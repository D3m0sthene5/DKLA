#!/usr/bin/env python3
"""Build OPUS_STAGE9_STATUS_DELTA from the Stage 8 reconciled handoff.

Usage: python3 -I build_stage9.py <handoff_dir> <opus8_dir> <review_dir> <leads_dir> <out_dir>

Deterministic except for the build timestamp. Reads only local files.
"""
import hashlib, json, os, re, shutil, sys, collections, datetime

HANDOFF, OPUS8, REVIEW, LEADS, OUT = sys.argv[1:6]
LEDGER_SHA = "80d6f1aa20e32209d9e9ec4c62f90cbdc5efdfc4c63d21e39dc1d1eeda8e5115"
DENOM = 14973
PRIOR_DET = 2226
PRIOR = {"YES": 191, "NO": 2035, "UNKNOWN": 12747}


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def jl(path):
    with open(path) as f:
        return [json.loads(l) for l in f if l.strip()]


def wjl(path, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, sort_keys=True, ensure_ascii=False) + "\n")


def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, sort_keys=True, ensure_ascii=False)
        f.write("\n")


if os.path.exists(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)

# ---------------------------------------------------------------- baseline
ledger_path = os.path.join(HANDOFF, "STAGE8_PRELIMINARY_MERGED_LEDGER.jsonl")
assert sha(ledger_path) == LEDGER_SHA, "Stage 8 ledger hash mismatch"
ledger = {r["instrument_id"]: r for r in jl(ledger_path)}
assert len(ledger) == 15010
val = [r for r in ledger.values() if r.get("included_validated")]
cnt = collections.Counter(r["substantive_effect"] for r in val)
assert len(val) == DENOM and cnt["yes"] == 191 and cnt["no"] == 2035 and cnt["indeterminate"] == 12747, cnt

# ---------------------------------------------------------------- exclusions
frozen = json.load(open(os.path.join(HANDOFF, "FROZEN_MEMBERSHIPS_V1_V5.json")))
reg = json.load(open(os.path.join(OPUS8, "STAGE8_JOB_REGISTRY.json")))
acc340 = {r["instrument_id"] for r in jl(os.path.join(HANDOFF, "STAGE8_TECHNICALLY_ACCEPTED_340.jsonl"))}
unres28 = {r["instrument_id"] for r in jl(os.path.join(HANDOFF, "STAGE8_UNRESOLVED_28.jsonl"))}
excl = collections.defaultdict(list)
for k, ids in frozen.items():
    for i in ids:
        excl[i].append("frozen_" + k)
for shard, d in reg["shards"].items():
    for i in d["ids"]:
        excl[i].append("opus_stage8_assignment:" + shard)
for i in acc340:
    excl[i].append("stage8_accepted_340")
for i in ("EO:5333", "EO:5335", "EO:5347"):
    excl[i].append("stage7_astra_quarantine")

FIVE = ["EO:8256", "EO:8497", "EO:8904", "EO:10225", "EO:11619"]

# ---------------------------------------------------------------- leads
lead_files = {
    "TAX_RETURN_INSPECTION": "STAGE9_TAX_RETURN_INSPECTION_CANDIDATES.jsonl",
    "WWI_EIGHT_HOUR": "STAGE9_WWI_EIGHT_HOUR_CANDIDATES.jsonl",
    "ALIEN_PROPERTY": "STAGE9_ALIEN_PROPERTY_CANDIDATES.jsonl",
    "SCREENED_UNASSIGNED": "STAGE9_UNASSIGNED_FAMILY_LEADS.jsonl",
}
leads = {}
for fam, fn in lead_files.items():
    for r in jl(os.path.join(HANDOFF, fn)):
        leads.setdefault(r["instrument_id"], []).append((fam, r))

# Titles that on their face concern civil-service appointment/eligibility. This is NOT
# a reconstruction of Astra's 1,181 manifest (which is unavailable); it only flags leads
# that must not be touched even provisionally.
CIVIL_FLAG = re.compile(r"civil service|without regard to the (requirements|civil)|appointments? in the|schedule a|from the requirements of the civil", re.I)


def apc_class(title):
    t = title.lower()
    if re.search(r"terminat|abolish|transferr|establishing|continuing the functions|designating", t):
        return "institutional_or_transfer"
    if re.search(r"delegat|powers|regulations|prescribed|vested", t):
        return "continuing_delegation_or_regulation"
    if re.search(r"lots not exceeding|any (seats|stocks)|property of any nature", t):
        return "general_class_authorization"
    if "lease" in t:
        return "single_identified_disposition_continuing_interest"
    if re.search(r"sell|reject all bids|reject bids|transfer to|dispose", t):
        return "single_identified_sale_or_disposition"
    return "other_or_misfiled"


screen = []
for iid in sorted(set(leads) | set(FIVE), key=lambda s: (re.sub(r"\D", "", s).zfill(6), s)):
    row = ledger.get(iid)
    fams = [f for f, _ in leads.get(iid, [])]
    title = row["title"] if row else None
    hits = sorted(set(excl.get(iid, [])))
    if iid in FIVE:
        own = "OPUS_STAGE8_ASSIGNMENT_CONFIRMED"
    elif "SCREENED_UNASSIGNED" in fams:
        own = "SCREENED_BY_ASTRA_PRIOR_EXCLUSION_SCAN"
    else:
        own = "OWNERSHIP_NOT_VERIFIED"
    flags = []
    if title and CIVIL_FLAG.search(title):
        flags.append("TITLE_SUGGESTS_CIVIL_SERVICE_SCOPE_DO_NOT_TOUCH")
    if any(f == "ALIEN_PROPERTY" for f in fams):
        flags.append("APC_TRIAGE:" + apc_class(title or ""))
    screen.append({
        "instrument_id": iid,
        "lead_families": fams,
        "in_stage8_ledger": row is not None,
        "included_validated": bool(row and row.get("included_validated")),
        "stage8_substantive_effect": row and row["substantive_effect"],
        "stage8_any_operative_EO_effect": row and row["any_operative_EO_effect"],
        "stage8_decision_status": row and row["decision_status"],
        "ledger_title": title,
        "known_exclusion_hits": hits,
        "astra_1181_manifest_check": "NOT_POSSIBLE_MANIFEST_UNAVAILABLE",
        "ownership_status": own,
        "flags": flags,
        "eligible_to_promote_in_stage9": own != "OWNERSHIP_NOT_VERIFIED" and not flags[:1] == ["TITLE_SUGGESTS_CIVIL_SERVICE_SCOPE_DO_NOT_TOUCH"] and bool(row and row.get("included_validated")) and (iid in FIVE or (row["substantive_effect"] == "indeterminate" and not hits)),
    })
wjl(os.path.join(OUT, "checks/OWNER_AND_BASELINE_CHECKS.jsonl"), screen)
screen_by = {s["instrument_id"]: s for s in screen}

# ---------------------------------------------------------------- pilots
PILOTS = {
    "TAX_RETURN_INSPECTION": [
        ("EO:5824", "pre-1937; state officers (non-federal recipients)"),
        ("EO:6342", "pre-1937; Senate special committee"),
        ("EO:9281", "WWII-era congressional special committee"),
        ("EO:9499", "WWII-era executive department recipient"),
        ("EO:10076", "agency recipient: Military Renegotiation Policy and Review Board"),
        ("EO:10090", "agency recipient: Federal Trade Commission (statistical/economic use)"),
        ("EO:10455", "multi-return congressional authorization later amended"),
        ("EO:10566", "amending order (footprint maps onto EO 10455)"),
        ("EO:10619", "agency recipient: HEW, individual returns (program use)"),
        ("EO:10814", "agency recipient: SEC, statistical transcript cards"),
        ("EO:11020", "1960s committee authorization"),
        ("EO:11720", "1970s committee authorization incl. excise returns"),
        ("EO:11786", "1974 House Judiciary (impeachment-era) authorization"),
        ("EO:11900", "last pre-TRA-1976 committee authorization (1976-01-22)"),
    ],
    "WWI_EIGHT_HOUR": [
        ("EO:1547", "pre-war (1912) Isthmian Canal contracts"),
        ("EO:2554", "general: Navy Dept. yards and private establishments"),
        ("EO:2559A", "general: military supplies, equipment and construction"),
        ("EO:2605", "general: War Dept. contracts"),
        ("EO:2663", "single identified contract (Alaskan Engineering Commission No. 43)"),
        ("EO:2678", "identified purchase orders with one firm"),
        ("EO:2830", "single building project (Arlington Building)"),
        ("EO:2908", "Alaskan Railroad construction (program, not a contract)"),
        ("EO:2918", "war housing program"),
        ("EO:3015", "post-armistice (1918-12-02) vessel repair contracts"),
    ],
    "ALIEN_PROPERTY": [
        ("EO:2843", "single sale of identified goods (50 hogsheads tobacco)"),
        ("EO:2858", "single sale of identified goods (nickel)"),
        ("EO:2953", "single private sale of identified real estate (Lilly Busch)"),
        ("EO:2954", "direction to reject all bids (then resale)"),
        ("EO:3016C", "sale of trademarks/patents to Chemical Foundation (litigated: 272 U.S. 1)"),
        ("EO:3016N", "transfer of shares to a named person (return-type disposition)"),
        ("EO:3150", "single private sale of identified real estate (Washington, D.C.)"),
        ("EO:3456", "single private sale of wharf property (Brooklyn)"),
        ("EO:3639A", "COUNTEREXAMPLE stratum: perpetual real estate lease (continuing interest)"),
        ("EO:4007", "sale of identified Standard Oil (N.J.) stock"),
    ],
    "SECONDARY_SCREENED": [
        ("EO:254", "dated office closing (1904 funeral)"),
        ("EO:4354", "dated office closing (1925-12-26)"),
        ("EO:5353", "dated office closing (1930-05-31) with cross-reference to another E.O."),
        ("EO:6920", "dated office closings (Dec. 24 and 31, 1934)"),
        ("EO:2171", "dated closing plus flag display (commemoration)"),
        ("EO:3665", "four-hour work day on a date (centennial)"),
        ("EO:7700", "employees excused on a date (Constitution 150th)"),
        ("EO:9379", "single special emergency board (rail wages)"),
        ("EO:9958", "single emergency board (airline dispute)"),
        ("EO:9172", "standing panel for creating emergency boards (continuing delegation stratum)"),
    ],
}

BLOCKED_HOSTS = ["www.presidency.ucsb.edu", "www.govinfo.gov", "www.archives.gov", "www.law.cornell.edu",
                 "uscode.house.gov", "babel.hathitrust.org", "www.loc.gov", "tile.loc.gov", "archive.org",
                 "www.federalregister.gov", "en.wikisource.org", "www.trumanlibrary.gov", "www.ecfr.gov",
                 "api.govinfo.gov", "mocat.library.unt.edu", "digital.library.unt.edu", "heinonline.org",
                 "www.courtlistener.com", "fraser.stlouisfed.org"]

FAMILY_LEGAL = {
    "TAX_RETURN_INSPECTION": {
        "controlling_law_to_retrieve": [
            "pre-1977 26 U.S.C. 6103(a) (1954 Code) and 1939 Code sec. 55 text: inspection 'upon order of the President' under Treasury regulations approved by the President",
            "Tax Reform Act of 1976, Pub. L. 94-455, sec. 1202(a) (new 6103) and sec. 1202(i) effective date (lead: effective 1977-01-01)",
            "26 CFR 301.6103(a)-1 and (a)-2: transition rule permitting continued use after 1976-12-31 of returns disclosed before 1977-01-01 for purposes permitted by the prior authority",
            "each order's own terms: recipient, return classes, years, purpose, time limit (e.g. 'during the 8xth Congress'), Treasury regulation approved with it",
            "26 U.S.C. 6103(f) (committee access since 1977) and 6103(i)/(j)/(l) agency access successors",
        ],
        "new_legal_blockers": [
            "TAX-B1: 26 CFR 301.6103(a)-1 (lead from search summary, text not retrieved) appears to save continued use of pre-1977 disclosures 'for purposes permitted by the prior authority'. For agency-recipient orders this is a candidate saved residual of the order's own terms (TC08): any-operative-effect cannot be 'no' until the regulation's text, scope and present status are read.",
            "TAX-B2: committee authorizations usually tie inspection to a resolution or a Congress; the end trigger must be read in each order and the authorizing resolution, not inferred from the date.",
            "TAX-B3: the 1976 rewrite alone does not prove whole-order cessation (prompt gate); sec. 1202 savings/transition text has not been read.",
        ],
        "candidate_rule_untested": "TAX-H1: an order whose only provision authorizes a named congressional committee to inspect returns for the duration of a named Congress or resolution, with the order's own end trigger before 1977-01-01, and no agency recipient, is no/no at the cutoff (finite, spent; TC07/TC10). Status: UNTESTED - no operative text could be read this session.",
    },
    "WWI_EIGHT_HOUR": {
        "controlling_law_to_retrieve": [
            "Act of June 19, 1912, ch. 174, 37 Stat. 137 (eight-hour stipulation in federal contracts)",
            "Naval Appropriation Act of March 4, 1917, ch. 180, 39 Stat. 1168, 1192 (President may suspend eight-hour limit 'in case of national emergency'; overtime at time and one-half); later 40 U.S.C. 326",
            "Joint Resolution of March 3, 1921, 41 Stat. 1359 (wartime statutes construed as if war ended) and any statute fixing the end of the 1917 'national emergency'",
            "Contract Work Hours Standards Act of 1962, Pub. L. 87-581 (repeal of 40 U.S.C. 321-326 and its savings clause)",
            "each order's end clause (lead: EO 2605 'operative during the pending emergency or until further orders', search summary only)",
        ],
        "new_legal_blockers": [
            "WWI-B1: the statutory suspension power survived into 1939 (EO 8198 cites 40 U.S.C. 326, search summary only), so the authority did not lapse with the Armistice; each order's own end trigger ('pending emergency', contract completion) must be read and its terminating event identified.",
            "WWI-B2: the 1917 proviso required overtime pay at time and one-half; retrospective wage claims are historical consequences only if no saved right remains (savings clause of the 1962 repeal unread).",
        ],
        "candidate_rule_untested": "WWI-H1: an order whose only provision suspends the eight-hour limit for a single identified contract or building project, with the work completed before the 1962 repeal of 40 U.S.C. 326, is spent (TC07). Status: UNTESTED.",
    },
    "ALIEN_PROPERTY": {
        "controlling_law_to_retrieve": [
            "Trading with the Enemy Act, Oct. 6, 1917, sec. 12 as amended Mar. 28, 1918 (sale 'by sale or otherwise' under the President; private sale on presidential order)",
            "Settlement of War Claims Act of 1928, 45 Stat. 254 (return of property; claims)",
            "each order's identified property, buyer and conditions; APC annual reports / sale records proving execution",
            "United States v. Chemical Foundation, 272 U.S. 1 (1926) (sales of seized patents upheld; lead only)",
        ],
        "new_legal_blockers": [
            "APC-B1: a grant to sell is not proof a sale occurred; APC annual reports or deed/transfer records are needed per order and none is reachable.",
            "APC-B2: orders directing rejection of bids and resale (e.g. EO 2954) are spent only if the resale is shown; an unexecuted direction is indeterminate.",
            "APC-B3: EO 3639A authorizes a perpetual lease; a perpetual leasehold created under the order is a candidate continuing property status (TC06) and is a counterexample to any 'all APC dispositions are spent' rule.",
        ],
        "candidate_rule_untested": "APC-H1: an order whose only provision authorizes a single sale of identified movable property, with the sale shown executed and no reserved interest, is spent (TC07). Status: UNTESTED; execution proof unreachable.",
    },
    "SECONDARY_SCREENED": {
        "controlling_law_to_retrieve": ["each order's full text (closing date; any pay/leave rule; any amendment of another order)",
                                        "for emergency boards: Railway Labor Act sec. 10 (45 U.S.C. 160) and NMB board records showing the report date"],
        "new_legal_blockers": [
            "SEC-B1: a dated closing is finite only if the text has no standing pay/leave or precedent clause; EO 5353's title cross-references another E.O., so a mixed footprint is possible.",
            "SEC-B2: EO 9172 creates a standing panel (continuing delegation), not a single board; it cannot share a single-board completion rule.",
        ],
        "candidate_rule_untested": "SEC-H1: an order whose only provision closes offices or excuses employees on one stated past date, with no standing pay/leave rule, is spent. Status: UNTESTED.",
    },
}

records, held = [], []
for fam, items in PILOTS.items():
    for iid, stratum in items:
        s = screen_by[iid]
        hold = ["OPERATIVE_TEXT_NOT_RETRIEVABLE: session network policy denies every primary-source host tried (see TELEMETRY.retrieval_attempts); WebSearch summaries are not operative text (gate 3)."]
        if s["ownership_status"] == "OWNERSHIP_NOT_VERIFIED":
            hold.append("OWNERSHIP_NOT_VERIFIED: Astra 1,181-ID manifest unavailable; may not be promoted even if decided.")
        for f in s["flags"]:
            if f.startswith("TITLE_SUGGESTS"):
                hold.append(f)
        if s["known_exclusion_hits"]:
            hold.append("KNOWN_EXCLUSION_HIT: " + ",".join(s["known_exclusion_hits"]))
        rec = {
            "instrument_id": iid,
            "proposal_id": "opus:s9:status:" + iid,
            "family": fam,
            "pilot_stratum": stratum,
            "ledger_title": s["ledger_title"],
            "stage8_baseline_substantive": s["stage8_substantive_effect"],
            "stage8_baseline_any_operative": s["stage8_any_operative_EO_effect"],
            "ownership_status": s["ownership_status"],
            "identity_validated_in_ledger": s["included_validated"],
            "operative_text_obtained": False,
            "text_source_grade": "none",
            "operative_footprint": [],
            "footprint_complete": False,
            "proposed_substantive_effect": "indeterminate",
            "proposed_any_operative_effect": "indeterminate",
            "decision_state": "HELD_NOT_DECIDED",
            "hold_reasons": hold,
            "controlling_law_to_retrieve": FAMILY_LEGAL[fam]["controlling_law_to_retrieve"],
            "family_blockers": FAMILY_LEGAL[fam]["new_legal_blockers"],
            "historical_causes": "UNKNOWN (retained; not researched in this present-status assignment)",
            "protected_fields_modified": False,
            "reviewer": None,
            "counted_in_coverage": False,
        }
        records.append(rec)
        held.append({"instrument_id": iid, "family": fam, "blockers": hold,
                     "source_that_would_settle_it": FAMILY_LEGAL[fam]["controlling_law_to_retrieve"][:2],
                     "priority": "P1" if fam in ("TAX_RETURN_INSPECTION", "WWI_EIGHT_HOUR", "ALIEN_PROPERTY") else "P2"})

# ---------------------------------------------------------------- five confirmations
rev = {r["instrument_id"]: r for r in jl(os.path.join(REVIEW, "V9_RET_CONFIRM_reviews.jsonl"))}
prod = {r["instrument_id"]: r for r in jl(os.path.join(REVIEW, "V9_COORD_PRODUCER_CHECKS.jsonl"))}
s8rev = {r["instrument_id"]: r for r in jl(os.path.join(OPUS8, "OPUS_STATUS_REVIEWS.jsonl")) if r["instrument_id"] in FIVE}
s8dec = {r["instrument_id"]: r for r in jl(os.path.join(OPUS8, "OPUS_STATUS_DECISIONS.jsonl")) if r["instrument_id"] in FIVE}
accepted = []
for iid in FIVE:
    p, v, o = prod[iid], rev[iid], s8rev[iid]
    votes = [(p["coordinator_substantive_effect"], p["coordinator_any_operative_effect"]),
             (v["reviewer_substantive_effect"], v["reviewer_any_operative_effect"]),
             (o["reviewer_substantive_effect"], o["reviewer_any_operative_effect"])]
    ok = all(x == ("no", "no") for x in votes) and v.get("verdict") == "confirm_no"
    rec = {
        "instrument_id": iid,
        "proposal_id": "opus:s9:status:" + iid,
        "family": "retirement_exemptions (Stage 8 reviewer-only case)",
        "ledger_title": ledger[iid]["title"],
        "stage8_baseline_substantive": ledger[iid]["substantive_effect"],
        "stage8_baseline_any_operative": ledger[iid]["any_operative_EO_effect"],
        "ownership_status": "OPUS_STAGE8_ASSIGNMENT_CONFIRMED",
        "stage8_producer_proposal": [s8dec[iid]["producer_proposal"]["proposed_substantive_effect"], s8dec[iid]["producer_proposal"]["proposed_any_operative_effect"]],
        "stage8_reviewer_V8_RET": [o["reviewer_substantive_effect"], o["reviewer_any_operative_effect"]],
        "stage9_coordinator_check": [p["coordinator_substantive_effect"], p["coordinator_any_operative_effect"]],
        "stage9_independent_reviewer_V9_RET_CONFIRM": [v["reviewer_substantive_effect"], v["reviewer_any_operative_effect"], v.get("verdict")],
        "operative_text_obtained": True,
        "text_source_grade": "hosted_transcript (American Presidency Project via Stage 8 WebFetch quote extraction; original bytes not held)",
        "operative_footprint": s8dec[iid]["producer_proposal"]["operative_footprint"],
        "footprint_complete": True,
        "rule_id": p["rule_id"],
        "proposed_substantive_effect": "no" if ok else "indeterminate",
        "proposed_any_operative_effect": "no" if ok else "indeterminate",
        "decision_state": "ACCEPTED_NO_NO_PROVISIONAL" if ok else "HELD",
        "limiting_predicates": p["limiting_predicates"],
        "dissent_and_counterevidence": {"coordinator": p["counterevidence"], "reviewer": v.get("counterevidence_and_dissent")},
        "source_quality_limits": v.get("source_quality_limits"),
        "first_cessation_date": "unknown (not adjudicated; protected field untouched)",
        "historical_causes": "UNKNOWN (retained)",
        "protected_fields_modified": False,
        "counted_in_coverage": ok,
    }
    records.append(rec)
    if ok:
        accepted.append({"instrument_id": iid, "substantive_effect": "no", "any_operative_EO_effect": "no",
                         "rule_id": p["rule_id"], "baseline": "indeterminate/indeterminate",
                         "reviewers": ["V8_RET (Stage 8)", "V9_COORD (Stage 9 coordinator check)", "V9_RET_CONFIRM (Stage 9 separate subagent)"],
                         "acceptance_label": "accepted_provisional"})
    else:
        held.append({"instrument_id": iid, "family": "retirement_exemptions", "blockers": ["reviewer disagreement"], "priority": "P1"})

wjl(os.path.join(OUT, "STAGE9_STATUS_RECORDS.jsonl"), records)
wjl(os.path.join(OUT, "STAGE9_ACCEPTED.jsonl"), accepted)
wjl(os.path.join(OUT, "STAGE9_HELD_QUEUE.jsonl"), held)
v7 = []
for a in accepted:
    iid = a["instrument_id"]
    assert ledger[iid]["substantive_effect"] == "indeterminate" and iid not in acc340
    assert not any(iid in ids for ids in frozen.values())
    v7.append({"instrument_id": iid, "membership": "V7_OPUS_PROVISIONAL", "substantive_effect": "no",
               "any_operative_EO_effect": "no", "rule_id": a["rule_id"], "title": ledger[iid]["title"],
               "signing_date": ledger[iid]["signing_date"], "causes": "UNKNOWN (not researched)"})
wjl(os.path.join(OUT, "CLAUDE_NEW_NO_V7_OPUS_PROVISIONAL.jsonl"), v7)

# ---------------------------------------------------------------- accounting
newly = len(accepted)
add_yes = 0
add_no = newly
acct = {
    "cutoff": "2026-10-14 America/New_York",
    "codebook_version": "2.0.0",
    "baseline_source": "STAGE8_PRELIMINARY_MERGED_LEDGER.jsonl sha256 " + LEDGER_SHA,
    "prior_accepted_substantive_determinate": PRIOR_DET,
    "prior_breakdown": PRIOR,
    "prior_note": "Includes Stage 8's 340 Opus NO/NO as PRIOR work (technical integration on reported reviews), not Stage 9 throughput.",
    "added_ACCEPTED_YES": add_yes,
    "added_ACCEPTED_NO": add_no,
    "newly_accepted": newly,
    "previously_accepted_overturned": 0,
    "substantive_UNKNOWN_remaining": PRIOR["UNKNOWN"] - newly,
    "numerator": PRIOR_DET + newly,
    "denominator": DENOM,
    "coverage_pct": round((PRIOR_DET + newly) / DENOM * 100, 6),
    "coverage_pct_prior": round(PRIOR_DET / DENOM * 100, 6),
    "post_stage9_provisional": {"YES": PRIOR["YES"] + add_yes, "NO": PRIOR["NO"] + add_no, "UNKNOWN": PRIOR["UNKNOWN"] - newly},
    "researched_ids": len(records),
    "held_ids": len(held),
    "historical_census_complete": False,
    "blockers": [
        "Astra 1,181-ID reserved manifest (705 P1, 476 P2) NOT AVAILABLE: no Stage 9 family pilot ID can be promoted; recorded as blocker, not proof of nonoverlap.",
        "Primary-source network access denied for this session (hosts listed in TELEMETRY.json).",
        "16 NRA P3 original IDs not recoverable from bundled files (they were in the unbundled Stage 7 split package).",
    ],
}
wjson(os.path.join(OUT, "ACCOUNTING.json"), acct)

# ---------------------------------------------------------------- next family candidates from the latest ledger
FAMS = [  # most specific first
    ("tax_return_inspection", r"inspection of .*returns|tax returns"),
    ("alien_property", r"alien property"),
    ("eight_hour_suspension", r"eight-hour"),
    ("emergency_board", r"emergency board"),
    ("indian_trust_period_extension", r"trust periods?"),
    ("one_day_closing_or_holiday", r"ordered closed|closing of|excused from duty|half-?holiday|holiday"),
    ("panama_canal", r"canal zone|panama|isthm"),
    ("consular_or_diplomatic", r"consul|diplomatic|legation"),
    ("tariff_or_customs", r"tariff|customs|duty|preferences"),
    ("land_withdrawal_or_reservation", r"withdraw|reservation|reserved|public land|lands? (in|for)"),
    ("commission_or_committee", r"commission|committee|council|board"),
]
pool = [r for r in val if r["substantive_effect"] == "indeterminate" and not excl.get(r["instrument_id"]) and r["instrument_id"] not in unres28]
fam_counts = collections.Counter()
fam_ex = collections.defaultdict(list)
for r in pool:
    t = (r.get("title") or "").lower()
    for name, pat in FAMS:
        if re.search(pat, t):
            fam_counts[name] += 1
            if len(fam_ex[name]) < 5:
                fam_ex[name].append(r["instrument_id"])
            break
nfc = {
    "basis": "STAGE8_PRELIMINARY_MERGED_LEDGER (sha256 %s) validated rows still substantive=indeterminate, minus frozen V1-V5, Stage 8 Opus assignments, the 340, Stage 7 quarantine and the 28 Stage 8 unresolved IDs; first matching title pattern wins." % LEDGER_SHA,
    "pool_size": len(pool),
    "title_pattern_counts": dict(fam_counts.most_common()),
    "examples": dict(fam_ex),
    "scope_warning": "Astra's 1,181-ID manifest was NOT available, so these counts may include Astra-reserved IDs. Title patterns are discovery leads, not legal classes. Indian trust-period orders must never be bulk-expired by date (25 U.S.C. 5102).",
    "recommended_order": [
        {"family": "WWI_EIGHT_HOUR (single-contract/building stratum)", "why": "finite projects with one statutory framework (1912 Act, 1917 proviso, 1962 repeal); one statute retrieval set covers ~30 single-project orders; needs presidency.ucsb.edu/HathiTrust Lord-list texts or Statutes at Large", "prerequisite": "Astra manifest + network access"},
        {"family": "TAX_RETURN_INSPECTION (congressional-committee stratum)", "why": "~70 committee orders share one statutory transition (TRA 1976 sec. 1202) and are mostly APP/FR-hosted; agency-recipient stratum is blocked by the 301.6103(a)-1 continued-use rule (TAX-B1)", "prerequisite": "Astra manifest + govinfo/APP/eCFR access"},
        {"family": "SECONDARY one-day closings", "why": "small (13) and likely finite, but each needs its own text; low statute cost", "prerequisite": "network access only (Astra-screened)"},
        {"family": "ALIEN_PROPERTY single sales", "why": "pivot candidate only: execution proof (APC reports) is expensive and EO 3639A shows continuing-interest exceptions", "prerequisite": "Astra manifest + HathiTrust APC annual reports"},
    ],
}
wjson(os.path.join(OUT, "NEXT_FAMILY_CANDIDATES.json"), nfc)

# ---------------------------------------------------------------- rules
rules = [
    {"rule_id": "RET-CHAIN-C",
     "legal_authority": "sec. 204, Act of June 30, 1932 (47 Stat. 404); Pub. L. 95-256 sec. 5(c)/6(c), effective 1978-09-30 (via accepted RET-R2 decisions on chain-end orders)",
     "applicability_predicates": [
         "C1: the order's only operative provision exempts a named person from compulsory retirement for age for a period whose stated end precedes the cutoff (text shown in a hosted transcript or better)",
         "C2: every later order naming the same person was identified, and the chain's last order is accepted no/no in the Stage 8 ledger",
         "C3: under reading (a) (fresh grant) the order ended on its own stated date; under reading (b) (extension) its status follows the chain's last order; both readings give no/no",
         "C4: no residual term (status, right, office, annuity grant) is created by the order itself"],
     "exceptions": ["chain-end order not accepted no/no", "order with a second operative provision", "beneficiary in a system that kept mandatory separation"],
     "covered_ids": ["EO:8256", "EO:8497", "EO:8904", "EO:10225"],
     "dependency": "Reading (b) depends on the Stage 8 acceptances of EO 9238 and EO 10333 (technically integrated, not freshly audited). Reading (a) does not.",
     "substantive_result": "no", "any_effect_result": "no"},
    {"rule_id": "RET-R2/NONLIMIT",
     "legal_authority": "5 U.S.C. 8335 as amended by Pub. L. 95-256 (striking subsecs. (a)-(e) eff. 1978-09-30)",
     "applicability_predicates": ["RET-R2 Q1-Q5 as frozen in Stage 8", "N1: the order's only other clause states that nothing in the order limits the Civil Service Commission's delegated exemption authority; it grants, commands, permits or creates nothing (rule of construction), consistent with the accepted treatment of the identical clause in EO 11378"],
     "exceptions": ["a clause that itself delegates or exercises authority", "position within a surviving mandatory-separation category"],
     "covered_ids": ["EO:11619"],
     "substantive_result": "no (no later than 1978-09-30)", "any_effect_result": "no"},
]
for fam, d in FAMILY_LEGAL.items():
    rules.append({"rule_id": d["candidate_rule_untested"].split(":")[0], "family": fam, "status": "UNTESTED_NO_TEXT",
                  "statement": d["candidate_rule_untested"], "controlling_law_to_retrieve": d["controlling_law_to_retrieve"],
                  "exception_checks": d["new_legal_blockers"], "covered_ids": []})
wjl(os.path.join(OUT, "rules/STAGE9_RULES.jsonl"), rules)

# ---------------------------------------------------------------- copy evidence, reviews, leads, code
for sub in ("evidence", "reviews", "leads"):
    os.makedirs(os.path.join(OUT, sub), exist_ok=True)
for f in sorted(os.listdir(REVIEW)):
    if f.endswith((".jsonl", ".md", ".json")):
        shutil.copy2(os.path.join(REVIEW, f), os.path.join(OUT, "reviews", f))
for f in sorted(os.listdir(LEADS)):
    src = os.path.join(LEADS, f)
    if f == "REPORT.md":
        dst = os.path.join(OUT, f)
    else:
        dst = os.path.join(OUT, "leads" if f.startswith("websearch") else "evidence", f)
    if os.path.isdir(src):
        shutil.copytree(src, dst)
    else:
        shutil.copy2(src, dst)
os.makedirs(os.path.join(OUT, "code"), exist_ok=True)
shutil.copy2(os.path.abspath(__file__), os.path.join(OUT, "code", "build_stage9.py"))

# ---------------------------------------------------------------- telemetry and conflicts
wjson(os.path.join(OUT, "TELEMETRY.json"), {
    "session_clock_utc": {"handoff_unpacked": "2026-10-16T15:55Z (file mtimes)", "network_probe": "15:57Z", "reviewer_V9_RET_CONFIRM": "15:59:46Z-16:02:29Z (agent-reported)", "packaging": "see MANIFEST.built_utc"},
    "agents": [
        {"id": "V9_COORD", "role": "coordinator, producer-side check of the five reviewer-only cases, pilot selection, packaging", "tokens": "not exposed to the coordinator"},
        {"id": "V9_RET_CONFIRM", "role": "separately instantiated reviewer subagent; read only the copied input folder; blind to coordinator verdict",
         "subagent_tokens": 96854, "tool_uses": 14, "duration_ms": 196738},
    ],
    "independence_note": "V9_RET_CONFIRM is a separate subagent context of the same model family, not a human reviewer. The coordinator wrote its check record after seeing the reviewer's summary; the coordinator's reasoning was formed earlier but this cannot be proved from the record.",
    "retrieval_attempts": {
        "shell_curl": "HTTP CONNECT 403 from the session egress proxy for every host in blocked_hosts (policy denial).",
        "WebFetch_tool": "getaddrinfo ENOTFOUND for presidency.ucsb.edu, govinfo.gov, law.cornell.edu, wikisource.org, federalregister.gov, archive.org.",
        "WebSearch_tool": "works; returns model-written summaries only (search_summary_only grade); 7 queries run; none used as a basis for a status.",
        "reachable_but_unsuitable": ["api.github.com", "raw.githubusercontent.com", "pypi.org"],
        "blocked_hosts": BLOCKED_HOSTS,
    },
    "per_family_yield": {
        "RETIREMENT_REVIEWER_CONFIRMATION": {"researched": 5, "accepted_no_no": len(accepted), "accepted_yes": 0, "held": 5 - len(accepted), "error_rate_vs_reviewer": 0.0, "agent_minutes": 3.3, "subagent_tokens": 96854},
        "TAX_RETURN_INSPECTION": {"researched": 14, "accepted": 0, "texts_obtained": 0, "new_legal_blockers": 3},
        "WWI_EIGHT_HOUR": {"researched": 10, "accepted": 0, "texts_obtained": 0, "new_legal_blockers": 2},
        "ALIEN_PROPERTY": {"researched": 10, "accepted": 0, "texts_obtained": 0, "new_legal_blockers": 3},
        "SECONDARY_SCREENED": {"researched": 10, "accepted": 0, "texts_obtained": 0, "new_legal_blockers": 2},
    },
    "validated_statuses_per_family_note": "Only the retirement confirmation family produced validated statuses (no text retrieval needed: Stage 8 caches). The three pilot families produced zero because no operative text could be retrieved, not because a rule failed; their yield is unmeasured, not zero.",
})
conf = [
    {"instrument_id": "EO:9238", "kind": "inherited_text_variant", "detail": "Hosted transcript spells 'Maurice C. Latte' in the operative sentence; title and other text 'Latta'. Not corrected."},
    {"instrument_id": "*", "kind": "inherited_retrieval_time", "detail": "Several Stage 8 cache headers say 'retrieved ... (approximate)'; carried as recorded, no timestamp invented."},
    {"instrument_id": "EO:11619", "kind": "interpretive_dissent", "detail": "Non-limitation clause: rule of construction (adopted by V8_RET, V9_RET_CONFIRM, V9_COORD) vs operative provision (Stage 8 producer hold). If operative, any_operative_EO_effect=indeterminate."},
    {"instrument_id": "STATUTE:Pub.L.95-256", "kind": "section_numbering", "detail": "Statutes rendering labels the 8335 amendment sec. 6(c); Code note says sec. 5(c). Substance identical; not resolved."},
    {"instrument_id": "EO:3441", "kind": "lead_scope", "detail": "In the alien-property lead list but titled as a Civil Service Rules Schedule A amendment: possible Astra civil-service scope; not touched."},
    {"instrument_id": "EO:8975", "kind": "lead_scope", "detail": "Alien-property lead titled 'appointments ... without regard to' civil service requirements: possible Astra scope; not touched."},
    {"instrument_id": "EO:8273", "kind": "lead_scope", "detail": "Screened commemoration lead excepts appointments from civil service requirements: possible Astra scope despite Astra's screen; not touched."},
    {"instrument_id": "EO:9592", "kind": "lead_misfiled", "detail": "Alien-property lead concerns Office of War Information contracts (EO 9001 extension); family label likely wrong."},
    {"instrument_id": "EO:2171,EO:5", "kind": "lead_duplicate", "detail": "Appear in both the commemoration and office-closing screened families."},
]
wjl(os.path.join(OUT, "CONFLICT_LOG.jsonl"), conf)

# ---------------------------------------------------------------- manifest
man = []
for root, _, files in os.walk(OUT):
    for f in sorted(files):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, OUT)
        if rel == "MANIFEST.json":
            continue
        man.append({"path": rel, "sha256": sha(p), "bytes": os.path.getsize(p)})
man.sort(key=lambda x: x["path"])
wjson(os.path.join(OUT, "MANIFEST.json"), {"package": "OPUS_STAGE9_STATUS_DELTA",
                                            "built_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                            "inputs": {"stage8_ledger_sha256": LEDGER_SHA},
                                            "files": man})
print(json.dumps(acct, indent=1))
