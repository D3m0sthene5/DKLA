#!/usr/bin/env python3
"""Integrate Stage 9 producer shards and independent reviews into OPUS_STAGE9_STATUS_DELTA (v2).

Usage: python3 -I build_stage9_v2.py <handoff_dir> <opus8_dir> <s9_dir> <v1_review_dir> <v1_leads_dir> <report_md> <out_dir>

Reads only local files. Promotion gates:
  * the order is in the five Opus Stage 8 reviewer-only cases, or passed Astra's prior exclusion scan
    (STAGE9_UNASSIGNED_FAMILY_LEADS) without a civil-service title flag;
  * Stage 8 baseline substantive_effect == indeterminate and no known exclusion hit;
  * a separate reviewer gave accept / accept_with_correction with the SAME substantive and any-effect
    statuses as the producer.
Reviewed determinate results for OWNERSHIP_NOT_VERIFIED orders are kept but never counted.
"""
import collections, datetime, hashlib, json, os, re, shutil, sys

HANDOFF, OPUS8, S9, V1REV, V1LEADS, REPORT, OUT = sys.argv[1:8]
LEDGER_SHA = "80d6f1aa20e32209d9e9ec4c62f90cbdc5efdfc4c63d21e39dc1d1eeda8e5115"
DENOM, PRIOR_DET = 14973, 2226
PRIOR = {"YES": 191, "NO": 2035, "UNKNOWN": 12747}
MAX_BINARY = 2 * 1024 * 1024
TEXTLIKE = (".txt", ".json", ".jsonl", ".md", ".log", ".py", ".mjs", ".js", ".csv", ".tsv", ".sh")
REVIEWERS = {"S9_TAX": "V9_TAX_REV", "S9_WWI": "V9_WWI_REV", "S9_APC": "V9_APC_REV", "S9_ADV": "V9_ADV_REV",
             "S9_COMM": "V9_COMM_REV", "S9_CLOSE_BOARD": "V9_CB_REV", "S9_TAXX_A": "V9_TAXX_A_REV",
             "S9_TAXX_B": "V9_TAXX_B_REV", "S9_WWIX_A": "V9_WWIX_A_REV", "S9_WWIX_B": "V9_WWIX_B_REV"}
FAMILY = {"S9_TAX": "TAX_RETURN_INSPECTION", "S9_TAXX_A": "TAX_RETURN_INSPECTION", "S9_TAXX_B": "TAX_RETURN_INSPECTION",
          "S9_WWI": "WWI_EIGHT_HOUR", "S9_WWIX_A": "WWI_EIGHT_HOUR", "S9_WWIX_B": "WWI_EIGHT_HOUR",
          "S9_APC": "ALIEN_PROPERTY", "S9_ADV": "ADVISORY_COMMITTEE_CONTINUANCE", "S9_COMM": "COMMEMORATION",
          "S9_CLOSE_BOARD": "OFFICE_CLOSING_AND_EMERGENCY_BOARD"}
PHASE = {"S9_TAX": "pilot", "S9_WWI": "pilot", "S9_APC": "pilot", "S9_ADV": "screened_production",
         "S9_COMM": "screened_production", "S9_CLOSE_BOARD": "screened_production",
         "S9_TAXX_A": "expansion", "S9_TAXX_B": "expansion", "S9_WWIX_A": "expansion", "S9_WWIX_B": "expansion"}


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def jl(p):
    if not os.path.exists(p):
        return []
    out = []
    with open(p) as f:
        for l in f:
            l = l.strip()
            if l:
                out.append(json.loads(l))
    return out


def wjl(p, rows):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        for r in rows:
            f.write(json.dumps(r, sort_keys=True, ensure_ascii=False) + "\n")


def wjson(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        json.dump(o, f, indent=1, sort_keys=True, ensure_ascii=False)
        f.write("\n")


if os.path.exists(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)

# ------------------------------------------------------------------ baseline and exclusions
lp = os.path.join(HANDOFF, "STAGE8_PRELIMINARY_MERGED_LEDGER.jsonl")
assert sha(lp) == LEDGER_SHA
ledger = {r["instrument_id"]: r for r in jl(lp)}
val = [r for r in ledger.values() if r.get("included_validated")]
c = collections.Counter(r["substantive_effect"] for r in val)
assert len(val) == DENOM and (c["yes"], c["no"], c["indeterminate"]) == (191, 2035, 12747)
frozen = json.load(open(os.path.join(HANDOFF, "FROZEN_MEMBERSHIPS_V1_V5.json")))
reg = json.load(open(os.path.join(OPUS8, "STAGE8_JOB_REGISTRY.json")))
acc340 = {r["instrument_id"] for r in jl(os.path.join(HANDOFF, "STAGE8_TECHNICALLY_ACCEPTED_340.jsonl"))}
unres28 = {r["instrument_id"] for r in jl(os.path.join(HANDOFF, "STAGE8_UNRESOLVED_28.jsonl"))}
excl = collections.defaultdict(list)
for k, ids in frozen.items():
    for i in ids:
        excl[i].append("frozen_" + k)
for s, d in reg["shards"].items():
    for i in d["ids"]:
        excl[i].append("opus_stage8_assignment:" + s)
for i in acc340:
    excl[i].append("stage8_accepted_340")
for i in ("EO:5333", "EO:5335", "EO:5347"):
    excl[i].append("stage7_astra_quarantine")
screened = {r["instrument_id"]: r["family"] for r in jl(os.path.join(HANDOFF, "STAGE9_UNASSIGNED_FAMILY_LEADS.jsonl"))}
CIVIL = re.compile(r"civil service|without regard to the (requirements|civil)|from the requirements of the civil|schedule a", re.I)
FIVE = ["EO:8256", "EO:8497", "EO:8904", "EO:10225", "EO:11619"]


def ownership(iid):
    t = ledger[iid]["title"]
    if iid in FIVE:
        return "OPUS_STAGE8_ASSIGNMENT_CONFIRMED", True
    if iid in screened and not CIVIL.search(t):
        return "SCREENED_BY_ASTRA_PRIOR_EXCLUSION_SCAN", True
    if iid in screened:
        return "SCREENED_BUT_CIVIL_SERVICE_TITLE_FLAG", False
    return "OWNERSHIP_NOT_VERIFIED", False


# ------------------------------------------------------------------ the five (v1 work, unchanged)
rev5 = {r["instrument_id"]: r for r in jl(os.path.join(V1REV, "V9_RET_CONFIRM_reviews.jsonl"))}
prod5 = {r["instrument_id"]: r for r in jl(os.path.join(V1REV, "V9_COORD_PRODUCER_CHECKS.jsonl"))}
s8rev = {r["instrument_id"]: r for r in jl(os.path.join(OPUS8, "OPUS_STATUS_REVIEWS.jsonl")) if r["instrument_id"] in FIVE}
records, accepted, held, reviewed_held_owner = [], [], [], []
for iid in FIVE:
    p, v, o = prod5[iid], rev5[iid], s8rev[iid]
    ok = all(x == ("no", "no") for x in [(p["coordinator_substantive_effect"], p["coordinator_any_operative_effect"]),
                                         (v["reviewer_substantive_effect"], v["reviewer_any_operative_effect"]),
                                         (o["reviewer_substantive_effect"], o["reviewer_any_operative_effect"])]) and v["verdict"] == "confirm_no"
    assert ok
    rec = {"instrument_id": iid, "family": "RETIREMENT_REVIEWER_CONFIRMATION", "phase": "reviewer_confirmation",
           "shard": "V9_COORD", "reviewer": "V9_RET_CONFIRM (+V8_RET Stage 8)", "ledger_title": ledger[iid]["title"],
           "ownership_status": "OPUS_STAGE8_ASSIGNMENT_CONFIRMED", "final_substantive_effect": "no",
           "final_any_operative_EO_effect": "no", "decision_state": "ACCEPTED_PROVISIONAL", "rule_id": p["rule_id"],
           "limiting_predicates": p["limiting_predicates"], "counted_in_coverage": True,
           "evidence_dir": "evidence/v1_retirement/"}
    records.append(rec)
    accepted.append({"instrument_id": iid, "substantive_effect": "no", "any_operative_EO_effect": "no",
                     "family": rec["family"], "rule_id": p["rule_id"], "reviewers": ["V8_RET", "V9_COORD", "V9_RET_CONFIRM"]})

# ------------------------------------------------------------------ shards
overrides = collections.defaultdict(list)
for o in jl(os.path.join(S9, "COORD_OVERRIDES.jsonl")):
    overrides[o["instrument_id"]].append(o)
shard_names = sorted(d for d in os.listdir(os.path.join(S9, "shards")) if os.path.isdir(os.path.join(S9, "shards", d)))
fam_stats = collections.defaultdict(lambda: collections.Counter())
for sh in shard_names:
    props = jl(os.path.join(S9, "shards", sh, "status_proposals.jsonl"))
    revdir = REVIEWERS.get(sh)
    revs = {r["instrument_id"]: r for r in jl(os.path.join(S9, "reviews", revdir or "-", "reviews.jsonl"))}
    packet = {r["instrument_id"] for r in jl(os.path.join(S9, "packets", sh + ".jsonl"))}
    seen = set()
    for p in props:
        iid = p["instrument_id"]
        assert iid in packet, (sh, iid)
        assert iid not in seen, (sh, iid)
        seen.add(iid)
        own, promotable = ownership(iid)
        base = ledger[iid]
        fam = FAMILY[sh]
        ps, pa = p.get("proposed_substantive_effect"), p.get("proposed_any_operative_effect")
        r = revs.get(iid)
        rv = r and r.get("verdict")
        rs, ra = (r.get("reviewer_substantive_effect"), r.get("reviewer_any_operative_effect")) if r else (None, None)
        clean_base = base["substantive_effect"] == "indeterminate" and not excl.get(iid) and base.get("included_validated")
        # Each axis stands only where producer and reviewer agree; otherwise it is indeterminate
        # (the stricter view prevails). Coordinator overrides can only make an axis stricter.
        if r is None:
            fs, fa = "indeterminate", "indeterminate"
        elif rv == "reject_other":
            fs, fa = "indeterminate", "indeterminate"
        else:
            fs = ps if rs == ps else "indeterminate"
            fa = pa if ra == pa else "indeterminate"
        applied = []
        for o in overrides.get(iid, []):
            if o["value"] != "indeterminate":
                raise SystemExit("override may only make an axis stricter: %r" % o)
            if o["axis"] == "substantive" and fs != "indeterminate":
                fs = "indeterminate"; applied.append(o)
            if o["axis"] == "any" and fa != "indeterminate":
                fa = "indeterminate"; applied.append(o)
        agree = r is not None and fs == ps and fa == pa and not applied
        if r is None:
            state = "NOT_YET_REVIEWED"
        elif fs == "indeterminate":
            state = "REVIEWED_INDETERMINATE" if ps == "indeterminate" else "REVIEW_DISAGREEMENT_HELD"
        elif promotable and clean_base:
            state = "ACCEPTED_PROVISIONAL"
        else:
            state = "REVIEWED_DETERMINATE_HELD_" + own
        counted = state == "ACCEPTED_PROVISIONAL"
        st = fam_stats[(fam, PHASE[sh])]
        st["researched"] += 1
        st["texts_obtained"] += bool(p.get("text_obtained"))
        st["reviewed"] += r is not None
        st["review_non_accept"] += r is not None and rv not in ("accept", "accept_with_correction")
        st["review_corrections"] += rv == "accept_with_correction"
        st["review_status_disagree"] += r is not None and (rs, ra) != (ps, pa)
        st["reviewed_determinate_substantive"] += fs in ("yes", "no")
        st["any_effect_narrowed_by_review_or_override"] += fa == "indeterminate" and pa != "indeterminate"
        st["accepted_counted"] += counted
        st["accepted_yes"] += counted and fs == "yes"
        st["accepted_no"] += counted and fs == "no"
        rec = {"instrument_id": iid, "family": fam, "phase": PHASE[sh], "shard": sh, "reviewer": revdir,
               "ledger_title": base["title"], "ledger_signing_date": base["signing_date"],
               "stage8_baseline": [base["substantive_effect"], base["any_operative_EO_effect"]],
               "ownership_status": own, "known_exclusion_hits": excl.get(iid, []),
               "producer_proposal": [ps, pa], "producer_confidence": p.get("confidence"),
               "text_obtained": p.get("text_obtained"), "text_source_grade": p.get("text_source_grade"),
               "footprint_complete": p.get("footprint_complete"), "rule_id": p.get("rule_id"),
               "hold_reason": p.get("hold_reason"), "what_remains_inferential": p.get("what_remains_inferential"),
               "review_verdict": rv, "reviewer_statuses": [rs, ra],
               "review_problems": r and r.get("problems"), "dissent_or_limiting_predicates": r and r.get("dissent_or_limiting_predicates"),
               "coordinator_overrides": applied,
               "final_substantive_effect": fs, "final_any_operative_EO_effect": fa, "decision_state": state,
               "counted_in_coverage": counted, "historical_causes": "UNKNOWN (retained)",
               "protected_fields_modified": False,
               "evidence_dir": f"evidence/shards/{sh}/", "review_dir": f"evidence/reviews/{revdir}/"}
        records.append(rec)
        if counted:
            accepted.append({"instrument_id": iid, "substantive_effect": fs, "any_operative_EO_effect": fa, "family": fam,
                             "rule_id": p.get("rule_id"), "reviewers": [sh + " (producer)", revdir]})
        elif state.startswith("REVIEWED_DETERMINATE_HELD"):
            reviewed_held_owner.append({"instrument_id": iid, "family": fam, "substantive_effect": fs,
                                        "any_operative_EO_effect": fa, "ownership_status": own,
                                        "promote_when": "Astra 1,181-ID manifest shows the ID is outside the reserved scope"})
        else:
            held.append({"instrument_id": iid, "family": fam, "state": state,
                         "blocker": p.get("hold_reason") or (r and r.get("problems")) or "not reviewed",
                         "ownership_status": own})
    for iid in sorted(packet - seen):
        held.append({"instrument_id": iid, "family": FAMILY[sh], "state": "NO_PRODUCER_RECORD", "blocker": "producer did not finish"})
        fam_stats[(FAMILY[sh], PHASE[sh])]["missing_producer_record"] += 1

ids = [r["instrument_id"] for r in records]
assert len(ids) == len(set(ids)), [i for i, n in collections.Counter(ids).items() if n > 1]
wjl(os.path.join(OUT, "STAGE9_STATUS_RECORDS.jsonl"), records)
wjl(os.path.join(OUT, "STAGE9_ACCEPTED.jsonl"), accepted)
wjl(os.path.join(OUT, "STAGE9_REVIEWED_DETERMINATE_HELD_FOR_OWNERSHIP.jsonl"), reviewed_held_owner)
wjl(os.path.join(OUT, "STAGE9_HELD_QUEUE.jsonl"), held)

v7, yes_new = [], []
for a in accepted:
    iid = a["instrument_id"]
    row = ledger[iid]
    assert row["substantive_effect"] == "indeterminate" and iid not in acc340
    assert not any(iid in v for v in frozen.values())
    m = {"instrument_id": iid, "substantive_effect": a["substantive_effect"], "any_operative_EO_effect": a["any_operative_EO_effect"],
         "family": a["family"], "rule_id": a["rule_id"], "title": row["title"], "signing_date": row["signing_date"],
         "causes": "UNKNOWN (not researched)"}
    if a["substantive_effect"] == "no":
        v7.append(dict(m, membership="V7_OPUS_PROVISIONAL"))
    elif a["substantive_effect"] == "yes":
        yes_new.append(dict(m, membership="STAGE9_NEW_YES_PROVISIONAL"))
wjl(os.path.join(OUT, "CLAUDE_NEW_NO_V7_OPUS_PROVISIONAL.jsonl"), v7)
wjl(os.path.join(OUT, "STAGE9_NEW_YES_PROVISIONAL.jsonl"), yes_new)

# ------------------------------------------------------------------ accounting
ny, nn = len(yes_new), len(v7)
newly = ny + nn
any_ct = collections.Counter(a["any_operative_EO_effect"] for a in accepted)
acct = {
    "cutoff": "2026-10-14 America/New_York", "codebook_version": "2.0.0",
    "baseline_source": "STAGE8_PRELIMINARY_MERGED_LEDGER.jsonl sha256 " + LEDGER_SHA,
    "prior_accepted_substantive_determinate": PRIOR_DET, "prior_breakdown": PRIOR,
    "prior_note": "Includes Stage 8's 340 Opus NO/NO as PRIOR work, not Stage 9 throughput.",
    "added_ACCEPTED_YES": ny, "added_ACCEPTED_NO": nn, "newly_accepted": newly,
    "previously_accepted_overturned": 0,
    "substantive_UNKNOWN_remaining": PRIOR["UNKNOWN"] - newly,
    "numerator": PRIOR_DET + newly, "denominator": DENOM,
    "coverage_pct": round((PRIOR_DET + newly) / DENOM * 100, 6),
    "coverage_pct_prior": round(PRIOR_DET / DENOM * 100, 6),
    "post_stage9_provisional": {"YES": PRIOR["YES"] + ny, "NO": PRIOR["NO"] + nn, "UNKNOWN": PRIOR["UNKNOWN"] - newly},
    "accepted_any_operative_effect_breakdown": dict(any_ct),
    "reviewed_determinate_held_for_ownership": len(reviewed_held_owner),
    "reviewed_determinate_held_for_ownership_breakdown": dict(collections.Counter(r["substantive_effect"] for r in reviewed_held_owner)),
    "coverage_pct_if_ownership_cleared": round((PRIOR_DET + newly + sum(1 for r in reviewed_held_owner if r["substantive_effect"] in ("yes", "no"))) / DENOM * 100, 6),
    "researched_ids": len(records), "held_or_indeterminate_ids": len(held),
    "historical_census_complete": False,
    "blockers": [
        "Astra 1,181-ID reserved manifest NOT AVAILABLE (lives in ASTRA_STAGE7_CIVIL_STATUS_DELTA_2026-10-15.zip > FROZEN_STAGE7_ASSIGNMENT_SPLIT_ORIGINAL.zip sha256 5b553c02...): tax, WWI and alien-property results cannot be promoted; recorded as blocker, not proof of nonoverlap.",
        "16 NRA P3 original IDs not recoverable from bundled files.",
    ],
}
wjson(os.path.join(OUT, "ACCOUNTING.json"), acct)

# ------------------------------------------------------------------ telemetry and yield
tele = jl(os.path.join(S9, "TELEMETRY_LOG.jsonl"))
tok = collections.defaultdict(int)
dur = collections.defaultdict(int)
agent_family = {"S9_TAX_producer": "TAX_RETURN_INSPECTION", "V9_TAX_REV": "TAX_RETURN_INSPECTION",
                "S9_TAXX_A_producer": "TAX_RETURN_INSPECTION", "S9_TAXX_B_producer": "TAX_RETURN_INSPECTION",
                "V9_TAXX_A_REV": "TAX_RETURN_INSPECTION", "V9_TAXX_B_REV": "TAX_RETURN_INSPECTION",
                "S9_WWI_producer": "WWI_EIGHT_HOUR", "V9_WWI_REV": "WWI_EIGHT_HOUR", "S9_WWIX_A_producer": "WWI_EIGHT_HOUR",
                "S9_WWIX_B_producer": "WWI_EIGHT_HOUR", "V9_WWIX_A_REV": "WWI_EIGHT_HOUR", "V9_WWIX_B_REV": "WWI_EIGHT_HOUR",
                "S9_APC_producer": "ALIEN_PROPERTY", "V9_APC_REV": "ALIEN_PROPERTY",
                "S9_ADV_producer": "ADVISORY_COMMITTEE_CONTINUANCE", "V9_ADV_REV": "ADVISORY_COMMITTEE_CONTINUANCE",
                "S9_COMM_producer": "COMMEMORATION", "V9_COMM_REV": "COMMEMORATION",
                "S9_CLOSE_BOARD_producer": "OFFICE_CLOSING_AND_EMERGENCY_BOARD", "V9_CB_REV": "OFFICE_CLOSING_AND_EMERGENCY_BOARD"}
# use the last cumulative figure per agent
last = {}
for t in tele:
    if "subagent_tokens" in t or "subagent_tokens_cumulative" in t:
        last[t["agent"]] = (t.get("subagent_tokens_cumulative") or t.get("subagent_tokens"), t.get("duration_ms_cumulative") or t.get("duration_ms"))
for a, (tk, ms) in last.items():
    f = agent_family.get(a)
    if f:
        tok[f] += tk
        dur[f] += ms
yield_rows = []
for (fam, ph), st in sorted(fam_stats.items()):
    yield_rows.append(dict(family=fam, phase=ph, **st))
fam_tot = collections.defaultdict(collections.Counter)
for (fam, ph), st in fam_stats.items():
    fam_tot[fam].update(st)
per_family = {}
for fam, st in fam_tot.items():
    t = tok.get(fam, 0)
    per_family[fam] = dict(st, subagent_tokens=t, agent_minutes=round(dur.get(fam, 0) / 60000, 1),
                           reviewed_determinate_per_100k_tokens=round(st["reviewed_determinate_substantive"] / t * 1e5, 2) if t else None,
                           review_error_rate=round(st["review_non_accept"] / st["reviewed"], 3) if st["reviewed"] else None,
                           review_correction_rate=round(st["review_corrections"] / st["reviewed"], 3) if st["reviewed"] else None)
wjson(os.path.join(OUT, "TELEMETRY.json"), {
    "per_family": per_family, "per_shard_phase": yield_rows, "raw_agent_log": tele,
    "retirement_confirmation_v1": {"accepted": 5, "subagent_tokens": 96854, "duration_ms": 196738},
    "token_note": "Subagent tokens are as reported by the harness at each agent's completion; coordinator tokens are not exposed. Agent minutes are summed agent durations (agents ran in parallel, so wall-clock is shorter).",
    "independence_note": "Producers and reviewers are separately instantiated subagents of the same model family, each with its own context; reviewers re-fetched sources themselves. They are not human reviewers.",
    "network_notes": open(os.path.join(S9, "NETWORK_NOTES.md")).read() if os.path.exists(os.path.join(S9, "NETWORK_NOTES.md")) else None,
})

# ------------------------------------------------------------------ rules, rulings, conflicts
rules = []
for sh in shard_names:
    for r in jl(os.path.join(S9, "shards", sh, "rules.jsonl")):
        rules.append(dict(r, shard=sh))
wjl(os.path.join(OUT, "rules/STAGE9_SHARD_RULES.jsonl"), rules)
for f in ("COORDINATOR_RULINGS.md", "PRODUCER_PROTOCOL.md", "REVIEWER_PROTOCOL.md"):
    shutil.copy2(os.path.join(S9, f), os.path.join(OUT, "rules", f))
conf = []
for base_dir, kind in ((os.path.join(S9, "shards"), "producer"), (os.path.join(S9, "reviews"), "reviewer")):
    for d in sorted(os.listdir(base_dir)):
        for r in jl(os.path.join(base_dir, d, "conflicts.jsonl")):
            conf.append(dict(r, reported_by=d, reporter_kind=kind))
for r in jl(os.path.join(S9, "COORD_CONFLICTS.jsonl")):
    conf.append(dict(r, reporter_kind="coordinator"))
for r in [
    {"instrument_id": "EO:9238", "conflict_type": "inherited_text_variant", "detail": "Hosted transcript spells 'Latte' once; not corrected."},
    {"instrument_id": "EO:11619", "conflict_type": "interpretive_dissent", "detail": "Non-limitation clause treated as a rule of construction (V8_RET, V9_RET_CONFIRM, V9_COORD); if operative, any-effect would be indeterminate."},
    {"instrument_id": "EO:3441,EO:8975,EO:8273", "conflict_type": "lead_scope", "detail": "Lead titles suggest civil-service scope; not researched."},
]:
    conf.append(dict(r, reporter_kind="coordinator_v1"))
wjl(os.path.join(OUT, "CONFLICT_LOG.jsonl"), conf)

# ------------------------------------------------------------------ owner checks for every researched ID
checks = []
for r in records:
    iid = r["instrument_id"]
    own, prom = ownership(iid)
    checks.append({"instrument_id": iid, "ownership_status": own, "promotable_scope": prom,
                   "stage8_substantive_effect": ledger[iid]["substantive_effect"],
                   "included_validated": ledger[iid].get("included_validated"),
                   "known_exclusion_hits": excl.get(iid, []), "in_stage8_unresolved_28": iid in unres28,
                   "astra_1181_manifest_check": "OPUS_STAGE8_ASSIGNMENT" if iid in FIVE else "NOT_POSSIBLE_MANIFEST_UNAVAILABLE"})
wjl(os.path.join(OUT, "checks/OWNER_AND_BASELINE_CHECKS.jsonl"), checks)

# ------------------------------------------------------------------ next family candidates from the latest ledger
done_ids = set(ids)
FAMS = [("tax_return_inspection", r"inspection of .*returns|tax returns"), ("alien_property", r"alien property"),
        ("eight_hour_suspension", r"eight-hour"), ("emergency_board", r"emergency board"),
        ("indian_trust_period_extension", r"trust periods?"),
        ("one_day_closing_or_holiday", r"ordered closed|closing of|excused from duty|half-?holiday|holiday"),
        ("advisory_committee_continuance", r"continuance of .*advisory"),
        ("panama_canal", r"canal zone|panama|isthm"), ("consular_or_diplomatic", r"consul|diplomatic|legation"),
        ("tariff_or_customs", r"tariff|customs|duty|preferences"),
        ("land_withdrawal_or_reservation", r"withdraw|reservation|reserved|public land|lands? (in|for)"),
        ("commission_or_committee", r"commission|committee|council|board")]
pool = [r for r in val if r["substantive_effect"] == "indeterminate" and not excl.get(r["instrument_id"])
        and r["instrument_id"] not in unres28 and r["instrument_id"] not in done_ids]
fc, fe = collections.Counter(), collections.defaultdict(list)
for r in pool:
    t = (r.get("title") or "").lower()
    for n, pat in FAMS:
        if re.search(pat, t):
            fc[n] += 1
            if len(fe[n]) < 5:
                fe[n].append(r["instrument_id"])
            break
wjson(os.path.join(OUT, "NEXT_FAMILY_CANDIDATES.json"), {
    "basis": "Stage 8 merged ledger (sha256 %s): validated rows still substantive=indeterminate, minus frozen V1-V5, Stage 8 Opus assignments, the 340, Stage 7 quarantine, the 28 Stage 8 unresolved IDs and every ID researched in Stage 9; first matching title pattern wins." % LEDGER_SHA,
    "pool_size": len(pool), "title_pattern_counts": dict(fc.most_common()), "examples": dict(fe),
    "scope_warning": "Astra's 1,181-ID manifest was not available; counts may include Astra-reserved IDs. Title patterns are discovery leads, not legal classes. Never bulk-expire Indian trust periods (25 U.S.C. 5102).",
    "measured_yield_this_stage": per_family,
})

# ------------------------------------------------------------------ evidence copy (text, metadata, small binaries)
skipped = []
MAX_TEXT = 256 * 1024
WINDOW = 3000
# every quote cited anywhere, keyed by file basename
quotes_by_file = collections.defaultdict(set)
for base_dir in (os.path.join(S9, "shards"), os.path.join(S9, "reviews")):
    for d in os.listdir(base_dir):
        for fn in ("evidence.jsonl", "reviews.jsonl"):
            for r in jl(os.path.join(base_dir, d, fn)):
                items = [r] + list(r.get("reviewer_evidence") or [])
                for e in items:
                    lf, q = e.get("local_file"), e.get("quote")
                    if lf and isinstance(q, str) and q:
                        quotes_by_file[os.path.basename(lf)].add(q)


def excerpt(sp, dp):
    """Write quote windows of a large text file; return number of quotes located."""
    text = open(sp, encoding="utf-8", errors="surrogateescape").read()
    spans = []
    for q in quotes_by_file.get(os.path.basename(sp), ()):
        start = 0
        while True:
            i = text.find(q, start)
            if i < 0:
                break
            spans.append((max(0, i - WINDOW), min(len(text), i + len(q) + WINDOW)))
            start = i + 1
    if not spans:
        return 0
    spans.sort()
    merged = [list(spans[0])]
    for a, b in spans[1:]:
        if a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    os.makedirs(os.path.dirname(dp), exist_ok=True)
    with open(dp + ".EXCERPTS.json", "w") as f:
        json.dump({"source_file": os.path.basename(sp), "source_sha256": sha(sp), "source_chars": len(text),
                   "note": "Character windows around every quoted passage; offsets are into the full extraction whose sha256 is given.",
                   "windows": [{"start": a, "end": b, "text": text[a:b]} for a, b in merged]}, f, ensure_ascii=False)
    return len(spans)


def copy_tree(src, dst):
    for root, _, files in os.walk(src):
        names = set(files)
        for f in files:
            sp = os.path.join(root, f)
            rel = os.path.relpath(sp, src)
            size = os.path.getsize(sp)
            dp = os.path.join(dst, rel)
            stem = os.path.splitext(f)[0]
            if f.endswith((".html", ".htm")) and (stem + ".txt") in names:
                skipped.append({"path": os.path.relpath(dp, OUT), "bytes": size, "sha256": sha(sp),
                                "note": "HTML original not packaged; its text extraction (.txt) and .meta.json are packaged"})
                continue
            if f.endswith(".txt") and size > MAX_TEXT:
                n = excerpt(sp, dp)
                skipped.append({"path": os.path.relpath(dp, OUT), "bytes": size, "sha256": sha(sp),
                                "note": f"large text extraction packaged as quote windows ({n} quote hits) in {f}.EXCERPTS.json" if n else "large text extraction with no cited quote; not packaged"})
                continue
            if f.endswith(TEXTLIKE) or size <= MAX_BINARY:
                dp = os.path.join(dst, rel)
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                shutil.copy2(sp, dp)
            else:
                skipped.append({"path": os.path.relpath(os.path.join(dst, rel), OUT), "bytes": size, "sha256": sha(sp),
                                "note": "original bytes not packaged (size); hash, URL and retrieval time are in the sibling .meta.json; text extraction packaged where made"})


for sh in shard_names:
    copy_tree(os.path.join(S9, "shards", sh), os.path.join(OUT, "evidence", "shards", sh))
for rv in sorted(os.listdir(os.path.join(S9, "reviews"))):
    copy_tree(os.path.join(S9, "reviews", rv), os.path.join(OUT, "evidence", "reviews", rv))
copy_tree(V1REV, os.path.join(OUT, "evidence", "v1_retirement", "reviews"))
copy_tree(V1LEADS, os.path.join(OUT, "evidence", "v1_retirement", "sources"))
wjl(os.path.join(OUT, "evidence/UNPACKAGED_LARGE_ORIGINALS.jsonl"), skipped)
os.makedirs(os.path.join(OUT, "code"), exist_ok=True)
shutil.copy2(os.path.abspath(__file__), os.path.join(OUT, "code", "build_stage9_v2.py"))
shutil.copy2(REPORT, os.path.join(OUT, "REPORT.md"))

man = []
for root, _, files in os.walk(OUT):
    for f in sorted(files):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, OUT)
        if rel != "MANIFEST.json":
            man.append({"path": rel, "sha256": sha(p), "bytes": os.path.getsize(p)})
man.sort(key=lambda x: x["path"])
wjson(os.path.join(OUT, "MANIFEST.json"), {"package": "OPUS_STAGE9_STATUS_DELTA", "version": 2,
                                            "built_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                            "inputs": {"stage8_ledger_sha256": LEDGER_SHA}, "files": man})
print(json.dumps({k: acct[k] for k in ("added_ACCEPTED_YES", "added_ACCEPTED_NO", "newly_accepted", "substantive_UNKNOWN_remaining", "numerator", "coverage_pct", "reviewed_determinate_held_for_ownership", "coverage_pct_if_ownership_cleared", "researched_ids")}, indent=1))
print(json.dumps(per_family, indent=1))
