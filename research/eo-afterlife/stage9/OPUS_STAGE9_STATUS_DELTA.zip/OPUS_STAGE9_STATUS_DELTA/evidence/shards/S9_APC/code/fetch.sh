#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
S=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/S9_APC
id="$1"; ext="$2"; url="$3"
out="$S/cache/$id.$ext"
ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
res=$(curl -sSL -A "Mozilla/5.0 (research; s9)" --max-time 180 -o "$out" -w '%{http_code}\t%{url_effective}\t%{content_type}' "$url")
code=$(echo "$res"|cut -f1); final=$(echo "$res"|cut -f2); ct=$(echo "$res"|cut -f3)
sha=$(sha256sum "$out"|cut -d' ' -f1)
python3 -I -c 'import json,sys; a=sys.argv; json.dump({"url":a[1],"final_url":a[2],"retrieved_utc":a[3],"http_status":int(a[4]),"content_type":a[5],"sha256":a[6],"method":"curl original bytes"},open(a[7],"w"),indent=1)' "$url" "$final" "$ts" "$code" "$ct" "$sha" "$S/cache/$id.meta.json"
echo "$id $code $ct $(stat -c%s "$out") $final"
