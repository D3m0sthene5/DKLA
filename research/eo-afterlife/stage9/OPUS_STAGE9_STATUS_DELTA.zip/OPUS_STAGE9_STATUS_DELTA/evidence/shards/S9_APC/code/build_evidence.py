import json, hashlib, sys, os
S = sys.argv[1]
C = os.path.join(S, 'cache')

SRC = {
 'twea_compilation_1920': ('Trading with the Enemy Act and amendments thereto, together with proclamations, executive orders, and orders issued by Frank L. Polk ... to and including November 25, 1919 (GPO 1920; Harvard Law Library copy scanned by Google), archive.org djvu OCR text', 'archived_copy_of_official_publication (archive.org OCR of GPO compilation; OCR errors)'),
 'ajil_2213147': ('American Journal of International Law, Supplement, Oct. 1918, Official Documents p. 295-296 (JSTOR Early Journal Content, archive.org djvu OCR)', 'hosted_transcript (contemporaneous journal reprint)'),
 'serialset_07464_sdoc65_435': ('S. Doc. 65-435, Alien Property Custodian Report ... calendar year 1918 and to the close of business on February 15, 1919 (Serial Set 7464), govinfo PDF text layer', 'official_publication (govinfo scan of Serial Set; OCR text layer)'),
 'serialset_08236_hdoc68_49_apc1923': ('H. Doc. 68-49, Annual Report of the Alien Property Custodian for the Year 1923 (Serial Set 8236), govinfo PDF text layer', 'official_publication (govinfo scan of Serial Set; OCR text layer)'),
 'serialset_08217_doc641': ('H. Doc. 67-641, Catalogue of the Public Documents of the Sixty-seventh Congress (Serial Set 8217), govinfo PDF text layer', 'index_only (official catalogue entry; not operative text)'),
 'govinfo_usrep272_1': ('United States v. Chemical Foundation, Inc., 272 U.S. 1 (1926), U.S. Reports, govinfo', 'official_publication'),
 'stat_40_459': ('Act of March 28, 1918, ch. 28, 40 Stat. 459, 460 (amending TWEA sec. 12), govinfo Statutes at Large', 'official_publication'),
 'stat_45_254': ('Settlement of War Claims Act of 1928, ch. 167, 45 Stat. 254, govinfo Statutes at Large', 'official_publication'),
 'govinfo_uscode2024_50_4312': ('50 U.S.C. 4312 (TWEA sec. 12), United States Code 2024 edition, govinfo', 'official_publication'),
 'app_eo6694': ('Executive Order 6694 (May 1, 1934), American Presidency Project', 'hosted_transcript'),
 'app_eo9788': ('Executive Order 9788 (Oct. 14, 1946), American Presidency Project', 'hosted_transcript'),
 'fr_1947_04_18': ('Federal Register Vol. 12, No. 77, April 18, 1947 (vesting order re zu Lynar), govinfo', 'official_publication'),
 'alien_enemies_1921': ('Alien enemies and property rights under the Trading with Enemy Act (1921), archive.org djvu OCR', 'secondary_treatise (list of orders; not operative text)'),
}

E = []
def ev(eid, sid, quote, locator, supports):
    E.append((eid, sid, quote, locator, supports))

# ---- operative texts
ev('E01','serialset_07464_sdoc65_435','50 hogsheads, more or less, of tobacco: property of Schilling and Burning, Bremen,','S. Doc. 65-435 appendix, EO [No. 2843.], p. 522-523 (txt line ~31151)','EO 2843 operative grant: private sale of 50 hogsheads of tobacco of Schilling and Bruning (OCR "Burning"); signed 24 April 1918')
ev('E02','twea_compilation_1920','[No. 2843.]','1920 GPO compilation p. 46 (txt line 2967)','Second copy of EO 2843 complete text (number, grant, reasons, signature 24 April 1918)')
ev('E03','serialset_07464_sdoc65_435','279,232 pounds, more or less, of nickel: property of Hammar and Company, Hamburg,','S. Doc. 65-435 appendix, EO [No. 2858.], p. 523-524 (txt line 31228)','EO 2858 operative grant: private sale of 279,232 lb nickel of Hammar & Co.')
ev('E04','serialset_07464_sdoc65_435','              9 May, 1918.','S. Doc. 65-435 p. 524 (signature block of No. 2858)','EO 2858 signature date is 9 May 1918 (ledger says 1918-05-07)')
ev('E05','ajil_2213147','iNo. 2858.','AJIL Supp. Oct. 1918 p. 295 footnote 1','Independent reprint numbers the 9 May 1918 nickel order as No. 2858')
ev('E06','serialset_07464_sdoc65_435','The Alien Property Custodian is hereby authorized to sell at private sale, without\n public or other advertisement, certain real estate now being held and administered\n by him as such Custodian','S. Doc. 65-435 appendix, EO [No. 2953.] (txt line 31928-31930)','EO 2953 operative grant: private sale of real estate held as property of Lilly Busch')
ev('E07','serialset_07464_sdoc65_435','(c) Said proposed sale is an advantageous one, and said Lilly Busch has consented','S. Doc. 65-435, EO 2953 reasons (txt line 32006)','EO 2953 reasons: pending offer; owner consent; section 9 petition pending')
ev('E08','serialset_07464_sdoc65_435','Now, therefore, IT hereby declare the said sale to be void and of no effect, and’1\n  hereby authorize and direct the Alien Property Custodian to reject all bids received','S. Doc. 65-435 appendix p. 541, EO [No. 2954.]','EO 2954 operative clauses: declaration that the 1918 Manila sale of Froehlich & Kuttner is void; direction to reject all bids')
ev('E09','twea_compilation_1920','[No. 2954.]','1920 GPO compilation p. 66 (txt line 4311)','Second copy of EO 2954 complete text, dated 13 September 1918')
ev('E10','twea_compilation_1920','The Alien Property Custodian may sell at private sale without public or other \nadvertisement to The Chemical Foundation (Inc.), a corporation organized ','1920 GPO compilation p. 92-93, Polk order of 26 Feb 1919 (txt line 6864-6865)','EO 3016C operative sale clause (order signed by Frank L. Polk under EO 3016 delegation)')
ev('E11','twea_compilation_1920','the Alien Property Custodian may seize or may have seized under the provi- \nsions of the said trading with the enemy act and the amendments thereto now \nor hereafter enacted and which he from time to time shall determine relate to ','1920 GPO compilation p. 93 (txt lines 6876-6878)','EO 3016C prospective clause: covers property the APC "may seize" under TWEA as now or hereafter amended, determined from time to time')
ev('E12','twea_compilation_1920','The Alien Property Custodian may release and discharge the United States \nof America and any department thereof upon such terms and conditions as to ','1920 GPO compilation p. 92 (txt lines 6858-6859)','EO 3016C clause 1: permission to release the United States from infringement claims')
ev('E13','twea_compilation_1920','Done in the District of Columbia this the 26th day of February, in the year ','1920 GPO compilation p. 93','EO 3016C dated 26 Feb 1919, signed Frank L. Polk')
ev('E14','twea_compilation_1920','V. I hereby vest in Frank L. Polk all power and authority conferred upon ','1920 GPO compilation p. 72, EO No. 3016 (Dec. 3, 1918) para. V','Source of authority for 3016C and 3016N: presidential delegation of TWEA sec. 12 power to Frank L. Polk')
ev('E15','twea_compilation_1920','to transfer, dispose of, release, surrender, and quitclaim to Ludwig Vogelstein, ','1920 GPO compilation p. 102 (Polk order of 18 April 1919)','EO 3016N operative clause: transfer/release to Ludwig Vogelstein of rights in 50,000 shares of L. Vogelstein & Co.')
ev('E16','twea_compilation_1920','stock of L. Vogelstein & Company, Inc., or any part thereof from passing into \nGerman hands or into German control for such period as may seem proper to \nthe Alien Property Custodian. ','1920 GPO compilation p. 103','EO 3016N ancillary power: arrangements to keep the shares out of German control for such period as the APC deems proper')
ev('E17','twea_compilation_1920','Done in the District of Columbia this 18th day of April, in the year x>t Our ','1920 GPO compilation p. 103','EO 3016N dated 18 April 1919, signed Frank L. Polk')
ev('E18','twea_compilation_1920','"Lot 77 in Franz A. R. Jung\'s subdivision in Square 159, as per plat of ','1920 GPO compilation p. 84 (txt line 6192)','EO 3150 operative grant: private sale of Lot 77, Square 159, Washington D.C.')
ev('E19','twea_compilation_1920','(c) That said Franz A. R. Jung and Sophie A. Nordhoff Jung have ex- ','1920 GPO compilation p. 84','EO 3150 reasons: owners approved private sale at offered price; signed 16 Aug 1919 (no order number printed)')
# ---- execution / disposition
ev('E20','govinfo_usrep272_1','from time to time commencing April 10, 1919, executed\nand delivered to the Foundation various assignments of\nthe patents. The considerations paid by the Foundation\nto the Custodian amounted in all to $271,850.00.','272 U.S. 1, 8 (1926)','EO 3016C sale executed by assignments from April 10, 1919')
ev('E21','govinfo_usrep272_1','We agree with the lower courts that the sales and trans-\nfers of the patents were ratified and confirmed by the\nPresident’s order of February 13, 1920.','272 U.S. 1, 15 (1926)','Sales under the Polk orders ratified by the President and upheld by the Supreme Court')
ev('E22','serialset_08236_hdoc68_49_apc1923','   Disposition: All stock pledged pending an accounting, and trustees’returned\nstock upon payment to Alien Property Custodian by American debtor.','H. Doc. 68-49 (1923 APC report), corporations list, L. Vogelstein & Co. (Inc.)','EO 3016N executed: trustees returned the stock upon payment to the APC by the American debtor')
ev('E23','serialset_08236_hdoc68_49_apc1923','L. Vogelstein & Co. allowed Oct. 11, 1920.','H. Doc. 68-49, claims list','Claim of L. Vogelstein & Co. allowed 11 Oct 1920')
ev('E24','serialset_08236_hdoc68_49_apc1923','2924 | Sofie A. N. Jung; allowed Dec. 2, 1920.','H. Doc. 68-49, claims list','Claim of Sofie A. N. Jung allowed (property-specific scope not shown)')
ev('E25','serialset_08236_hdoc68_49_apc1923','2925 | Franz A. K. Jung; allowed Dec. 9, 1620.','H. Doc. 68-49, claims list (OCR "K."/"1620")','Claim of Franz A. R. Jung (OCR) allowed Dec. 1920 (property-specific scope not shown)')
ev('E26','serialset_07464_sdoc65_435','Lilly Busch.    vs ooaivaacs Ownership...           8, 500,000.00 | Application to Attor- | Allowed.','S. Doc. 65-435, Bureau of Law, claims filed under section 9 (txt line 28393)','Lilly Busch ownership claim (est. $8.5M) allowed on application to Attorney General')
ev('E27','serialset_08236_hdoc68_49_apc1923','Mrs. Lilly Busch; suits under sec. 9.','H. Doc. 68-49, claims list','A further Lilly Busch claim was in suit under sec. 9 (not all her property returned by claim allowance)')
ev('E28','serialset_08236_hdoc68_49_apc1923','284 | Lillie Busch; allowed Dec. 6, 1918.','H. Doc. 68-49, claims list','Busch claim no. 284 allowed 6 Dec 1918')
ev('E29','serialset_08236_hdoc68_49_apc1923','Schilling & Bruning; allowed Nov. 22,','H. Doc. 68-49, claims list','Schilling & Bruning claim allowed 22 Nov 1923 (scope/amount not shown)')
ev('E30','serialset_08236_hdoc68_49_apc1923','7838   | Hammar & Co. (Ltd.); pending.','H. Doc. 68-49, claims list','Hammar & Co. (Ltd.) claim still pending end of 1923')
ev('E31','serialset_07464_sdoc65_435','More than 1,500,000 pounds of nickel and several hundred thousand\npounds of ferrovanadium were turned over to the Ordnance Depart-\nment','S. Doc. 65-435 p. 13 (txt line 260)','Aggregate (not owner-specific) report that enemy nickel was turned over to Ordnance')
# ---- index-only for 3639A and later orders
ev('E32','serialset_08217_doc641','give perpetual lease of certain real estate','H. Doc. 67-641 Document Catalogue, entry MANDRUP DE LYNAR (txt line 112265)','Index-only: EO 3639A authorizes a perpetual lease of Columbus, Ohio real estate to Swan Company; 12 p.; Feb. 21, 1922')
ev('E33','serialset_08217_doc641','Columbus, Ohio, to Swan Company].','H. Doc. 67-641 Document Catalogue','Index-only: lessee Swan Company; location Columbus, Ohio')
ev('E34','fr_1947_04_18','gations owing to Graf George zu Lynar,','12 FR 2542 (Apr. 18, 1947), vesting order','Lead: in 1946-47 the Office of Alien Property vested debts owed to the zu Lynar family by a Columbus, Ohio bank trust department (suggests continuing Columbus income; lease link not stated)')
ev('E35','fr_1947_04_18','Huntington  National    Bank  of','12 FR 2542','Lead: obligor is Huntington National Bank of Columbus (trust department voucher Dec. 5, 1946)')
# ---- controlling law
ev('E36','stat_40_459','or of any part thereof, by sale or otherwise, and exercise any rights','40 Stat. 460 (Act of Mar. 28, 1918, amending TWEA sec. 12)','Controlling authority: APC disposition power by sale or otherwise under the President')
ev('E37','stat_40_459','reasons therefor, in the public interest shall otherwise determine:','40 Stat. 460','Private sale only on presidential determination stating reasons')
ev('E38','govinfo_uscode2024_50_4312','or make any disposition thereof or of any part thereof, by sale or otherwise, and exercise any rights or powers which may be or become appurtenant thereto','50 U.S.C. 4312 (2024 ed.)','TWEA sec. 12 sale power remains codified (no repeal of the authorizing statute)')
ev('E39','govinfo_uscode2024_50_4312','Functions vested by law in Alien Property Custodian and Office of Alien Property Custodian transferred to Attorney General by Reorg. Plan No. 1 of 1947','50 U.S.C. 4312 note','Successor actor: Attorney General')
ev('E40','app_eo6694','1. The Office of the Alien Property Custodian is abolished, and the authority, rights, privileges, powers, and duties conferred and imposed on the Alien Property Custodian by law and/or Executive order are transferred to the Department of Justice','EO 6694 para. 1','1934: office abolished but EO-conferred powers transferred, not terminated (no ending of unexecuted authorizations)')
ev('E41','app_eo9788','all authority, rights, privileges, powers, duties, and other functions vested in such Office or in the Alien Property Custodian or transferred or delegated thereto are hereby vested in or transferred or delegated to the Attorney General','EO 9788 para. 1','1946: functions transferred to Attorney General')
ev('E42','stat_45_254','(3) Any patent (or any right therein or claim thereto, and','45 Stat. 254 (Settlement of War Claims Act 1928) sec. 3','1928 Act compensates German owners for patents sold by the Custodian (treats such sales as completed; counter-check for 3016C)')
ev('E43','serialset_08236_hdoc68_49_apc1923','authorized the custodian to return to former owners all property in a\ntrust valued at $10,000 and under','H. Doc. 68-49, letter of transmittal p. VI-VII','Winslow Act of March 4, 1923 returns (context for claims allowed in 1923)')
ev('E44','alien_enemies_1921','April 24, 1918. Private sale of property of Schilling & ','1921 treatise p. 272 list','Secondary list confirms Apr. 24, 1918 Schilling order (index-level)')

out=[]
bad=[]
for eid,sid,quote,loc,sup in E:
    txtp=os.path.join(C,sid+'.txt')
    t=open(txtp,encoding='utf-8',errors='replace').read()
    if quote not in t:
        bad.append(eid); continue
    m=json.load(open(os.path.join(C,sid+'.meta.json')))
    title,grade=SRC[sid]
    out.append({'evidence_id':'S9_APC:'+eid,'source_id':sid,'source_title':title,'url':m['url'],'final_url':m.get('final_url'),
        'retrieved_utc':m['retrieved_utc'],'local_file':'cache/'+sid+'.txt',
        'local_file_sha256':hashlib.sha256(open(txtp,'rb').read()).hexdigest(),
        'original_bytes_file':[f for f in os.listdir(C) if f.startswith(sid+'.') and not f.endswith(('.txt','.meta.json'))] or ['cache/'+sid+'.txt (original bytes are the djvu text)'],
        'original_bytes_sha256':m['sha256'],
        'quote':quote,'locator':loc,'retrieval_method':m['method']+(('; '+m['text_extraction']) if 'text_extraction' in m else ''),
        'evidence_grade':grade,'supports':sup})
print('bad',bad)
with open(os.path.join(S,'evidence.jsonl'),'w') as f:
    for r in out: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(len(out))
