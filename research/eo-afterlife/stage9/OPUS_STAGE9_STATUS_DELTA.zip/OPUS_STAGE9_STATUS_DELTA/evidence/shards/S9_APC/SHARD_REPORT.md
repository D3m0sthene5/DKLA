# S9_APC shard report (pilot: single-transaction Alien Property Custodian orders, 1918-1924)

Producer: opus (S9_APC). Codebook 2.0.0, cutoff 2026-10-14 America/New_York.
**Actual UTC start:** 2026-10-16T16:33:56Z (`date -u` at setup). **Actual UTC end:** see last line of this file.
Ownership: all 10 IDs OWNERSHIP_NOT_VERIFIED. Decisions are made in full but cannot be promoted.

## Counts

| Proposed (substantive / any) | IDs |
|---|---|
| no / no | 2: EO:2954 (self-executing annulment of a 1918 Manila sale), EO:3016N (Vogelstein share transfer, executed per 1923 APC report) |
| indeterminate / indeterminate | 8: EO:2843, 2858, 2953, 3150 (text in hand, sale or return not proved for the specific property); EO:3016C (sale executed and upheld in 272 U.S. 1, but a forward-looking clause has no proved end); EO:3456, 3639A, 4007 (operative text not obtained) |
| yes | 0 |

- Texts obtained: 7 of 10. Six come from official publications: S. Doc. 65-435 (Serial Set, govinfo) for 2843, 2858, 2953 and 2954, and the GPO 1920 compilation of TWEA orders for 3016C, 3016N and 3150. The compilation copy is the archive.org OCR of the Google scan, so evidence is graded `archived_copy_of_official_publication`. The seventh is AJIL as a second copy for 2858.
- Not obtained: EO:3456, EO:3639A and EO:4007. 3639A has only an index entry in the official Document Catalogue of the 67th Congress; 3456 and 4007 have nothing better than a ledger title.
- Footprints complete: 6 (2843, 2858, 2953, 2954, 3016N, 3150). Incomplete: 3016C (the text of the 13 Feb 1920 ratifying order was not retrieved), 3456, 3639A, 4007.
- Rules: S9_APC_R1_executed_single_transaction covers [EO:3016N]. S9_APC_R2_self_executing_annulment covers [EO:2954]. Each order was checked against the rule's predicates on its own text (TC16).
- Conflicts logged: 5. The main ones are:
  - EO 2858 was signed 9 May 1918, not 7 May.
  - 3016C and 3016N are orders by Frank L. Polk under the EO 3016 delegation, not orders the President signed.
  - The 3150 text in the compilation carries no number.

## Answer to the pilot question

Single-sale APC orders **cannot be closed repeatably** from published records.

The operative text is cheap for 1918-1919 orders. Two sources print them in full: the APC 1919 report (S. Doc. 65-435) and the GPO 1920 compilation (orders to 25 Nov 1919). Each order then needs about 3-5 minutes.

Proof that an order was carried out is the bottleneck:
- The APC annual reports for 1919, 1922, 1923 and 1925 list sales by commodity in totals, not by owner. For example, ">1,500,000 pounds of nickel ... turned over to the Ordnance Department" does not show whether the Hammar lot was among it.
- The claim lists show that an owner's claim was "allowed" (Jung, Schilling & Bruning, Busch, L. Vogelstein & Co.) but not which property was returned.

Closure only worked in two cases:
- **Per-trust disposition line:** EO 3016N, where the 1923 report says the trustees returned the stock on payment.
- **Self-executing order:** EO 2954, which voided a sale by its own terms.

The Supreme Court case proves the Chemical Foundation sale (3016C) was carried out. The order still stays open, because it also allows sales of property the custodian "may seize ... from time to time" under the Act "now or hereafter enacted".

Legally, an authorization that was never carried out does **not** lapse:
- TWEA sec. 12 is still codified at 50 U.S.C. 4312.
- EO 6694 (1934) and EO 9788 (1946) transferred powers granted by executive order to the Attorney General; they did not end them.

So each sale order needs proof tied to the specific property: either it was sold, or it was returned.

**Cost:** about 28 minutes of research in total for 10 orders, plus about 10 minutes writing up. Per order:
- About 3-5 minutes when the text is in a compilation and a per-trust record exists.
- More than 10 minutes with no result when proof of execution has to come from deed records or archive files. I stopped under the pivot rule (no point in going past about 30 minutes per order).

Time per order is an **allocation of shared phases**, since one search usually served several orders:
- 16:34-16:41, finding texts (APP, archive.org, AJIL, 1920 compilation): about 1 minute each for 2843, 2858, 2953, 2954, 3016C, 3016N and 3150.
- 16:37-16:47, working down the source ladder for 3456, 3639A and 4007: about 3-4 minutes each, no text.
- 16:41-16:58, law and proof of execution:
  - 3016C (272 U.S. 1): about 3 minutes.
  - Serial Set reports: about 2 minutes each for 2843, 2858, 2953, 3016N and 3150.
  - 2954: about 1 minute.
- 16:54-16:58, finding the 3639A index entry and the 1947 vesting order: about 3 minutes.

## Main findings and blockers

- **3639A (perpetual lease, the designed counterexample).** The official catalogue confirms No. 3639A, 21 Feb 1922, 12 pages: a perpetual lease of Columbus, Ohio land owned by the Mandrup de Lynar family to Swan Company.
  - A 1947 vesting order (12 FR 2542) seized money that the Huntington National Bank trust department in Columbus owed the zu Lynar family in 1946. That fits ongoing Columbus income, but the lease is not named.
  - If the lease was signed it is a continuing property interest (a TC07 durable_disposition candidate). It has to stay open until someone has the 12-page text and the Franklin County lease record.
- **3016C.** Clauses that look forward with no stated end mean this is not a pure single sale. Open questions:
  - whether The Chemical Foundation, Inc. still exists;
  - whether any trademarks or rights seized under the Act are still in federal hands;
  - what the Winslow Act of 1923 says about returning unsold patents (seen only in the APC's summary).
- **New legal blocker (applies to the whole family):** offices were abolished but powers were transferred, not ended. Age, the custodian office ending, and Polk's death therefore cannot close an authorization that was never carried out.

## Retrieval log (the standing rule's source ladder)

Successful downloads are listed in `cache/*.meta.json`: URL, final URL, retrieval time, HTTP status, sha256, and how text was extracted. Failed or blocked attempts:

1. **APP** (presidency.ucsb.edu):
   - Quoted-number searches for all 10 orders: no results.
   - Keyword searches on party names, with and without date filters: no results.
   - Full list of APP executive orders mentioning "Alien Property Custodian" (3 pages): none of the 10 packet orders appear.
   - APP does not host these orders.
2. **mocat.library.unt.edu** (Monthly Catalog index, which is index-only anyway):
   - curl: 403 Access Denied.
   - WebFetch: DNS failure.
   - Playwright Chromium: 403.
3. **HathiTrust** (the full-view APC 1919 report, catalog 001756793, and full-text search):
   - curl and Playwright both hit a Cloudflare challenge page; not defeated.
   - WebFetch: DNS failure.
   - The Bib API returned 403.
   - Got around this by using the same report from the govinfo Serial Set (official).
4. **Google Books:**
   - API: quota 0 (429).
   - books.google.com: 302 redirect to a block page.
   - The /books/feeds endpoint: 500.
5. **Wayback Machine** (CDX lookups for the HathiTrust record, mocat entries and APP slugs): connection reset 6 times. The proxy status says the upstream closed the tunnel, which looks like rate limiting. Earlier there was one 429.
6. **NARA catalog:**
   - API v2 needs a key (returned the app's HTML page).
   - The website rendered in Playwright returned only irrelevant results for "Lynar" and "Executive Order 4007".
   - www.archives.gov is blocked by the proxy policy (403 on connect, per proxy status).
7. **uscode.house.gov:** a 200 "site under maintenance" page. Used the govinfo USCODE-2024 edition of 50 U.S.C. 4312 instead (Cornell LII also returned 200).
8. **govinfo:**
   - The search API with DEMO_KEY was rate-limited.
   - The govinfo website rendered in Playwright worked. It found the Serial Set APC reports (1919, 1922, 1923, 1925) and the 67th Congress Document Catalogue.
   - The 1924 report (S. Doc. 68-203, 237 MB) and S. Doc. 67-181 (491 MB) were not downloaded, under the pivot rule.
9. **archive.org:**
   - Advanced search found the 1920 GPO compilation and the AJIL 1918 reprints.
   - No later edition of the compilation was found (the 1920 edition stops at 25 Nov 1919, so it misses 3456, 3639A and 4007).
   - The full-text search API refused the parameters used.
10. **WebSearch** (to find leads only): turned up Monthly Catalog snippets for 3639A (Swan Company, Columbus) and 4007 (sale on the New York Stock Exchange of 97,295 shares). These are index-level and were not stored as evidence for 4007.

Playwright-rendered search pages (`cache/hathi_ls_*`, `mocat_pw_*`, `nara_*`, `govinfo_search_*`) are kept as an attempt log only. They have no meta files and are not used as evidence.

The cache is about 1 GB because the protocol requires keeping the original bytes of the large Serial Set PDFs.

Scripts are in `code/`: fetch.sh, html2txt.py, pw.js, build_evidence.py, build_outputs.py. All quotes are checked as exact substrings of the cached `.txt` files.

**Actual UTC end:** 2026-10-16T17:02:00Z
