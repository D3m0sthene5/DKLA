import json, os, sys
S = sys.argv[1]
OWN = "OWNERSHIP_NOT_VERIFIED (Astra 1,181 manifest unavailable): research and review fully, but the decision cannot be promoted"
P = lambda x: 'S9_APC:' + x
LAW = [P('E36'), P('E37'), P('E38'), P('E39'), P('E40'), P('E41')]
SEARCHED_COMMON = [
  "APP advanced search: order number (quoted), party names, 'Alien Property Custodian' (all APP EOs mentioning APC listed: none of the 10 packet orders hosted; no later order naming these numbers)",
  "APP EO 12553 (1986 revocation list) grep: none of the packet numbers",
  "EO 6694 (1934), EO 9788 (1946), 50 U.S.C. 4312 + notes (2024 ed.)",
  "1920 GPO compilation of TWEA orders to Nov. 25, 1919 (archive.org)",
  "APC reports in Serial Set: S. Doc. 65-435 (1919), H. Doc. 67-525 (1922), H. Doc. 68-49 (1923), S. Doc. 69-94 (1925) full-text grep for party names",
  "Settlement of War Claims Act 1928, 45 Stat. 254 (grep patents/return provisions)",
]
SAV_SALE = ("TWEA sec. 12 (50 U.S.C. 4312) still authorizes disposition; EO 6694 (1934) and EO 9788 (1946) transferred, not terminated, "
            "APC powers conferred by Executive order, so an UNEXECUTED authorization would have passed to the Attorney General. "
            "Hence the only end points are execution (spent, TC07) or loss of the object from federal custody (return under sec. 9 / Winslow Act / 1928 Act). "
            "Owner claims and 1928 Act awards are compensation/return mechanisms, not savings of the order.")

def rec(iid, fam, sub, any_, fp, comp, txt, grade, ctrl, sc_find, sav, rule, evs, conf, hold, infer, extra_searched=()):
    return {"instrument_id": iid, "shard_id": "S9_APC", "family": fam, "proposal_id": "opus:s9:status:" + iid,
            "proposed_substantive_effect": sub, "proposed_any_operative_effect": any_,
            "operative_footprint": fp, "footprint_complete": comp, "text_obtained": txt, "text_source_grade": grade,
            "controlling_authority_evidence_ids": ctrl,
            "subsequent_change_check": {"searched": SEARCHED_COMMON + list(extra_searched), "findings": sc_find},
            "savings_or_residual_considered": sav, "rule_id": rule, "evidence_ids": evs, "confidence": conf,
            "hold_reason": hold, "what_remains_inferential": infer, "ownership_status": OWN,
            "producer_state": "producer_supported_pending_independent_review"}

def cl(clause, actor, obj, auth, cond, end_date, end_basis, ev):
    return {"clause": clause, "actor": actor, "object": obj, "authority": auth, "time_or_condition": cond,
            "end": {"date": end_date, "basis": end_basis}, "evidence_ids": ev}

FAM = "APC single-transaction order (TWEA sec. 12)"
A12 = "TWEA sec. 12 as amended Mar. 28, 1918 (40 Stat. 460)"
R = []

R.append(rec("EO:2843", FAM, "indeterminate", "indeterminate",
 [cl("Authorizes APC to sell at private sale, without advertisement, 50 hogsheads of tobacco of Schilling and Bruning (Bremen) taken off the bark Metador, stored in General Stores NYC; in lots, place/terms at APC discretion",
     "Alien Property Custodian (now Attorney General)", "50 hogsheads tobacco, Schilling & Bruning", A12,
     "no time limit; reasons: dock congestion, avoid expense", None,
     "unproven: no owner-specific sale record found; claim of Schilling & Bruning allowed 22 Nov 1923 (scope unknown)", [P('E01'), P('E02'), P('E29')]),
  cl("Statement of reasons (statutory precondition for private sale)", "President", "-", A12, "satisfied at signing 24 Apr 1918", "1918-04-24", "non-operative recital; satisfied", [P('E01')])],
 True, True, "official_publication", LAW,
 "No amending/revoking order found. 1919 APC report lists the order but its sales schedules are aggregated by commodity (no Schilling & Bruning line). 1923 report: Schilling & Bruning claim allowed Nov. 22, 1923.",
 SAV_SALE, None, [P('E01'), P('E02'), P('E29'), P('E44')] + LAW, "medium",
 "Missing fact: whether the 50 hogsheads were sold under this order (or returned) so the permission is spent/without object. Would settle: APC Bureau of Sales trust file / sale report for Schilling & Bruning (NARA RG 131, Office of Alien Property, WWI trust and claim files; claim no. ~5000 allowed 22 Nov 1923), or APC report sale schedule naming the owner.",
 "Execution is highly probable (perishable goods, dock-congestion rationale, later claim allowance) but no record ties a sale or return to these 50 hogsheads."))

R.append(rec("EO:2858", FAM, "indeterminate", "indeterminate",
 [cl("Authorizes APC to sell at private sale 279,232 lb nickel of Hammar & Co. (Hamburg), Hammar & Co. Ltd. (Stockholm) and unknown enemies, held by American Dock Co., Tompkinsville; to manufacturers designated by Ordnance Dept.",
     "Alien Property Custodian (now Attorney General)", "279,232 lb nickel", A12, "no time limit", None,
     "unproven: aggregate report that >1.5M lb enemy nickel went to Ordnance; Hammar & Co. (Ltd.) claim still pending end-1923", [P('E03'), P('E04'), P('E05'), P('E31'), P('E30')])],
 True, True, "official_publication", LAW,
 "No amending/revoking order found. 1919 report: nickel 'sold to Ordnance Department' lines and aggregate statement, none owner-specific. 1923 report: Hammar & Co. (Ltd.) claim pending.",
 SAV_SALE, None, [P('E03'), P('E04'), P('E05'), P('E30'), P('E31')] + LAW, "medium",
 "Missing fact: owner-specific proof that the Hammar nickel was sold (Ordnance designation) or otherwise left federal custody, and disposition of Hammar & Co. (Ltd.) claim no. 7838. Would settle: APC trust/sale file for Hammar & Co. (NARA RG 131) or a later APC report/claims list showing claim 7838 disposition.",
 "Sale to Ordnance-designated buyers is very likely given the aggregate statement, but not shown for this lot."))

R.append(rec("EO:2953", FAM, "indeterminate", "indeterminate",
 [cl("Authorizes APC to sell at private sale described Manhattan real estate (Northern Ave/Riverside Drive at W. 181st St.) held as property of Lilly Busch",
     "Alien Property Custodian (now Attorney General)", "Riverside Drive / Northern Ave parcel, Lilly Busch", A12,
     "pending offer 'must be accepted at once'; owner consented; sec. 9 petition pending", None,
     "unproven: Busch ownership claim allowed (Dec. 6, 1918) but other Busch claims were in sec. 9 suits; no deed/sale record found", [P('E06'), P('E07'), P('E26'), P('E27'), P('E28')])],
 True, True, "official_publication", LAW,
 "No amending/revoking order found. Claims lists show claim 284 (Lillie Busch) allowed Dec. 6, 1918 and later 'Mrs. Lilly Busch; suits under sec. 9'.",
 SAV_SALE + " If not sold before the Dec. 1918 claim allowance, return to Busch would also end the object, but the claim's property scope is not shown.",
 None, [P('E06'), P('E07'), P('E26'), P('E27'), P('E28')] + LAW, "medium",
 "Missing fact: whether the parcel was conveyed by the APC under this order or returned to Lilly Busch. Would settle: NYC Register (Manhattan) conveyance libers 1918-1919 for the Riverside Drive/W.181st St. parcel (grantor Alien Property Custodian), or the APC/Busch sec. 9 claim file (NARA RG 131).",
 "Either sale or return ends the object; neither is proved for this parcel."))

R.append(rec("EO:2954", FAM, "no", "no",
 [cl("Declares the May 1918 Manila sale of Froehlich & Kuttner to Compania Mercantil de Filipinas void and of no effect",
     "President", "1918 sale of Froehlich & Kuttner", A12 + " (proviso: reject bids on presidential order with reasons)",
     "self-executing on signature", "1918-09-13", "completed annulment at signing (TC07 spent dispositive act); no continuing status beyond historical voidness", [P('E08'), P('E09')]),
  cl("Authorizes and directs APC to reject all bids received at that sale, incl. Compania Mercantil de Filipinas",
     "Alien Property Custodian", "bids at the voided May 1918 Manila sale", A12, "one-time act; no deadline", "1918-09-13",
     "object extinguished: the order itself voided the sale the bids belonged to, so no bid remains capable of acceptance; rejection is a finite act", [P('E08')])],
 True, True, "official_publication", LAW + [P('E36'), P('E37')],
 "No amending/revoking order found; 1919 APC report lists 'Canceling sale of Froelich & Kuttner' among orders and reprints text. Order's reasons say the firm should be liquidated under a War Trade Board license (no command in this order to do so).",
 "Considered: (a) whether a direction to reject bids survives as a continuing command (TC10) - no live object after the annulment; (b) whether voidness is a durable status (TC06) - it is a historical consequence, excluded by TC04; (c) the reasons' reference to WTB-license liquidation is a recital, not a command of this order.",
 "S9_APC_R2_self_executing_annulment", [P('E08'), P('E09')] + LAW, "medium", None,
 "That the bid-rejection direction is spent rests on reading the annulment as self-executing; actual APC rejection letters were not retrieved."))

R.append(rec("EO:3016C", FAM, "indeterminate", "indeterminate",
 [cl("Permits APC to release and discharge the United States from claims for infringement of the patents/trade-marks referred to",
     "Alien Property Custodian (now Attorney General)", "infringement claims against the United States re the covered patents/trade-marks", "TWEA sec. 12 via EO 3016 para. V delegation to Frank L. Polk",
     "no time limit", None, "unproven: exercise not documented; covered WWI patents long expired (inferential)", [P('E12'), P('E14')]),
  cl("Permits APC to sell at private sale to The Chemical Foundation (Inc.) all letters patent, trade-marks and rights (incl. past-infringement damages) which the APC 'may seize or may have seized' under TWEA 'now or hereafter enacted' and from time to time determines relate to the Foundation's purposes",
     "Alien Property Custodian (now Attorney General)", "seized enemy patents/trade-marks relating to chemical industry", "TWEA sec. 12 via EO 3016 para. V",
     "prospective: future seizures and determinations 'from time to time'", None,
     "executed for the 1919-1920 assignments (from Apr. 10, 1919; $271,850), ratified by the President Feb. 13, 1920, upheld 272 U.S. 1 (1926); prospective part has no proved end", [P('E10'), P('E11'), P('E13'), P('E20'), P('E21')])],
 False, True, "official_publication", [P('E14')] + LAW,
 "Ratifying presidential order of Feb. 13, 1920 (per 272 U.S. 1) confirms past sales; Supreme Court upheld sales (1926); Settlement of War Claims Act 1928 compensates for sold patents. No revocation of the Polk order found.",
 "Executed assignments are spent dispositive acts (TC07); the Foundation's title is a historical consequence (TC04). Residual: the prospective permission covers property the APC 'may seize' under TWEA as amended 'hereafter', with no stated end; TWEA vesting power and the successor (Attorney General) still exist; whether The Chemical Foundation, Inc. still exists and whether any TWEA-vested trade-mark/right is held is unknown. The April 5, 1919 Polk order (copyrights) is a separate instrument.",
 None, [P('E10'), P('E11'), P('E12'), P('E13'), P('E14'), P('E20'), P('E21'), P('E42')] + LAW, "medium",
 "Missing facts for the prospective clauses: (1) whether The Chemical Foundation, Inc. (Delaware) still exists (Delaware Division of Corporations entity record); (2) whether any TWEA-vested patent/trade-mark/right remains in federal custody (Treasury OFAC/DOJ records of residual TWEA vested property); (3) text of the Act of March 4, 1923 (Winslow Act) proviso on return of unsold patents (42 Stat. 1511) and the Feb. 13, 1920 ratifying order to see whether they closed the authorization. Footprint marked incomplete because the 1920 ratification order text was not retrieved.",
 "The 1919-1920 sales are proved; the dormant prospective permission is very unlikely to have a live object today, but that is inference, not evidence.",
 extra_searched=["United States v. Chemical Foundation, 272 U.S. 1 (govinfo USREPORTS-272)", "WebSearch for Chemical Foundation dissolution (no source)"]))

R.append(rec("EO:3016N", FAM, "no", "no",
 [cl("Authorizes and directs APC to transfer, release, surrender and quitclaim to Ludwig Vogelstein all rights of the APC and Aron Hirsch & Sohn in 50,000 shares of L. Vogelstein & Co., Inc., on terms securing payment of Vogelstein's debt to Hirsch",
     "Alien Property Custodian", "50,000 shares L. Vogelstein & Co., Inc.", "TWEA sec. 12 via EO 3016 para. V (Polk)", "on payment/security of debt",
     None, "executed: 1923 APC report disposition 'trustees returned stock upon payment to Alien Property Custodian by American debtor'; claim allowed Oct. 11, 1920 (exact date of transfer not shown)", [P('E15'), P('E17'), P('E22'), P('E23')]),
  cl("Includes power to hold released shares as security under a trust agreement and to make arrangements preventing the shares passing into German control 'for such period as may seem proper to the APC'",
     "Alien Property Custodian", "same shares", "same", "discretionary period", None,
     "object ended: APC interest released and stock returned upon payment; any private arrangement made would be a saved independent act (TC08), not continuing EO authority", [P('E16'), P('E22')])],
 True, True, "official_publication", [P('E14')] + LAW,
 "No amending/revoking order found. 1923 report records final disposition of the L. Vogelstein & Co. trust and allowance of its claim (Oct. 11, 1920).",
 "Considered the anti-German-control power: it was ancillary to APC custody of the pledged shares; once the trustees returned the stock on payment, the APC held no interest to which the power could attach. A contractual restriction, if any was imposed, would survive only as a saved act (TC08).",
 "S9_APC_R1_executed_single_transaction", [P('E15'), P('E16'), P('E17'), P('E22'), P('E23'), P('E14')] + LAW, "medium", None,
 "Exact date of transfer and whether any anti-German-control trust arrangement was executed are not documented; the disposition line is a summary entry. Text grade: GPO compilation reached through archive.org OCR (archived copy of official publication)."))

R.append(rec("EO:3150", FAM, "indeterminate", "indeterminate",
 [cl("Authorizes APC to sell at private sale Lot 77 in Franz A. R. Jung's subdivision, Square 159, Washington D.C., formerly owned by Franz A. R. Jung and Sophie A. Nordhoff Jung",
     "Alien Property Custodian (now Attorney General)", "Lot 77, Square 159, D.C.", A12 + " and Act of Nov. 4, 1918", "advantageous offer received; owners approved price",
     None, "unproven: claims of Sofie A. N. Jung (Dec. 2, 1920) and Franz A. R. Jung (Dec. 9, 1920) allowed, but property scope not shown; no deed found", [P('E18'), P('E19'), P('E24'), P('E25')])],
 True, True, "official_publication", LAW,
 "No amending/revoking order found. Compilation prints the order without a number (identity by date and content).",
 SAV_SALE, None, [P('E18'), P('E19'), P('E24'), P('E25')] + LAW, "medium",
 "Missing fact: deed from the APC conveying Lot 77, Square 159 (1919-1920) or proof the lot was returned to the Jungs under their allowed claims. Would settle: D.C. Recorder of Deeds land records for Square 159 Lot 77 (1919-1920), or the APC trust/claim files 2924-2925 (NARA RG 131).",
 "Sale with owner consent followed by allowed claims is consistent with completion, but no record ties these to this lot."))

TXT_LADDER = ("Text ladder tried: APP advanced search (number, party names, all APC-related EOs: not hosted); WebSearch (only Monthly Catalog index entries at mocat.library.unt.edu); "
              "mocat.library.unt.edu via curl, WebFetch and Playwright (403 Access Denied / DNS fail); HathiTrust full-text search via curl and Playwright (Cloudflare challenge, not defeated); "
              "Google Books API (quota 0) and books.google.com (302 block); NARA catalog API (needs key) and UI via Playwright (no hit); Wayback CDX (connection reset by upstream x6); "
              "archive.org advancedsearch (1920 compilation stops at Nov. 25, 1919; no later edition found); govinfo Serial Set full-text search via Playwright (only index/catalogue entries; APC reports 1922/1923/1925 do not reprint orders).")

R.append(rec("EO:3456", FAM, "indeterminate", "indeterminate",
 [cl("Per ledger title only: authorizes APC to sell at private sale the HAPAG wharf property on New York Bay, Brooklyn", "Alien Property Custodian", "HAPAG Brooklyn wharf", A12 + " (assumed)", "unknown", None, "operative text not obtained", [])],
 False, False, "none", LAW,
 "Not checkable without text. Document Catalogue lists other 1921 HAPAG orders (3549, 3573) on Hoboken piers, not this wharf.",
 SAV_SALE, None, LAW, "low",
 "Operative text not obtained. " + TXT_LADDER + " Would settle text: signed original in NARA RG 11 (Executive Orders) or the GPO slip print (SuDoc Pr 29.5), e.g. via HathiTrust/UNT Monthly Catalog 1921; execution: APC annual report for 1921 (Serial Set) or Kings County conveyance records.",
 "Everything beyond the ledger title."))

R.append(rec("EO:3639A", FAM, "indeterminate", "indeterminate",
 [cl("Per official Document Catalogue index entry: authorizes APC to give a perpetual lease of Columbus, Ohio real estate of Jane Georgiana Margaret Sophie Mandrup de Lynar and other de Lynar family members to Swan Company (12 pp.)",
     "Alien Property Custodian", "Columbus, Ohio real estate (Franklin County)", A12 + " (assumed)", "perpetual", None,
     "operative text not obtained; if executed, a perpetual leasehold is a continuing property interest that may keep an effect alive (TC06/TC07 durable_disposition)", [P('E32'), P('E33'), P('E34'), P('E35')])],
 False, False, "index_only", LAW,
 "Document Catalogue 67th Cong. confirms No. 3639A, Feb. 21, 1922, 12 pp. A 1947 vesting order (12 FR 2542) vested debts owed to the zu Lynar family by Huntington National Bank of Columbus trust department (Dec. 1946) - consistent with continuing Columbus income but the lease is not named.",
 "Perpetual lease is the designed counterexample: if executed under this order, the leasehold (and lessor reversion/rent) is a continuing property status whose validity rests on the presidential authorization; under TC07 that is a durable_disposition candidate, not automatically spent. Cannot be decided without the 12-page text (terms, renewal, conditions) and the recorded lease.",
 None, [P('E32'), P('E33'), P('E34'), P('E35')] + LAW, "low",
 "Operative text not obtained (12-page order). " + TXT_LADDER + " Would settle: text - NARA RG 11 signed original or GPO slip print (Monthly Catalog 1922); execution and present status - Franklin County (Ohio) Recorder lease record from Alien Property Custodian to The Swan Company (1922) and current chain of title/ground-rent status; OAP vesting order file for 12 FR 2542 (zu Lynar).",
 "Everything beyond the catalogue entry; whether the lease was executed and still subsists."))

R.append(rec("EO:4007", FAM, "indeterminate", "indeterminate",
 [cl("Per ledger title (and a Monthly Catalog snippet seen only in a WebSearch summary: sale upon the New York Stock Exchange of 97,295 shares): authorizes APC to sell Standard Oil Co. (N.J.) stock formerly of Louise Braesecke, Wilhelm A. and Erwin C. Riedemann, Carl, Gustav and Meta Schutte",
     "Alien Property Custodian", "Standard Oil Co. (N.J.) shares", A12 + " (assumed)", "unknown", None, "operative text not obtained", [])],
 False, False, "none", LAW,
 "Not checkable without text. 1923 APC report shows Riedemann claims allowed 1921-1922 (scope not shown).",
 SAV_SALE, None, LAW, "low",
 "Operative text not obtained. " + TXT_LADDER + " Would settle: text - NARA RG 11 or GPO slip print (Monthly Catalog 1924, mocat entry 353-ch1428); execution - Annual Report of the APC for 1924, S. Doc. 68-203 (Serial Set 8405, govinfo SERIALSET-08405_00_00-002-0203-0000, 237 MB, not downloaded under the pivot rule).",
 "Everything beyond the ledger title."))

with open(os.path.join(S, 'status_proposals.jsonl'), 'w') as f:
    for r in R: f.write(json.dumps(r, ensure_ascii=False) + '\n')

rules = [
 {"rule_id": "S9_APC_R1_executed_single_transaction",
  "legal_authority": "TWEA sec. 12 (40 Stat. 423, as amended 40 Stat. 460; 50 U.S.C. 4312); TC07 spent dispositive act; TC08 saved acts",
  "sources": ["S9_APC:E36", "S9_APC:E38", "S9_APC:E40", "S9_APC:E41"],
  "applicability_predicates": ["Every operative clause is a one-time permission/direction to dispose of identified property in APC custody",
                               "An owner- or trust-specific official record shows the disposition was carried out or APC custody of that object ended",
                               "No prospective clause reaching future seizures or a continuing status (lease, servitude, restriction) with a live object",
                               "Subsequent-change search found no amendment, revocation or revival"],
  "exceptions": ["Orders with prospective coverage (EO 3016C)", "Orders creating continuing property interests (EO 3639A perpetual lease)",
                 "Orders where execution is shown only by aggregate statistics or an owner claim of unknown scope (EO 2843, 2858, 2953, 3150)"],
  "savings_or_surviving_effects": "Title of the transferee and any contracts made are historical consequences/saved acts, not current EO effect (TC04, TC08). Unexecuted authorizations would have passed to the Attorney General (EO 6694, EO 9788), so non-execution keeps the order open.",
  "covered_ids": ["EO:3016N"],
  "what_evidence_proves": "Operative text and an official per-trust disposition record showing completion.",
  "what_remains_inferential": "Exact completion date; whether any ancillary arrangement was made.",
  "substantive_result": "no", "any_effect_result": "no"},
 {"rule_id": "S9_APC_R2_self_executing_annulment",
  "legal_authority": "TWEA sec. 12 proviso (reject bids on presidential order stating reasons), 40 Stat. 460; TC07",
  "sources": ["S9_APC:E36", "S9_APC:E37", "S9_APC:E08"],
  "applicability_predicates": ["Order itself declares an identified past sale void", "Only other clause directs rejection of bids at that same sale", "No direction to resell on stated terms or other continuing command"],
  "exceptions": ["Orders that also direct a resale or set continuing conditions"],
  "savings_or_surviving_effects": "Historical voidness only (TC04).",
  "covered_ids": ["EO:2954"],
  "what_evidence_proves": "Operative text showing self-executing annulment.",
  "what_remains_inferential": "That the APC actually sent rejections (immaterial once the sale was void).",
  "substantive_result": "no", "any_effect_result": "no"}]
with open(os.path.join(S, 'rules.jsonl'), 'w') as f:
    for r in rules: f.write(json.dumps(r, ensure_ascii=False) + '\n')

queue = [
 ("EO:2843", "No owner-specific sale/return record for the 50 hogsheads", "NARA RG 131 WWI APC trust/sale file for Schilling & Bruning; claim ~5000 (allowed 22 Nov 1923)"),
 ("EO:2858", "No owner-specific sale record for Hammar nickel; claim 7838 pending in 1923", "NARA RG 131 trust file Hammar & Co.; APC reports 1924+ claims lists"),
 ("EO:2953", "No deed or return record for the Riverside Drive parcel", "NYC Register (Manhattan) conveyance libers 1918-1919; Busch sec. 9 claim/suit files (NARA RG 131)"),
 ("EO:3016C", "Prospective sale/release permission without proved end", "Delaware Division of Corporations record for The Chemical Foundation, Inc.; Act of Mar. 4, 1923 (42 Stat. 1511) patent-return proviso; Feb. 13, 1920 ratifying EO text"),
 ("EO:3150", "No deed or return record for Lot 77 Sq. 159", "D.C. Recorder of Deeds 1919-1920; APC claims 2924-2925 files"),
 ("EO:3456", "Operative text not obtained (full ladder failed)", "NARA RG 11 signed original; GPO slip print via HathiTrust (Cloudflare-blocked here); APC report 1921"),
 ("EO:3639A", "Operative text (12 pp.) not obtained; perpetual lease may be a continuing property interest", "NARA RG 11 original or GPO print; Franklin County OH Recorder lease APC->Swan Company 1922; OAP file for 12 FR 2542"),
 ("EO:4007", "Operative text not obtained", "NARA RG 11 / GPO print; APC 1924 report S. Doc. 68-203 (govinfo SERIALSET-08405_00_00-002-0203-0000)"),
]
with open(os.path.join(S, 'queue.jsonl'), 'w') as f:
    for i, b, s in queue: f.write(json.dumps({"instrument_id": i, "blocker": b, "source_that_would_settle_it": s}) + '\n')

conf = [
 {"instrument_id": "EO:2858", "field": "signing_date", "ledger": "1918-05-07", "source": "1918-05-09", "evidence_ids": ["S9_APC:E04", "S9_APC:E05"], "note": "Signature block '9 May, 1918' in S. Doc. 65-435 and AJIL; the 7 May 1918 order is No. 2857 (100 hogsheads Schilling & Bruning). Ledger not corrected."},
 {"instrument_id": "EO:3016C", "field": "issuer/instrument type", "ledger": "EO (Lord-lettered 3016C)", "source": "Order of Frank L. Polk, Counselor/Acting Secretary of State, under delegation in EO 3016 (Dec. 3, 1918), not signed by the President", "evidence_ids": ["S9_APC:E13", "S9_APC:E14"], "note": "Treated as in-scope delegated order; the 1921 treatise calls Polk orders 'substantially Executive orders'."},
 {"instrument_id": "EO:3016N", "field": "issuer/instrument type", "ledger": "EO (Lord-lettered 3016N)", "source": "Order of Frank L. Polk under EO 3016 delegation, dated 18 April 1919", "evidence_ids": ["S9_APC:E15", "S9_APC:E17"], "note": "Ledger title says 'transfer ... acquired by Aron Hirsch'; text: rights of APC and Aron Hirsch & Sohn arising from the deposit of the shares."},
 {"instrument_id": "EO:3150", "field": "number", "ledger": "3150", "source": "compilation prints the 16 Aug 1919 order without a number", "evidence_ids": ["S9_APC:E18", "S9_APC:E19"], "note": "Identity by date and content (Jung, Washington D.C.)."},
 {"instrument_id": "EO:2843", "field": "title spelling", "ledger": "Schilling and Bruning", "source": "OCR 'Burning'/'Burnings' in both copies; 2857 copy reads 'Bruning'", "evidence_ids": ["S9_APC:E01"], "note": "OCR variant only; not a substantive conflict."},
]
with open(os.path.join(S, 'conflicts.jsonl'), 'w') as f:
    for c in conf: f.write(json.dumps(c, ensure_ascii=False) + '\n')
print('ok', len(R))
