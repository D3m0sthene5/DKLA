// usage: node pw.js <url> <outfile>
const { chromium } = require('playwright');
(async () => {
  const [url, out] = process.argv.slice(2);
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' });
  const resp = await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 90000 });
  await page.waitForTimeout(parseInt(process.env.WAIT||"5000"));
  require('fs').writeFileSync(out, await page.content());
  console.log(resp ? resp.status() : 'noresp', page.url());
  await browser.close();
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
