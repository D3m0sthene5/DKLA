import sys,json,hashlib
from bs4 import BeautifulSoup
src,dst,meta=sys.argv[1:4]
soup=BeautifulSoup(open(src,'rb').read(),'html.parser')
for t in soup(['script','style','nav','header','footer']): t.decompose()
txt=soup.get_text('\n')
import re
txt=re.sub(r'\n\s*\n+','\n\n',txt)
open(dst,'w').write(txt)
m=json.load(open(meta)); m['text_extraction']='python3 -I bs4 html.parser get_text(newline), script/style/nav/header/footer removed'; m['text_sha256']=hashlib.sha256(open(dst,'rb').read()).hexdigest()
json.dump(m,open(meta,'w'),indent=1)
print(len(txt))
