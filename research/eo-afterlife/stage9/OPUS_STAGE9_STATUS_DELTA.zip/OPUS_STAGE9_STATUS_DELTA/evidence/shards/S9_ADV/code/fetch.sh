#!/bin/bash
# usage: fetch.sh source_id ext url
set -u
id="$1"; ext="$2"; url="$3"
d=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/S9_ADV/cache
out="$d/$id.$ext"
ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
res=$(curl -sSL -A "Mozilla/5.0 (research; DKLA)" -o "$out" -w '%{http_code}|%{url_effective}|%{content_type}' "$url")
code=${res%%|*}; rest=${res#*|}; final=${rest%%|*}; ctype=${rest#*|}
sha=$(sha256sum "$out" | cut -d' ' -f1)
python3 -I - "$d/$id.meta.json" "$url" "$final" "$ts" "$code" "$ctype" "$sha" <<'PY'
import json,sys
p,url,final,ts,code,ct,sha=sys.argv[1:]
json.dump({"url":url,"final_url":final,"retrieved_utc":ts,"http_status":int(code),"content_type":ct,"sha256":sha,"method":"curl original bytes"},open(p,"w"),indent=1)
PY
echo "$id $code $ctype $(stat -c %s "$out")"
