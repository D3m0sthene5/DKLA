import sys,json,hashlib,subprocess,os
# usage: extract.py cache_dir source_id ext [firstpage lastpage]
d,sid,ext=sys.argv[1:4]
src=os.path.join(d,f"{sid}.{ext}"); txt=os.path.join(d,f"{sid}.txt"); meta=os.path.join(d,f"{sid}.meta.json")
m=json.load(open(meta))
if ext=="pdf":
    cmd=["pdftotext","-layout"]
    if len(sys.argv)>5: cmd+=["-f",sys.argv[4],"-l",sys.argv[5]]
    subprocess.run(cmd+[src,txt],check=True)
    m["extraction_method"]="pdftotext -layout"+(f" -f {sys.argv[4]} -l {sys.argv[5]}" if len(sys.argv)>5 else "")
elif ext=="json":
    open(txt,"w").write(json.dumps(json.load(open(src)),indent=1,ensure_ascii=False))
    m["extraction_method"]="python json pretty-print"
elif ext=="txt_raw":
    pass
else:
    from bs4 import BeautifulSoup
    s=BeautifulSoup(open(src,"rb").read(),"html.parser")
    for t in s(["script","style"]): t.decompose()
    open(txt,"w").write(s.get_text("\n"))
    m["extraction_method"]="python3 -I bs4 html.parser get_text('\\n')"
m["text_file_sha256"]=hashlib.sha256(open(txt,"rb").read()).hexdigest()
json.dump(m,open(meta,"w"),indent=1)
print(sid,m["text_file_sha256"][:12])
