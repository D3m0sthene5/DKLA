import json,os,sys
base=sys.argv[1]
ev={json.loads(l)['evidence_id'] for l in open(os.path.join(base,'evidence.jsonl'))}
pk=[json.loads(l) for l in open(os.path.join(base,'..','..','packets','S9_ADV.jsonl'))]
own={p['instrument_id']:p['ownership_status'] for p in pk}
def C(clause,actor,obj,auth,time,end_date,basis,eids):
    return {"clause":clause,"actor":actor,"object":obj,"authority":auth,"time_or_condition":time,"end":{"date":end_date,"basis":basis},"evidence_ids":eids}
FACA="FACA, 5 U.S.C. App. (now 5 U.S.C. ch. 10); President's constitutional/statutory authority"
P={}
P["EO:11948"]=dict(s="no",a="no",rule="ADV-R1",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance of 13 listed committees","President / listed agencies","13 advisory committees","FACA (5 U.S.C. App. I)","until Dec 31, 1978","1978-12-31","own end date; superseded by EO 12110 sec. 1-104",["E11948_sec1","E11948_sec1date","E12110_sup","E12110_cont"]),
     C("sec.2 delegation of FACA functions for sec.1 committees","listed agency heads","FACA functions for sec.1 committees","FACA","tied to sec.1 committees","1978-12-31","whole order superseded by EO 12110 sec. 1-104",["E12110_sup"]),
     C("sec.3 revocation of EO 11868 effective Jan 16, 1977","President","EO 11868","constitutional","dated","1977-01-16","spent pure revocation (TC07)",["E11948_sec3"]),
     C("sec.4 revocations of EOs 11667, 11809, 11860; supersession of EO 11827","President","listed EOs","constitutional","immediate","1976-12-31","spent pure revocation/supersession (TC07)",["E11948_sec4b"]),
     C("sec.5 effective date","n/a","n/a","n/a","Dec 31, 1976","1976-12-31","spent",[])],
 ctrl=["E12110_sup"],srch=["NARA 1976 and 1978 disposition tables","FR 1979-01-03 (EO 12110 text)"],
 find="No amendments of other EOs. Continuance expired 1978-12-31 and EO 12110 sec. 1-104 superseded EO 11948.",
 sav="No savings clause; no incorporated amendment; revocations are spent (TC07).",inf="None material; OCR text of 1976 FR used for quotes.")
P["EO:12692"]=dict(s="no",a="no",rule="ADV-R1",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance of 11 committees","President / listed agencies","11 advisory committees","FACA","until Sept 30, 1991","1991-09-30","own end date; EO 12774 sec.4 superseded EO 12692",["E12692_sec1","E12774_sup12692"]),
     C("sec.2 FACA delegation","listed agency heads","FACA functions","FACA","tied to sec.1","1991-09-30","superseded by EO 12774 sec.4",["E12774_sup12692"]),
     C("sec.3 revocation of seven committee EOs","President","EOs 12462, 12592, 12668, 12607, 12296, 12528, 12601","constitutional","immediate","1989-09-30","spent pure revocation (TC07)",["E12692_sec3"]),
     C("sec.4 supersedes EO 12610; sec.5 effective date","President","EO 12610","constitutional","immediate","1989-09-30","spent",["E12692_sec4"])],
 ctrl=["E12774_sup12692"],srch=["NARA 1989-bush disposition table","FR 1991-10-01 (EO 12774 text)"],
 find="No amendments of other EOs. Superseded in whole by EO 12774 sec. 4; own term ended 1991-09-30.",sav="None.",inf="None material.")
P["EO:12774"]=dict(s="no",a="no",rule="ADV-R1",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance of 10 committees","President / listed agencies","10 advisory committees","FACA","until Sept 30, 1993","1993-09-30","own end date; EO 12869 sec.5 superseded EO 12774",["E12774_sec1","E12774_sec1date","E12869_sup","E12869_cont"]),
     C("sec.2 FACA delegation","listed agency heads","FACA functions","FACA","tied to sec.1","1993-09-30","superseded by EO 12869 sec.5",["E12869_sup"]),
     C("sec.3 revocations (EO 12661 sec 3-401, EO 12686, EO 12658)","President","listed EOs","constitutional","immediate","1991-09-30","spent pure revocation (TC07)",["E12774_sec3"]),
     C("sec.4 supersedes EO 12692; sec.5 effective date","President","EO 12692","constitutional","immediate","1991-09-30","spent",["E12774_sup12692"])],
 ctrl=["E12869_sup"],srch=["NARA 1991 disposition table","APP transcript of EO 12869 (FR 1993-10-01/04/05 issues fetched and screened on contents pages without locating EO 12869; deleted)"],
 find="No amendments of other EOs. Own term ended 1993-09-30; EO 12869 sec. 5 supersedes (APP transcript).",sav="None.",inf="Supersession evidence for EO 12869 is a hosted transcript; the order's own end date independently ends sec.1-2.")
P["EO:13138"]=dict(s="no",a="no",rule="ADV-R3",conf="medium",grade="official_publication",
 fp=[C("sec.1 continuance of 16 committees until Sept 30, 2001; sec.2 FACA delegation","President / listed agencies","16 advisory committees","FACA","until Sept 30, 2001","2001-09-30","own end date; EO 13225 sec.4 superseded secs 1-4",["E13138_sec1","E13225_sup13138"]),
     C("sec.3 revocations of seven committee EOs","President","EOs 13017, 13038, 13010 (part), 13037, 13050, 12852, 12961","constitutional","immediate","1999-09-30","spent pure revocation (TC07)",["E13138_sec3"]),
     C("sec.4 supersedes EO 13062 secs 1-4","President","EO 13062","constitutional","immediate","1999-09-30","spent (TC07)",["E13138_sec4"]),
     C("sec.5 adds Department of Energy to EO 12131 sec 1-102(a) (President's Export Council)","Commerce/PEC","EO 12131 sec 1-102(a)","constitutional; FACA","incorporated amendment","2003-09-30","amended text displaced: EO 13316 sec.5 rewrote 1-102(a) and EO 13596 sec.1 rewrote all of 1-102 (TC09)",["E13138_sec5","E13316_sec5","E13596_1102","E13596_1102b"]),
     C("sec.6 adds Treasury and ONDCP to EO 13115 Coast Guard task force","Interagency Task Force on Coast Guard roles","EO 13115 sec 1(b)","constitutional","task force to exist 6 months from first meeting unless extended","no later than 2000-11-09 (event bound: FR notice reports the Task Force findings)","host task force was time-limited and completed its report (TC07 finite completed event)",["E13138_sec6","E13115_sunset","E2000_tf_reported"]),
     C("sec.7 amends EO 12367 (President's Committee on the Arts and the Humanities) secs 1, 2, 3(b)","PCAH / NEA","EO 12367","FACA","incorporated amendment (partly re-amended by EO 13385 sec.6)","2017-09-30","PCAH last continued to Sept 30, 2017 (EO 13708); omitted from EO 13811 and all later continuance orders; terminated under 5 U.S.C. 1013(a)(2); new PCAH created under EO 14084 in 2022 (itself revoked 2025) (ADV-R4)",["E13138_sec7","E13708_pcah","E13708_until2017","E12367_search","E12367_search_bare","E14084_newpcah","EFACA_term","EFACA_renew","E14084_revoked"]),
     C("sec.8 rewrites membership sentence of EO 12345 sec 2(b)","President's Council on Physical Fitness and Sports","EO 12345","FACA","incorporated amendment","2002-06-06","host EO 12345 revoked by EO 13265 (TC09)",["E13138_sec8","E13265_rev12345"]),
     C("sec.9 effective date","n/a","n/a","n/a","Sept 30, 1999","1999-09-30","spent",[])],
 ctrl=["E13225_sup13138","E13596_1102","E13265_rev12345","EFACA_term"],srch=["FR API notes for EOs 13138, 13225, 13115, 13265, 13226","FR full-text search for 'Executive Order 12131' (2003-2026), 'Executive Order 12367' (2005-2026), '12367' (2016-2026), 'Executive Order 13115' (1999-2026)","EO 13596 text","EO 14084 text"],
 find="Every clause ended: continuance superseded (13225); revocations spent; 12131 amendment displaced by 13316 and 13596; 13115 task force time-limited and reported; 12345 revoked 2002; 12367 committee not continued after Sept 30, 2017 and re-created under a different order in 2022.",
 sav="EO 12367 itself has no located revocation; the 13138 sec.7 wording survives on paper in an unrevoked host whose committee terminated under FACA in 2017. Treated as ended under ADV-R4 (committee terminated; revival would need a new act, TC11).",
 inf="That the PCAH under EO 12367 was not renewed by any non-FR presidential act after Sept 30, 2017 (bounded check only); convention that FACA termination ends the host's operative scope rather than leaving a dormant effect. That the 13115 task force was not extended (only the 2000 FR notice of its completed findings).")
P["EO:13316"]=dict(s="no",a="no",rule="ADV-R3",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance until Sept 30, 2005; sec.2 FACA delegation","President / listed agencies","14 committees","FACA","until Sept 30, 2005","2005-09-30","own end date; EO 13385 sec.4 superseded secs 1-2",["E13316_sec1","E13385_sec4"]),
     C("sec.3 revocations of nine committee EOs/sections","President","listed EOs","constitutional","immediate","2003-09-30","spent pure revocation (TC07)",["E13316_sec3"]),
     C("sec.4 supersedes EO 13225","President","EO 13225","constitutional","immediate","2003-09-30","spent",["E13316_sec4"]),
     C("sec.5 rewrites EO 12131 sec 1-102(a) (PEC agency members)","PEC/Commerce","EO 12131 sec 1-102(a)","FACA","incorporated amendment","2011-12-19","displaced: EO 13596 sec.1 rewrote all of sec 1-102 (TC09)",["E13316_sec5","E13596_1102","E13596_1102b"]),
     C("sec.6 effective date","n/a","n/a","n/a","Sept 30, 2003","2003-09-30","spent",[])],
 ctrl=["E13385_sec4","E13596_1102"],srch=["FR API notes for 13316, 13385","FR full-text search 'Executive Order 12131' 2003-2026","EO 13596 text"],
 find="Only amendment (12131 sec 1-102(a)) was wholly replaced by EO 13596 in 2011; continuance superseded by 13385.",sav="None surviving.",inf="None material.")
P["EO:13385"]=dict(s="indeterminate",a="indeterminate",rule="ADV-R3",conf="medium",grade="official_publication",
 hold="EO 13385 sec.7 rewrote EO 12216 sec 1-101 (President's Committee on the International Labor Organization); EO 12216 has no located revocation and 1-101 has no later re-amendment, so the 13385 text survives in the host. The committee was last continued to Sept 30, 2025 (EO 14109 sec.1(f)) and is omitted from EO 14354; no later DOL charter-renewal notice was found. Missing fact: whether the ILO committee was renewed by other appropriate action after Sept 30, 2025 or terminated under 5 U.S.C. 1013(a)(2), and (convention) whether a FACA-terminated committee in an unrevoked host leaves a dormant incorporated effect. Settled by: GSA FACA database record / DOL charter status for the committee as of 2026-10-14, plus root ruling on the FACA-lapse convention.",
 fp=[C("sec.1 continuance until Sept 30, 2007; sec.2 FACA delegation","President / listed agencies","16 committees","FACA","until Sept 30, 2007","2007-09-30","own end date; EO 13446 sec.4 superseded secs 1-2",["E13385_sec1","E13446_sup13385"]),
     C("sec.3 revocation of EOs 13328 and 13326; sec.9 revocation of EO 13283","President","listed EOs","constitutional","immediate","2005-09-30","spent pure revocation (TC07)",["E13385_sec3","E13385_sec9"]),
     C("sec.4 supersedes EO 13316 secs 1-2","President","EO 13316","constitutional","immediate","2005-09-30","spent",["E13385_sec4"]),
     C("sec.5 rewrites EO 13231 sec.3 (NIAC)","DHS/NIAC","EO 13231 sec.3","FACA","incorporated amendment","2013-09-30","displaced: EO 13652 sec.6 struck and replaced sec.3 except (c) (TC09)",["E13385_sec5","E13652_sec6","E13652_sec6b"]),
     C("sec.6 amends EO 12367 (PCAH) secs 2, 3","PCAH/NEA/IMLS","EO 12367","FACA","incorporated amendment","2017-09-30","PCAH not continued after Sept 30, 2017; terminated under 5 U.S.C. 1013(a)(2); new PCAH under EO 14084 (ADV-R4)",["E13385_sec6","E13708_pcah","E13708_until2017","E12367_search","E14084_newpcah","EFACA_term"]),
     C("sec.7 rewrites EO 12216 sec 1-101 (ILO committee establishment and membership)","Secretary of Labor; ILO committee members","EO 12216 sec 1-101","FACA; constitutional","incorporated amendment; committee continued to Sept 30, 2025 by EO 14109, omitted from EO 14354","unknown (possibly 2025-09-30)","UNRESOLVED: host unrevoked and text intact; committee renewal/termination after Sept 30, 2025 not established",["E13385_sec7","E13385_sec7b","E12216_search","E12216_bare","E14109_ilo","E14109_until2025","E_ilo_charter","EFACA_term","EFACA_renew"]),
     C("sec.8 amends EO 13226 (PCAST) membership and adds sec 2(d)","PCAST/OSTP","EO 13226","FACA; 15 U.S.C. 5511","incorporated amendment","2010-04-21","host EO 13226 revoked by EO 13539 (TC09)",["E13385_sec8","E13226_revoked"]),
     C("sec.10 effective date","n/a","n/a","n/a","Sept 30, 2005","2005-09-30","spent",[])],
 ctrl=["E13446_sup13385","E13652_sec6","E13226_revoked","EFACA_term"],srch=["FR API notes for 13385, 13226, 13231","FR full-text searches 'Executive Order 12216' (2005-2026), '12216' (2024-2026), 'Executive Order 12367' (2005-2026)","FR all-document search for ILO committee notices (2015-2026)","EO 14354 text (ILO committee absent)"],
 find="All clauses ended except sec.7 (EO 12216 sec 1-101), whose host is unrevoked and whose committee lapsed from the continuance list only on Sept 30, 2025.",
 sav="Possible surviving incorporated amendment in EO 12216 (TC09); not forced to NO.",inf="Status of the ILO committee after Sept 30, 2025; convention for FACA-lapsed hosts.")
P["EO:13511"]=dict(s="no",a="no",rule="ADV-R1",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance until Sept 30, 2011; sec.2 FACA delegation","President / listed agencies","15 committees","FACA","until Sept 30, 2011","2011-09-30","own end date; EO 13585 sec.3 superseded secs 1-2",["E13511_sec1","E13585_sup13511"]),
     C("sec.3 supersedes EO 13446 secs 1-2; sec.4 effective date","President","EO 13446","constitutional","immediate","2009-09-30","spent",["E13511_sec3"])],
 ctrl=["E13585_sup13511"],srch=["FR API notes for 13511, 13585"],find="No amendments of other EOs; superseded by EO 13585.",sav="None.",inf="None material.")
P["EO:13585"]=dict(s="no",a="no",rule="ADV-R3",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance until Sept 30, 2013; sec.2 FACA delegation","President / listed agencies","15 committees","FACA","until Sept 30, 2013","2013-09-30","own end date; EO 13652 sec.3 superseded secs 1-2",["E13585_sec1","E13652_sup"]),
     C("sec.3 supersedes EO 13511 secs 1-2","President","EO 13511","constitutional","immediate","2011-09-30","spent",["E13585_sup13511"]),
     C("sec.4 amends EO 13515 (AAPI Initiative/Commission co-chairs and members)","Education/Commerce; AAPI Initiative","EO 13515 secs 2-3","constitutional; FACA","incorporated amendment","2021-05-28","host EO 13515 superseded by EO 14031 sec.4(a) (and 14031 itself revoked 2025) (TC09)",["E13585_sec4","E14031_sup13515a","E14031_sup13515b","E14031_revoked"]),
     C("sec.5 effective date","n/a","n/a","n/a","Sept 30, 2011","2011-09-30","spent",[])],
 ctrl=["E13652_sup","E14031_sup13515a"],srch=["FR API notes for 13585, 13515, 14031","EO 14031 text"],find="Only amendment host (EO 13515) was superseded in 2021.",sav="None.",inf="None material.")
P["EO:13591"]=dict(s="no",a="no",rule="ADV-R3",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance of 7 committees until Sept 30, 2013","President / listed agencies","7 committees","FACA","until Sept 30, 2013","2013-09-30","own end date; EO 13652 sec.3 superseded secs 1, 2, 4",["E13591_sec1","E13652_sup13591"]),
     C("sec.2 continuance of Advisory Group on Prevention until Sept 30, 2012","HHS","advisory group","FACA","until Sept 30, 2012","2012-09-30","own end date; superseded by EO 13652 sec.3",["E13591_sec2","E13652_sup13591"]),
     C("sec.3 rewrites EO 13530 sec.6: Council terminates Jan 29, 2013 unless extended","President's Advisory Council on Financial Capability","EO 13530 sec.6","FACA","sunset Jan 29, 2013 unless extended by the President","2013-01-29","sunset operated; no presidential extension found (TC07/TC10)",["E13591_sec3","E13591_sec3b","E13530_search","E13530_validate","E13530_notes"]),
     C("sec.4 FACA delegation","listed agency heads","FACA functions","FACA","tied to secs 1-2","2013-09-30","superseded by EO 13652 sec.3",["E13652_sup13591"])],
 ctrl=["E13652_sup13591","E13530_search"],srch=["FR API notes for 13591, 13530","FR full-text search '13530' presidential docs 2011-12-01..2026 (validated by 2011-11-01 search finding 13591)"],find="All clauses ended; EO 13530 council terminated Jan 29, 2013 under the sunset written by 13591.",sav="None.",inf="Non-extension of the EO 13530 council rests on FR presidential-document search and FR finding-aid notes.")
P["EO:13652"]=dict(s="indeterminate",a="indeterminate",rule="ADV-R3",conf="medium",grade="official_publication",
 hold="EO 13652 sec.6 replaced EO 13231 sec.3 (NIAC); that text survives in EO 13231 (only sec 3(a) last sentence re-amended by EO 14048 sec.6) and EO 13231 has no located revocation. NIAC was last continued to Sept 30, 2025 (EO 14109 sec.1(q)) and is omitted from EO 14354; DHS does not publish NIAC charter renewals in the FR and CISA pages return 403. Missing fact: whether NIAC was renewed by other appropriate action after Sept 30, 2025 or terminated under 5 U.S.C. 1013(a)(2), plus the FACA-lapse convention. Settled by: GSA FACA database / DHS-CISA NIAC charter status as of 2026-10-14 and root ruling on FACA-lapsed hosts.",
 fp=[C("sec.1 continuance until Sept 30, 2015; sec.2 FACA delegation","President / listed agencies","26 committees","FACA","until Sept 30, 2015","2015-09-30","own end date; EO 13708 sec.3 superseded secs 1-2",["E13652_sec1","E13708_sup13652"]),
     C("sec.3 supersedes 13585 secs 1-2 and 13591 secs 1, 2, 4","President","EOs 13585, 13591","constitutional","immediate","2013-09-30","spent",["E13652_sup","E13652_sup13591"]),
     C("sec.4 amends EO 13538 sec 4(c) (PMAB DFO)","PMAB/GSA","EO 13538","FACA","incorporated amendment","2017-09-30","PMAB own sunset (sec.5) operated: last extended to Sept 30, 2017 (EO 13708), no later extension (ADV-R4)",["E13652_sec4","E13538_term","E13708_pmab","E13708_until2017","E13538_search"]),
     C("sec.5 strikes EO 13043 sec.4","President","EO 13043 sec.4","constitutional","immediate","2013-09-30","spent pure partial revocation (TC07)",["E13652_sec5"]),
     C("sec.6 replaces EO 13231 sec.3 (NIAC composition and functions)","DHS; NIAC","EO 13231 sec.3","FACA; constitutional","incorporated amendment; NIAC continued to Sept 30, 2025 by EO 14109, omitted from EO 14354","unknown (possibly 2025-09-30)","UNRESOLVED: host unrevoked and text intact (14048 changed only one sentence); NIAC renewal/termination after Sept 30, 2025 not established",["E13652_sec6","E13652_sec6b","E14048_sec6","E14109_niac","E14109_until2025","E13231_search","E13231_bare","E_niac_notices","EFACA_term","EFACA_renew"]),
     C("sec.7 amends EO 13600 secs 3(b), 5(c) (Global Development Council)","PGDC/USAID","EO 13600","FACA","incorporated amendment","2017-09-30","PGDC own sunset (sec.6) operated: last continued to Sept 30, 2017 (EO 13708), no later renewal (ADV-R4)",["E13652_sec7","E13600_term","E13708_pgdc","E13708_until2017","E13600_search"]),
     C("sec.8 amends EO 13515 sec 3(b)","AAPI Initiative","EO 13515","constitutional","incorporated amendment","2021-05-28","host superseded by EO 14031 sec.4(a) (TC09)",["E13652_sec8","E14031_sup13515a","E14031_sup13515b"]),
     C("sec.9 effective date","n/a","n/a","n/a","Sept 30, 2013","2013-09-30","spent",[])],
 ctrl=["E13708_sup13652","EFACA_term"],srch=["FR API notes for 13652, 13043, 13231, 13515, 13538, 13600, 14031","FR searches 'Executive Order 13231' (2021-2026), '13231' (2024-2026), 'Executive Order 13538'/'13600'/'13043' (2013-2026)","FR all-document search 'National Infrastructure Advisory Council' (2024-2026) and NIAC charter (2013-2026)","CISA NIAC pages (403)","WebSearch (Wikipedia only: NIAC inactive, omitted from EO 14354)"],
 find="All clauses ended except sec.6 (NIAC text in EO 13231), whose host is unrevoked and whose committee dropped off the continuance list on Sept 30, 2025.",
 sav="Possible surviving incorporated amendment in EO 13231 (TC09); not forced to NO.",inf="NIAC status after Sept 30, 2025; convention for FACA-lapsed hosts.")
P["EO:13708"]=dict(s="yes",a="yes",rule="ADV-R5",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance/reestablishment until Sept 30, 2017; sec.2 FACA delegation","President / listed agencies","40 committees","FACA","until Sept 30, 2017","2017-09-30","own end date; EO 13811 sec.3 superseded secs 1-2",["E13708_sec1","E13708_until2017","E13811_sup13708"]),
     C("sec.3 supersedes EO 13652 secs 1-2","President","EO 13652","constitutional","immediate","2015-09-30","spent",["E13708_sup13652"]),
     C("sec.4 amends EO 12829 sec 103(c)(2) (NARA provides NISPPAC administrative support) and 103(d) (Archivist performs President's FACA functions for NISPPAC)","National Archives and Records Administration / Archivist; NISPPAC","EO 12829 sec 103(c)(2), 103(d)","constitutional; FACA (5 U.S.C. ch.10)","incorporated amendment; host committee continued to Sept 30, 2027 by EO 14354 sec.1(d)",None,"continuing: text present in official 2024 U.S. Code compilation of EO 12829; no later amendment found; host committee live at cutoff",["E13708_sec4","E13708_sec4b","EUSC_12829_amendnote","EUSC_12829_c2","EUSC_12829_d","EISOO_pre13708","E12829_search","E13764_xref","E14354_nisppac","E14354_2027"]),
     C("sec.5 effective date","n/a","n/a","n/a","Sept 30, 2015","2015-09-30","spent",[])],
 ctrl=["EUSC_12829_amendnote","EUSC_12829_c2","E14354_nisppac"],srch=["FR API notes for 13708, 13811","FR search 'Executive Order 12829' presidential docs 2015-10-06..2026 (13764 cross-reference and continuance orders only)","EO 13764 text","govinfo U.S. Code 2024 ed. 50 U.S.C. 3161 note","NARA ISOO compiled EO 12829 (pre-13708)","uscode.house.gov (page not found in temporary format)"],
 find="EO 13708 sec.4 wording (NARA support; Archivist FACA functions) remains in EO 12829 sec.103 per the 2024 U.S. Code note; NISPPAC is continued to Sept 30, 2027 by EO 14354; no later change located.",
 sav="Incorporated amendment survives in a live host (TC09).",inf="No intervening 2025-2026 amendment of EO 12829 sec.103 beyond FR presidential-document search; 103(d) overlaps EO 14354 sec.2 delegation to NARA, which does not displace host text.")
P["EO:13811"]=dict(s="no",a="no",rule="ADV-R1",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance until Sept 30, 2019; sec.2 FACA delegation","President / listed agencies","32 committees","FACA","until Sept 30, 2019","2019-09-30","own end date; EO 13889 sec.3 superseded secs 1-2",["E13811_sec1","E13889_sup13811"]),
     C("sec.3 supersedes EO 13708 secs 1-2; revokes EO 13805","President","EOs 13708, 13805","constitutional","immediate","2017-09-30","spent pure revocation/supersession (TC07)",["E13811_sup13708","E13811_rev"]),
     C("sec.4 effective date","n/a","n/a","n/a","Sept 30, 2017","2017-09-30","spent",[])],
 ctrl=["E13889_sup13811"],srch=["FR API notes for 13811, 13889"],find="No amendments of other EOs; superseded by EO 13889.",sav="None.",inf="None material.")
P["EO:14109"]=dict(s="no",a="no",rule="ADV-R3",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance until Sept 30, 2025; sec.2 FACA delegation","President / listed agencies","37 committees","5 U.S.C. ch.10","until Sept 30, 2025","2025-09-30","own end date; EO 14354 sec.3 superseded secs 1-2",["E14109_until2025","E14354_sec3"]),
     C("sec.3 supersedes EO 14048 secs 1-2","President","EO 14048","constitutional","immediate","2023-09-30","spent",["E14109_sec3"]),
     C("sec.4 amends EO 14031 secs 2, 3 (AA/NHPI Commission and Initiative)","HHS; Commission","EO 14031","constitutional; FACA","incorporated amendment","2025-01-20","host EO 14031 revoked by EO 14148 (TC09)",["E14109_sec4","E14148_14031","E14031_revoked"]),
     C("sec.5 amends EO 14084 sec.2 (PCAH membership; liaison role)","IMLS; PCAH","EO 14084","constitutional; FACA","incorporated amendment","2025-01-20","host EO 14084 revoked by EO 14148 (TC09)",["E14109_sec5","E14148_14084","E14084_revoked"]),
     C("sec.6 effective date; sec.7 general provisions","n/a","n/a","n/a","Sept 30, 2023","2025-09-30","spent/residual boilerplate with no independent operative object",[])],
 ctrl=["E14354_sec3","E14148_14031","E14148_14084"],srch=["FR API notes for 14109, 14031, 14084, 14354","EO 14148 text"],find="Continuance superseded by EO 14354 and both amendment hosts revoked by EO 14148.",sav="None.",inf="None material.")
P["EO:14354"]=dict(s="yes",a="yes",rule="ADV-R6",conf="high",grade="official_publication",
 fp=[C("sec.1 continuance of 22 committees","President; listed agencies and committees","22 advisory committees","5 U.S.C. ch.10 (FACA); constitutional","until Sept 30, 2027",None,"unexpired at cutoff (2026-10-14)",["E14354_sec1","E14354_2027","E14354_nisppac"]),
     C("sec.2 FACA functions delegated to designated agency heads","listed agency heads","FACA functions for sec.1 committees","5 U.S.C. ch.10","tied to sec.1 committees",None,"continuing",["E14354_sec2"]),
     C("sec.3 supersedes EO 14109 secs 1-2","President","EO 14109","constitutional","immediate","2025-09-30","spent (TC07)",["E14354_sec3"]),
     C("sec.4 effective Sept 30, 2025; sec.5 general provisions","n/a","n/a","n/a","Sept 30, 2025",None,"effective; general provisions accompany continuing secs 1-2",["E14354_eff"])],
 ctrl=["E14354_2027","E14354_search","E14354_notes"],srch=["FR API notes for 14354","FR search 'Executive Order 14354' presidential docs 2025-10-07..2026"],
 find="Continuance runs to Sept 30, 2027, after the cutoff; no later presidential document amending, superseding or revoking EO 14354 found.",sav="n/a",inf="Bridge to cutoff relies on FR presidential-document search through publication date of retrieval (TC14).")

# ---- follow-up update (2026-10-16 ~17:10Z): holds resolved; limiting predicate made explicit ----
LP=("LIMITING PREDICATE (unruled convention): this 'no' assumes that once an advisory committee has terminated (under its host order's own sunset and/or 5 U.S.C. 1013(a)(2)) "
    "the host-order text establishing/structuring it, including text written by this amender, has no current operative effect, i.e. it is NOT a 'dormant' effect; "
    "revival would require a new presidential extension or re-establishment (TC11). If root rules that terminated-committee text in an unrevoked host is a dormant effect, this record becomes indeterminate/indeterminate.")
def setclause(iid,prefix,**kw):
    for c in P[iid]['fp']:
        if c['clause'].startswith(prefix):
            for k,v in kw.items():
                if k=='end_date': c['end']['date']=v
                elif k=='basis': c['end']['basis']=v
                elif k=='add': c['evidence_ids']+= [e for e in v if e not in c['evidence_ids']]
                else: c[k]=v
            return
    raise KeyError((iid,prefix))
# EO 13138
setclause("EO:13138","sec.7",time_or_condition="incorporated amendment (partly re-amended by EO 13385 sec.6); host sec.4(b) sunset 'unless sooner extended'",
  basis="PCAH under EO 12367 ended under host's own sunset (sec.4(b)) and FACA after its last extension expired Sept 30, 2017 (EO 13708); omitted from EO 13811 and every later continuance order; new PCAH created under EO 14084 in 2022 (revoked 2025) (ADV-R4). Subject to LIMITING PREDICATE (no dormant effect).",
  add=["E12367_sunset"])
P["EO:13138"]['ctrl']+=["E12367_sunset"]
P["EO:13138"]['sav']="EO 12367 has no located revocation; the 13138 sec.7 wording survives on paper in an unrevoked host whose committee ended Sept 30, 2017 under the host's own sunset (sec.4(b)) and FACA. "+LP
P["EO:13138"]['inf']=LP+" Also inferential: no unpublished presidential extension of the EO 12367 PCAH after Sept 30, 2017 (bounded FR checks), and non-extension of the EO 13115 task force (2000 FR notice reports its completed findings)."
# EO 13385
P["EO:13385"].update(s="no",a="no",conf="medium",rule="ADV-R4",hold=None)
setclause("EO:13385","sec.7",time_or_condition="incorporated amendment; host sec.1-402 sunset unless extended by further Executive order; last extension to Sept 30, 2025 (EO 14109 sec.1(f)); omitted from EO 14354",
  end_date="2025-09-30",basis="ILO committee terminated Sept 30, 2025: host's own sunset (EO 12216 sec.1-402) with no further extending EO (EO 14354 omits it; no 2025-2026 EO continues it), and 5 U.S.C. 1013(a)(2); DOL's charter renewals follow each presidential continuance (2023 notice: continued through Sept 30, 2025) and none issued after. Subject to LIMITING PREDICATE (no dormant effect).",
  add=["E12216_sunset","E_ilo_notice_2023","E_ilo_notice_2023b","E_ilo_fr_newest","E_eo_list_2025_2026","E14217_targets"])
setclause("EO:13385","sec.6",basis="PCAH ended under host's own sunset (EO 12367 sec.4(b)) and FACA after last extension to Sept 30, 2017; omitted thereafter; new PCAH under EO 14084 (ADV-R4). Subject to LIMITING PREDICATE.",add=["E12367_sunset"])
P["EO:13385"]['ctrl']+=["E12216_sunset","E_ilo_notice_2023","E_eo_list_2025_2026"]
P["EO:13385"]['srch']+=["Follow-up ladder: FR API all-document search for the ILO committee >= 2024-01-01 (0 hits); FR API list of all 303 EOs signed 2025-01-01..2026-10-14 (titles reviewed; only EO 14354 continues advisory committees); EO 14217/14238/14174/14236/14148 texts checked (no mention of EO 12216 or the ILO committee); DOL notice FR Doc 2023-23409; NARA codification of EO 12216; dol.gov ILAB pages (curl 403; Playwright 404; WebFetch DNS failure); WebSearch (no 2025-2026 record)"]
P["EO:13385"]['find']="All clauses ended. Sec.7's text survives formally in EO 12216 sec.1-101, but the committee terminated Sept 30, 2025 under the host's own sunset (1-402) and FACA: its last extension (EO 14109) ran to Sept 30, 2025, EO 14354 omits it, no other 2025-2026 EO extends it, and no DOL charter renewal or meeting notice appears after 2023."
P["EO:13385"]['sav']="Incorporated amendment (TC09) in EO 12216 considered; host unrevoked but its committee terminated. "+LP
P["EO:13385"]['inf']=LP+" Also inferential: absence of an unpublished presidential extension after Sept 30, 2025 (bounded by FR EO list and searches through 2026-10-14)."
# EO 13652
P["EO:13652"].update(s="no",a="no",conf="medium",rule="ADV-R4",hold=None)
setclause("EO:13652","sec.6",time_or_condition="incorporated amendment; NIAC last continued to Sept 30, 2025 (EO 14109 sec.1(q)); omitted from EO 14354",
  end_date="2025-09-30",basis="NIAC terminated Sept 30, 2025: DHS NIAC charter (filed 12/18/2023) sec.11 says it 'shall terminate on September 30, 2025, unless extended by the President'; no extension (EO 14354 omits NIAC; no 2025-2026 EO or FR document extends it); last listed meeting Dec 11, 2024; 5 U.S.C. 1013(a)(2). Subject to LIMITING PREDICATE (no dormant effect).",
  add=["E_niac_charter_term","E_niac_charter_basis","E_niac_last_meeting","E_niac_fr_newest","E_eo_list_2025_2026","E14217_targets"])
P["EO:13652"]['ctrl']+=["E_niac_charter_term","E_eo_list_2025_2026"]
P["EO:13652"]['srch']+=["Follow-up ladder: FR API all-document search 'National Infrastructure Advisory Council' >= 2025-01-01 (2 EPA rule hits only); FR API list of all 303 EOs signed 2025-01-01..2026-10-14; EO 14217/14238/14174/14236/14148 texts checked; cisa.gov NIAC pages (curl 403; WebFetch DNS failure; rendered via headless Chromium: main page, meetings page; NIAC charter PDF fetched in-browser); WebSearch (no termination/extension record)"]
P["EO:13652"]['find']="All clauses ended. Sec.6's NIAC text survives formally in EO 13231 sec.3, but NIAC terminated Sept 30, 2025 per its DHS charter (sec.11) and FACA: no presidential extension (EO 14354 omits NIAC; no other 2025-2026 EO), and CISA lists no meeting after Dec 11, 2024."
P["EO:13652"]['sav']="Incorporated amendment (TC09) in EO 13231 considered; host unrevoked but NIAC terminated. "+LP
P["EO:13652"]['inf']=LP+" Also inferential: absence of an unpublished presidential extension after Sept 30, 2025; CISA pages are rendered captures (not original bytes) except the charter PDF."
recs=[]
for iid,p in P.items():
    eids=sorted({e for c in p['fp'] for e in c['evidence_ids']}|set(p['ctrl']))
    for e in eids: assert e in ev,(iid,e)
    recs.append({"instrument_id":iid,"shard_id":"S9_ADV","family":"Advisory committee continuance","proposal_id":f"opus:s9:status:{iid}",
     "proposed_substantive_effect":p['s'],"proposed_any_operative_effect":p['a'],"operative_footprint":p['fp'],"footprint_complete":True,"text_obtained":True,
     "text_source_grade":p['grade'],"controlling_authority_evidence_ids":p['ctrl'],"subsequent_change_check":{"searched":p['srch'],"findings":p['find']},
     "savings_or_residual_considered":p['sav'],"rule_id":p['rule'],"evidence_ids":eids,"confidence":p['conf'],"hold_reason":p.get('hold'),
     "what_remains_inferential":p['inf'],"ownership_status":own[iid],"producer_state":"producer_supported_pending_independent_review"})
assert {r['instrument_id'] for r in recs}==set(own)
with open(os.path.join(base,'status_proposals.jsonl'),'w') as f:
    for r in recs: f.write(json.dumps(r,ensure_ascii=False)+'\n')
from collections import Counter
print(Counter((r['proposed_substantive_effect'],r['proposed_any_operative_effect']) for r in recs))
