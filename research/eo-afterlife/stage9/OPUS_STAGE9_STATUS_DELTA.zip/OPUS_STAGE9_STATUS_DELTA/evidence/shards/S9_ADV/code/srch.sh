#!/bin/bash
sid=$1; q=$2; from=$3
cd /tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/S9_ADV
for t in 1 2 3; do
 sleep 8
 code/fetch.sh $sid json "https://www.federalregister.gov/api/v1/documents.json?conditions%5Btype%5D%5B%5D=PRESDOCU&conditions%5Bterm%5D=$q&conditions%5Bpublication_date%5D%5Bgte%5D=$from&per_page=100&order=oldest&fields%5B%5D=executive_order_number&fields%5B%5D=title&fields%5B%5D=publication_date&fields%5B%5D=document_number&fields%5B%5D=citation&fields%5B%5D=subtype&fields%5B%5D=pdf_url" >/dev/null
 grep -q '"http_status": 200' cache/$sid.meta.json && break
done
python3 -I code/extract.py $PWD/cache $sid json >/dev/null 2>&1
python3 -I -c "
import json,sys
try: j=json.load(open('cache/$sid.json'))
except Exception as e: print('>> $sid FAILED'); sys.exit()
print('>>','$sid','count',j.get('count'), j.get('message',''))
for x in j.get('results',[]): print('  ',x['publication_date'],x.get('subtype'),x.get('executive_order_number'),x['document_number'],x['title'][:80])"
