// usage: node pw_fetch.js url outfile
const { chromium } = require('playwright');
(async () => {
  const [url, out] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' });
  let status = null;
  try { const r = await p.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 }); status = r ? r.status() : null; await p.waitForTimeout(4000); }
  catch (e) { console.log('ERR', e.message.split('\n')[0]); }
  require('fs').writeFileSync(out, await p.content());
  console.log(JSON.stringify({ url, final: p.url(), status }));
  await b.close();
})();
