const { chromium } = require('playwright');
(async () => {
  const [page, url, out] = process.argv.slice(2);
  const b = await chromium.launch();
  const p = await b.newPage({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' });
  await p.goto(page, { waitUntil: 'domcontentloaded', timeout: 45000 });
  const res = await p.evaluate(async (u) => { const r = await fetch(u); const a = new Uint8Array(await r.arrayBuffer()); let s=''; for (const x of a) s += String.fromCharCode(x); return { status: r.status, ct: r.headers.get('content-type'), b64: btoa(s) }; }, url);
  require('fs').writeFileSync(out, Buffer.from(res.b64, 'base64'));
  console.log(JSON.stringify({ url, status: res.status, ct: res.ct }));
  await b.close();
})();
