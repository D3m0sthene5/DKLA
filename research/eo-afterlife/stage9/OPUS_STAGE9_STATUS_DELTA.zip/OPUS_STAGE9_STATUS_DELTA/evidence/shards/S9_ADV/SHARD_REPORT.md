# S9_ADV shard report: advisory committee continuance orders

Actual UTC start: 2026-10-16T16:33:43Z. Actual UTC end: 2026-10-16T17:02:45Z.

## Counts (14 packet IDs)
- yes/yes: 2 (EO 14354 is continued to Sept 30, 2027, past the cutoff. EO 13708 sec.4 wording still sits in EO 12829 sec.103, whose committee, NISPPAC, is live.)
- no/no: 12 (EOs 11948, 12692, 12774, 13138, 13316, 13385, 13511, 13585, 13591, 13652, 13811, 14109). EO 13385 and EO 13652 changed from indeterminate in the follow-up below.
- indeterminate: 0
- Full text obtained: 14/14. 13 come from official FR PDFs on govinfo. EO 11948, 12692 and 12774 come from full FR issue PDFs, using only the pages that carry the order. Footprints complete: 14/14.

## Rules used
ADV-R1 (continuance expired and superseded), ADV-R3 (incorporated amendments ended: host revoked or superseded, text wholly rewritten, or subject ended), ADV-R4 (committee ended under its own sunset or under FACA 5 U.S.C. 1013(a)(2) after several unrenewed cycles; narrow), ADV-R5 (amendment survives in a live host), ADV-R6 (continuance not yet expired).

## New legal blockers
- Lapsed-committee convention. Some amendments sit in host EOs that were never revoked, but the committee itself dropped out of the continuance chain. For these, root should rule whether a committee that ended under FACA leaves a dormant effect. EO 13138 is decided `no` under ADV-R4 for EO 12367, the PCAH, which was last continued in 2017 and re-created under EO 14084 in 2022. This decision is sensitive to that ruling.
- The ILO committee (EO 12216) and NIAC (EO 13231) were continued only to Sept 30, 2025 and are omitted from EO 14354. I found no FR evidence that either was renewed afterwards. Because only one cycle has passed, I put both on hold instead of deciding them.

## Retrieval log (incl. standing-rule ladder)
- federalregister.gov API: 200 OK, but there were intermittent 403/empty responses under rate limiting. I retried with 6-8 s backoff and every retry succeeded.
- archives.gov EO disposition tables: 1976, 1978, 1989-bush and 1991 returned 200. 1979, 1980, 1982, 1993-clinton and the disposition-tables index returned 404, and retries with a browser user agent also returned 404. The Wayback CDX request failed with a connection reset. These tables were not needed: the FR API notes plus the order texts covered every fact.
- EO 12869 (successor to EO 12774): I downloaded the FR issues for 1993-10-01, 10-04 and 10-05 (each over 200 MB). The order did not appear on their contents pages, so I deleted them. I then used the APP transcript, graded hosted_transcript. EO 12774's own end date settles the result without it.
- uscode.house.gov (50 U.S.C. 3161): "Page Not Found" because the site is running in a temporary format. I used the govinfo link service instead, which returned the USCODE-2024 PDF (official).
- NARA ISOO: the compiled EO 12829 PDF (pre-13708) returned 200. eo-12829.html returned 404.
- media.defense.gov (1999 Coast Guard task force report): 403. I used the official FR notice of 2000-11-09 (FR Doc 00-28732), which reports the Task Force findings.
- cisa.gov NIAC pages: 403. WebSearch found only Wikipedia (NIAC inactive, omitted from EO 14354), which I did not use as evidence. facadatabase.gov loads (200) but is a dynamic app and was not queried. This is the open blocker in queue.jsonl.
- Proxy status check: denied by the permission classifier, so it was not used.

## Files
status_proposals.jsonl (14), evidence.jsonl (118 quotes; each one verified as an exact substring of cache/<source_id>.txt), rules.jsonl (5), queue.jsonl (2), conflicts.jsonl (3 finding-aid discrepancies; no ledger conflicts), cache/ (original bytes, meta, text), code/.

## Follow-up (standing-rule ladder for the two holds), UTC 2026-10-16T17:03:55Z to 2026-10-16T17:09:37Z
Records updated: EO 13385, EO 13652 and EO 13138, plus evidence.jsonl (now 129 entries). rules.jsonl and queue.jsonl were left unchanged, as the coordinator instructed. The two queue entries and ADV-R4's exception text about the ILO committee and NIAC are therefore superseded by the updated records.
- **NIAC (EO 13231; EO 13652 sec.6).** FR API all-document search for 2025-2026 found only 2 unrelated EPA rules. The FR API list of all 303 EOs signed 2025-01-01..2026-10-14 shows no extension: EO 14354 is the only continuance order. Texts of EOs 14148, 14174, 14217, 14236 and 14238 do not mention NIAC. cisa.gov returned 403 to curl, and WebFetch failed with a DNS error. Headless Chromium (Playwright) rendered the main page and the meetings page; the last meeting listed is Dec 11, 2024. The DHS NIAC charter PDF was then fetched in-browser (original bytes). Its sec.11 says NIAC "shall terminate on September 30, 2025, unless extended by the President". Result: NIAC terminated 2025-09-30, so EO 13652 is no/no (medium).
- **ILO committee (EO 12216; EO 13385 sec.7).** FR API all-document search for 2024-2026 returned 0 hits. The same 2025-2026 EO list shows no extension. The DOL notice of 2023-10-24 (FR Doc 2023-23409) says the committee was continued "for two years through September 30, 2025" and that DOL renews the charter after each presidential continuance; no renewal has appeared since. The NARA codification shows EO 12216 sec.1-402, under which the committee ends unless "extended by further Executive order". dol.gov returned 403 to curl, 404 to Playwright on the ILAB page, and a DNS failure to WebFetch. WebSearch found no 2025-2026 record. Result: the committee terminated 2025-09-30, so EO 13385 is no/no (medium).
- **EO 13138.** The 'no' for EO 12367 now also rests on that order's own sunset (sec.4(b), "unless sooner extended", per the NARA codification); the last extension ran to Sept 30, 2017. The 'no' still depends on an unruled premise: that the text of a terminated committee left in a host order that was never revoked is not a "dormant" effect. That premise is now written into each of the three records (13138, 13385, 13652) as an explicit LIMITING PREDICATE. If root rules the other way, all three become indeterminate.
- facadatabase.gov loads (HTTP 200) but is a dynamic Salesforce app; I found no usable API or CSV export for it, so it was not queried. No news or GAO primary document was found.
