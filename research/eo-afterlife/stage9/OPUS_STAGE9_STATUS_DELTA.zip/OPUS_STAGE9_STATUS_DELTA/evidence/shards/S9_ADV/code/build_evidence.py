import json,hashlib,os,sys
base=sys.argv[1]
sys.path.insert(0,os.path.join(base,'code'))
from evidence_specs import SPECS
GRADE={'fr_':'official_publication','fr_issue':'official_publication','frapi':'official_finding_aid (Federal Register API metadata)','frsearch':'official_finding_aid (Federal Register API search)','app_':'hosted_transcript','uscode':'official_publication (govinfo U.S. Code 2024 ed.)','nara_isoo':'agency_hosted_compilation (NARA ISOO)','nara_eo':'official_finding_aid (NARA disposition table)'}
def grade(s):
    if s=='cisa_niac_charter_2023': return 'agency_original_document (DHS NIAC charter PDF, fetched via headless browser)'
    if s.startswith('cisa_'): return 'agency_web_page (headless_render; not original bytes)'
    if s.startswith('frlist'): return 'official_finding_aid (Federal Register API list)'
    if s.startswith('nara_codif'): return 'official_compilation_historical (NARA Codification of Presidential Proclamations and EOs, 1945-1989)'
    for k in ['frsearch','frapi','fr_issue','fr_','app_','uscode','nara_isoo','nara_eo']:
        if s.startswith(k): return GRADE[k]
bad=0;out=[]
for eid,sid,q,loc,sup in SPECS:
    txt=os.path.join(base,'cache',sid+'.txt'); m=json.load(open(os.path.join(base,'cache',sid+'.meta.json')))
    t=open(txt,encoding='utf-8').read()
    if q not in t: print('MISSING',eid,repr(q)); bad+=1; continue
    out.append({"evidence_id":eid,"source_id":sid,"source_title":sid,"url":m['final_url'],"retrieved_utc":m['retrieved_utc'],
      "local_file":f"cache/{sid}.txt","local_file_sha256":hashlib.sha256(open(txt,'rb').read()).hexdigest(),
      "quote":q,"locator":loc,"retrieval_method":m['method']+'; '+m.get('extraction_method',''),"evidence_grade":grade(sid),"supports":sup})
if bad: sys.exit(1)
with open(os.path.join(base,'evidence.jsonl'),'w') as f:
    for o in out: f.write(json.dumps(o,ensure_ascii=False)+'\n')
print('ok',len(out))
