# S9_CLOSE_BOARD shard report (producer)

- Actual UTC start: 2026-10-16T16:33:42Z (`date -u` at first command)
- Actual UTC end: 2026-10-16T17:45:13Z (`date -u` before writing this report)
- Packet: 18 IDs (13 dated closings 1866-1935, 5 rail/airline board orders 1942-1948). Codebook 2.0.0, cutoff 2026-10-14.
- State of every record: producer_supported_pending_independent_review

## Counts by proposed status (substantive / any-effect)

| Status | Count | IDs |
|---|---|---|
| no / no | 17 | EO 5, 254, 2171, 3885-B, 4354, 4782, 5008, 5238, 5353, 5763, 6920, 7249, 9172, 9379, 9388, 9413, 9958 |
| indeterminate / indeterminate | 1 | EO 3885-A (no text found, on hold) |

- Texts obtained: 17 of 18. Footprints complete: 17 of 18.
- Text grades:
  - official_publication: 5 (EO 9172, 9379, 9388, 9413, 9958, each from the Federal Register daily issue PDF on govinfo, with the APP transcript used for clean quotes).
  - hosted_transcript: 12. Six come from APP (EO 5, 5238, 5353, 5763, 6920, 7249). Six come from contemporaneous newspaper reprints of the order text in LOC Chronicling America OCR (EO 254, 2171, 3885-B, 4354, 4782, 5008).
  - index_only: 1 (EO 3885-A).
- Confidence:
  - high: 12 (EO 5, 254, 2171, 5008, 5238, 5353, 5763, 6920, 7249, 9172, 9388, 9958)
  - medium: 5 (EO 3885-B, 4354, 4782, 9379, 9413)
  - low: 1 (EO 3885-A, held)

## Rules used
- `R-S9CB-DATED-CLOSING-SPENT` covers 12 closings. Each order was checked on its own text (TC16), and in every one each clause is tied to a stated past date. None contains a standing pay/leave rule or a general holiday rule.
  - EO 5353 has a second clause that defers EO 4644's summer four-hour Saturdays "to the second Saturday in June". The clause reads "In view of this order" and the order says it is "not to be deemed as establishing a precedent". Mapped under TC09, its footprint in EO 4644 is the 1930 season only (the first Saturday of June 1930). The Act of March 3, 1931 (46 Stat. 1482) later made four-hour Saturdays year-round.
  - EO 7249's shift clause is limited to "the dates specified".
  - EO 4354 says "as an experiment, not as a precedent".
- `R-S9CB-WARTIME-SPECIAL-WAGE-BOARD-SPENT` covers EO 9379, 9388 and 9413. Each board handled one dispute, and the order's "recommendations become effective" clause was used once. Completion evidence for each:
  - EO 9388: the board reported, and the Economic Stabilization Director's order of Nov. 4, 1943 authorized its recommendations. This is recited in EO 9413 as published in the FR.
  - EO 9379: the Director approved the board's recommended raise, per a Nov. 4, 1943 wire story. The OCR is poor.
  - EO 9413: the dispute was settled on Jan. 17-18, 1944 by an agreement the Director approved. The board chairman said such an agreement "would end the work of the board". Sources are the NMB FY1944 report and newspapers.
  - For all three: EO 9801 (Nov. 9, 1946) ended all Stabilization Act wage controls "including any Executive order ... issued thereunder", and EO 9883 revoked the Panel the members came from. EO 9801 has a savings clause for suits on rights or liabilities incurred before Nov. 9, 1946. I considered it and treated it as saved liabilities, not a current EO effect (TC04/TC08). No live proceeding was found. The reviewer may weigh this clause differently.
- `R-S9CB-RLA10-BOARD-SUPERSEDED-AND-REPORTED` covers EO 9958. EO 9965 superseded it on June 3, 1948. The same board reported on July 9, 1948 (PEB No. 62), and the statutory status quo ended 30 days later. EO 12553 revoked EO 9965 in 1986.
- EO 9172 uses no shared rule (rule_id null). It was revoked in full by EO 9883 (Aug. 11, 1947; 12 FR 5481), with no savings clause. The NMB says the Panel operated until Aug. 11, 1947 and was not funded after June 30, 1947.
- RLA sec. 10 (45 U.S.C. 160): the source credit shows no change since 1934, so the 1942-1948 text is the same as the current text. The statute requires a separate board for each dispute and a report within 30 days, with the status quo lasting until 30 days after the report. It has **no express clause** dissolving the board on report, so no proposal relies on one.

## Retrieval failures and ladder log (STANDING RULE)
- uscode.house.gov (45 U.S.C. 160/181): curl returned HTTP 200 with an "Under Maintenance" page. Switched to the govinfo USCODE 2022/2023/2024 HTML (success) and Cornell LII 160/181 (success).
- mocat.library.unt.edu (Monthly Catalog entries): curl returned 403 "Access Denied"; WebFetch returned ENOTFOUND. These were locator-only and not needed.
- prrths.com (PRR chronology PDFs): DNS failure. Not needed.
- LOC loc.gov search: intermittent 503 errors, truncated JSON and a Cloudflare challenge on `?st=text` views. Fixed by retrying with backoff and using the JSON API plus the tile.loc.gov full-text service.
- api.govinfo.gov search with DEMO_KEY: OVER_RATE_LIMIT. Retried with backoff; partial results only, locator-only.
- CourtListener API: v4 throttled and v3 needs auth. Switched to the web search page (success).
- APP: the first EO 9172 slug returned 404. The search page gave the right slug (success). EO 254, 2171, 3885-A/B, 4354, 4782, 5008 and 4644 are not on APP (number search and date-window search).
- **EO 3885-A (held).** Steps tried:
  - APP number search and the Aug. 2-10, 1923 date window
  - Wikisource Coolidge EO index (3885-A is a redlink)
  - WebSearch, which turns up only the Wikipedia list (index only)
  - LOC Chronicling America, Aug. 4-8, 1923: 3885-B text and the Aug. 6 extension (3885-D) found, but no "approved" document
  - Lord list (index only)

  What would settle it: the original in NARA, or a 1923 State Department printing.
- EO 4644 (host for EO 5353): text not found in APP or Chronicling America (May 9-11, 1927). Its subject comes from the Lord entry only. This does not affect EO 5353, whose footprint ended in June 1930.

## New legal blockers
- None that are new. EO 3885-A is held for missing text only.

## Counterevidence checked
- NARA disposition tables for 1942, 1943, 1944, 1946, 1947 and 1948.
- The Lord list, searched for later "E. O. <n>" references to each closing order. Only 3885-D (amending 3885-B for the same days) and 5353 (amending 4644) were found.
- APP searches.
- CourtListener: EO 9172 is cited only in 1948-1952 cases; no opinions cite 9379, 9388, 9413, 9958 or 9965.
- NMB annual reports for FY1943, 1944, 1945, 1947 and 1948.

## Files
- `status_proposals.jsonl` (18), `evidence.jsonl` (91; every quote was checked by script as an exact substring of the `.txt`), `rules.jsonl` (3), `queue.jsonl` (1), `conflicts.jsonl` (2, informational; ledger not changed)
- `cache/` holds original bytes, `.meta.json` and `.txt` files. Scripts are in `code/`. `code/attempts.log` records the early failures.
