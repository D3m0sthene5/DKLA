import json, hashlib, os, sys, re
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S9 = os.path.dirname(os.path.dirname(R))
def load(p): return open(p, encoding='utf-8', errors='replace').read()
items = [
 # id, local file (relative to review dir or abs), start anchor, end anchor, locator, supports
 ("RV-01","cache/ia_ob03.txt","8 -Hour Law Suspended on Marine","after this date. _","OB Oct. 29, 1918 p.22 (EO 2950; page image n555 viewed by reviewer)","EO 2950 full text re-fetched; byte-identical to producer copy"),
 ("RV-02","cache/ia_compgen_v7.txt","It is obvious that the purpose","the restoration of the eight-hour day.","7 Comp. Gen. 76 (1927)","1917 suspension authorized only to hasten preparation for the emergency; authority ceased when need ceased"),
 ("RV-03","cache/ia_compgen_v7.txt","gency that caused their suspension by Executive order","emergency had passed.","7 Comp. Gen. 76-77 (1927)","restoration by operation of law; suspension conditioned upon continuance of the national emergency"),
 ("RV-04","cache/ia_compgen_v7.txt","“ Liberty Loan Building: For completion of the construction of two additional","the Butler Building, and the Auditor’s Building.","7 Comp. Gen. 474 (Feb. 13, 1928)","Liberty Loan Building (EO 2933 object) an existing Treasury building by 1927-28; two additional stories under a 1927 appropriation and new contract"),
 ("RV-05","cache/ia_sectreas_1920.txt","EXTENSIONS  PLACED  UNDER  CONTRACT  DURING  THE  FISCAL  YEAR  1920.","Butler  Building.","Secretary of the Treasury Annual Report FY1920, Supervising Architect lists","Butler Building extension placed under contract FY1920 (post-armistice)"),
 ("RV-06","cache/ia_sectreas_1921.txt","EXTENSION  COMPLETED  DURINO  THE  FISCAL  YEAR  1921.","Butler  Building.","Secretary of the Treasury Annual Report FY1921, Supervising Architect lists","Butler Building extension completed FY1921 (by June 30, 1921) (EO 2931)"),
 ("RV-07","cache/ia_usnm_1919.txt","The building erected in the east court of the Natural History Build-","occupancy of the building","USNM Report FY1919 (buildings section)","temporary building in National Museum court erected, occupied by War Risk Bureau and turned over to Museum by June 30, 1919 (EO 2935)"),
 ("RV-08","cache/ia_rchs_23.txt","Oct. 27. Dedication ceremonies under the auspices of the","remodeled Courthouse.","Records of the Columbia Historical Society vol. 23, Chronicler's Report for 1919, p. 229","remodeled D.C. Courthouse dedicated Oct. 27, 1919 (EO 2942)"),
 ("RV-09","cache/ia_ebis_2010.txt","The East Boston Immigration Station was constructed in 1919-1920","The East Boston Immigration Station opened in April 1920.","Boston Landmarks Commission, East Boston Immigration Station Study Report (2010), Description","Boston immigrant station built 1919-1920, opened April 1920 (EO 2947); later upper-story additions late 1920s/1930s"),
 ("RV-10","cache/ia_reportofchemist1919unit.txt","The  laboratory  under  construction  at  Arlington","the  coming  year.","Report of the Chemist FY1919, p. 21-22","Arlington lab under construction, loaned to Ordnance Nitrate Division during the war, to be ready for occupancy FY1920 (EO 2986)"),
 ("RV-11","cache/ia_reportofchemist1920unit.txt","Toward  the  end  of  the  year  the  laboratory  was  moved  to  the","completely  equipped.","Report of the Chemist FY1920","laboratory moved into the color laboratory building at Arlington Farm by end of FY1920 (EO 2986)"),
 ("RV-12","cache/ia_phs_1919.txt","Baltimore,  Md.  (act  Mar.  28, 1918):","Balance  June  30, 1919 6, 206. 14","PHS Surgeon General report FY1919, miscellaneous appropriations, marine hospitals","Mar. 28, 1918 marine hospital funds largely unexpended at June 30, 1919 (EO 2950)"),
 ("RV-13","cache/ia_annualreportofsu1920unit.txt","Baltimore,  Md.  (act  Mnr.  28,  1918)  :","Balance,  June  30,  1920 5,932.14","PHS Surgeon General report FY1920, p. 365-366","Mar. 28, 1918 marine hospital funds still largely unexpended at June 30, 1920; Boston: no FY1920 expenditure (EO 2950)"),
 ("RV-14","cache/ia_annualreportofsu1920unit.txt","Boston,  Mass.   (act  June  5,  1920) __: $54,300.00","Savannah,  Ga.  (act  June  5,  1920) 34,000.00","PHS Surgeon General report FY1920, p. 366 (under Supervising Architect)","new post-war marine hospital appropriations 1919-1920 for Boston, Savannah (continuing construction at named hospitals) (EO 2950)"),
 ("RV-15","cache/stat_42_105.txt","CHAP. 40.—Joint Resolution Terminating the state of war","is hereby declared at an end.","42 Stat. 105 (July 2, 1921)","state of war with Germany declared at an end July 2, 1921"),
 ("RV-16",os.path.join(S9,"shards/S9_WWI/cache/stat_41_1359.txt"),"CHAP. 136.—Joint Resolution Declaring that certain Acts of Congress, joint","shall be construed and treated as the date","41 Stat. 1359 (Mar. 3, 1921), pilot cache (read by reviewer)","for Acts, joint resolutions and proclamations the present war / present or existing emergency treated as ended on the resolution's effective date"),
 ("RV-17",os.path.join(S9,"shards/S9_WWI/cache/stat_76_357.txt"),"SEC. 203. The following statutes are hereby repealed:","outstanding at the time of the enactment of this Act.","76 Stat. 360 sec. 203 (pilot cache, read by reviewer)","1962 repeal; savings for contracts existing on effective date"),
 ("RV-18",os.path.join(S9,"shards/S9_WWI/cache/stat_37_137.txt"),"The President, by Execu-","or a time when","37 Stat. 138 sec. 2 (pilot cache)","1912 Act waiver power: specific contracts during time of war or when war is imminent (authority for D.C. contract exceptions)"),
]
out=[]
for eid,lf,a,b,loc,sup in items:
    p = lf if os.path.isabs(lf) else os.path.join(R,lf)
    t = load(p)
    rx=lambda x: r"\s+".join(re.escape(w) for w in x.split())
    ma = re.search(rx(a), t); mb = re.search(rx(b), t[ma.start():])
    i = ma.start(); j = ma.start()+mb.end()
    q = t[i:j]
    assert q in t and len(q) < 4000, (eid, len(q))
    sha = hashlib.sha256(open(p,'rb').read()).hexdigest()
    mp = p.rsplit('.',1)[0]+'.meta.json'
    if p.endswith('.txt') and os.path.exists(p[:-4]+'.pdf'): mp = p[:-4]+'.meta.json'
    m = json.load(open(mp)) if os.path.exists(mp) else {}
    out.append({"evidence_id":eid,"local_file":os.path.relpath(p,R),"sha256":sha,"url":m.get('url'),"retrieved_utc":m.get('retrieved_utc'),"quote":q,"locator":loc,"supports":sup})
with open(os.path.join(R,'reviewer_evidence.jsonl'),'w') as f:
    for o in out: f.write(json.dumps(o, ensure_ascii=False)+'\n')
for o in out: print(o['evidence_id'], len(o['quote']), o['retrieved_utc'], o['local_file'][-40:])
