import json, hashlib, os, sys
shard = sys.argv[1]
cache = {}
def sha(p):
    if p not in cache:
        cache[p] = hashlib.sha256(open(p,'rb').read()).hexdigest()
    return cache[p]
out=[]
for l in open(os.path.join(shard,'evidence.jsonl')):
    e=json.loads(l)
    lf=os.path.join(shard,e['local_file']); tf=os.path.join(shard,e.get('text_file') or e['local_file'])
    r={'id':e['evidence_id'],'local_exists':os.path.exists(lf)}
    r['sha_local']= os.path.exists(lf) and sha(lf)==e['local_file_sha256']
    if e.get('text_file_sha256') and os.path.exists(tf):
        r['sha_text']= sha(tf)==e['text_file_sha256']
    txt=open(tf,encoding='utf-8',errors='replace').read() if os.path.exists(tf) else ''
    r['quote_in_text']= e['quote'] in txt
    r['grade']=e['evidence_grade']; r['src']=e['source_id']; r['loc']=str(e.get('locator'))[:90]
    r['supports']=str(e.get('supports'))[:80]
    print(json.dumps(r))
