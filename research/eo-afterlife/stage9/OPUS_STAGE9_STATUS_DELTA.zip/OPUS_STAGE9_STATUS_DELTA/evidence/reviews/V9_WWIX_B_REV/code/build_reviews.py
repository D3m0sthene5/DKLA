import json, os
R = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SH = os.path.join(os.path.dirname(os.path.dirname(R)), 'shards', 'S9_WWIX_B')
ev = {}
for l in open(os.path.join(R, 'reviewer_evidence.jsonl')):
    e = json.loads(l); ev[e['evidence_id']] = e
props = [json.loads(l) for l in open(os.path.join(SH, 'status_proposals.jsonl'))]

LAPSE = ("Decisive ground (reviewer): the 1962 Act alone does not close this order. Pub. L. 87-581 sec. 203 keeps the repealed statutes, "
 "including the 40 U.S.C. 326 suspension power, applying to contracts existing on 1962-10-12, so closing on the 1962 Act alone needs a showing "
 "that no contract under the order existed then (or that any such contract has since been fully performed). The producer only infers that from "
 "absence of evidence; it is not shown. The order closes instead because its suspension ended long before 1962: the order rests on a "
 "national-emergency finding that its own text ties to WWI war activities/war measures; the Comptroller General (7 Comp. Gen. 76-77, 1927; RV-02, RV-03) "
 "holds that a suspension under the 1917 proviso was 'conditioned upon the continuance of the national emergency' and that the eight-hour law "
 "returned 'by operation of law' when the emergency passed; the state of war was declared at an end July 2, 1921 (42 Stat. 105; RV-15) and the "
 "Mar. 3, 1921 joint resolution treats the 'present or existing emergency' as ended for Acts and proclamations (RV-16). A savings clause keeps "
 "the law for existing contracts; it does not revive a suspension that had already lapsed. First cessation unpinned (Nov. 1918 to 1921); latest 1962-10-12 (TC13).")
DC_LAPSE = ("Decisive ground (reviewer): the operative clause itself declares the work an emergency 'relating to the conduct of the present war' (ground i). "
 "Authority is not cited; the likeliest source is the 1912 Act sec. 2 power to waive for specific contracts 'during time of war' (RV-18). The war ended "
 "July 2, 1921 (RV-15; see also RV-16). Any 1962 savings for contracts (RV-17) cannot revive an exception that had already ended; D.C. day labor was repealed outright.")
COMMON_LAW = ['RV-02', 'RV-03', 'RV-15', 'RV-16', 'RV-17']
DC_LAW = ['RV-18', 'RV-15', 'RV-16', 'RV-17']

R_ = {}
def rec(i, verdict, problems, dissent, evids, rp=True, tc=True, ref=True, fp=True):
    R_[i] = dict(verdict=verdict, problems=problems, dissent=dissent, evids=evids, rp=rp, tc=tc, ref=ref, fp=fp)

rec('2883', 'accept', ["None material. Text re-fetched (OB vol. 1, byte-identical). 'during the present national emergency' is an express WWI term and is the only end ground for this continuing object (all existing and future Lighthouse contracts), as the producer says. The CG 1927 rule (RV-02/03) confirms the suspension lapsed with the emergency, so the 1962 savings clause cannot reach it."],
    "First cessation unpinned; outer legal bound 1921 (RV-15/16).", COMMON_LAW)
rec('2902', 'accept', ["None. Completion documented (building accepted Aug. 4, 1919, XB-E29). Text re-fetched (OB vol. 2, byte-identical)."], "", COMMON_LAW[:2])
rec('2924', 'accept', ["None. Fixed term 'until December 1, 1918'. The overtime proviso ('time and a-half for overtime work spent upon said construction') attaches only to the sidewalk work during the exception, so it ended 1918-12-01. Accrued claims are historical (TC04) and time-barred."], "", DC_LAW)
rec('2928', 'accept', ["Hold is correct. My own four further archive.org full-text queries ('fuel storage and distribution yards', 'Government fuel yards', 'fuel yards' + 'eight hours', Bureau of Mines + 'distribution yards') found only the Lord 1944 entries and National Union Catalog headings, no text (log: code/fts_2928.log). Under TC15 it cannot be 'no'."],
    "Not upgraded.", [], rp=None, tc=False, ref=False, fp=False)
rec('2931', 'accept_with_correction', [
    "Status no/no stands; the reasoning needs correcting.",
    "The producer treats this as a 1918 job with completion undocumented. The Treasury annual reports show the Butler Building extension was placed under contract in FY1920 (after the armistice) and completed in FY1921, i.e. by June 30, 1921 (RV-05, RV-06). Equating it with the order's 'remodeling and extending of the annex' is by description.",
    "Rule P5's 'projects were 1918 jobs' is wrong for this order, and its 'no evidence of any 1962-existing contract' is an inference, not a showing.",
    LAPSE],
    "If the emergency-lapse ground were rejected, completion by June 1921 (RV-06) would still close the project scope.", COMMON_LAW + ['RV-05', 'RV-06'], rp=False)
rec('2933', 'accept_with_correction', [
    "Status no/no stands; the reasoning needs correcting.",
    "Completion evidence: by 1927-28 the Liberty Loan Building (the temporary building south of the Bureau of Engraving and Printing) was an existing Treasury office building (RV-04).",
    "The same source shows two more stories were built under a 1927 appropriation and a new contract. So construction on 'the' building happened again, and a project-completion reading alone would not exclude that later work. Only the emergency lapse excludes it.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "", COMMON_LAW + ['RV-04'], rp=False)
rec('2935', 'accept_with_correction', [
    "Status no/no stands; completion is now documented.",
    "The USNM report for FY1919 says the building erected in the east court of the Natural History Building by the Bureau of War Risk Insurance was turned over to the Museum when that occupancy ended, by June 30, 1919 (RV-07). Equating it with the order's 'temporary building in the court of the National Museum' is by description.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "", COMMON_LAW + ['RV-07'], rp=False)
rec('2942', 'accept_with_correction', [
    "Status no/no stands; completion is now documented: the remodeled D.C. Courthouse was dedicated on Oct. 27, 1919 (RV-08).",
    "An archive.org full-text snippet (not read in full) shows that 41 Stat. carries further money 'for reconstruction and furnishing of the courthouse'. Any such later work falls outside the lapsed emergency.",
    "The text does not use the words 'national emergency'. It invokes the 1917 national-emergency power because the War Department urgently needed the courts' temporary quarters, and that is a war tie.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "", COMMON_LAW + ['RV-08'], rp=False)
rec('2947', 'accept_with_correction', [
    "Status no/no stands; completion is now documented: the East Boston Immigration Station was built in 1919-1920 and opened in April 1920 (RV-09).",
    "The source is the Boston Landmarks Commission study report (2010), a secondary source citing the Commissioner-General's FY1920 report, p. 181, which I did not read.",
    "Upper-story additions were built in the late 1920s or 1930s. They show that the 'construction, etc.' scope recurred, and only the emergency lapse excludes them.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "", COMMON_LAW + ['RV-09'], rp=False)
rec('2950', 'accept_with_correction', [
    "Status no/no is reachable only on a different ground. The producer's ground fails.",
    "Rule predicate P3(b), 'a single identified construction project', is NOT met (TC16 counterexample). The order covers 'construction, remodeling, etc.' of the buildings of six hospitals; I confirmed the wording myself on page image n555.",
    "The Mar. 28, 1918 funds for these hospitals were largely unspent at June 30, 1919 and June 30, 1920 (RV-12, RV-13). Boston had no spending at all in FY1920, and Baltimore still had $15,767 of $17,985 left. New construction money for Boston and Savannah followed in 1919-1920 (RV-14).",
    "So completion cannot be shown, and the work at these continuing hospitals did not end as one finite project. The producer's 'project completion + no 1962 contract' basis is unsupported.",
    "Maintenance scope: 'etc.' is in the printed text. Whether repair was covered cannot be settled from the text, and after the emergency lapsed it does not matter.",
    LAPSE],
    "LIMITING: this record rests entirely on the emergency-lapse ground (order's war-activities emergency finding + 7 Comp. Gen. 76-77 + 1921 end of war). If the coordinator does not accept that ground for orders with no express time term, 2950 must be indeterminate/indeterminate (no completion evidence exists).",
    ['RV-01', 'RV-12', 'RV-13', 'RV-14'] + COMMON_LAW, rp=False)
rec('2961', 'accept_with_correction', [
    "Status no/no stands, but on the order's own war tie, not on project completion.",
    "The operative clause declares the paving operations 'emergency work relating to the conduct of the present war'. That closes the producer's own worry about later paving in the same area: later paving is not war emergency work.",
    "The FY1919 D.C. report (XB-E34) does not name this job, so completion stays inferential.",
    "The overtime proviso ('time and half for overtime work spent upon said construction') attaches only to the excepted operations and ends with the exception. Accrued claims are historical (TC04).",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    DC_LAPSE],
    "", DC_LAW, rp=False)
rec('2969', 'accept', ["None material. The term is 'for the period of the war'. Lord notes the instrument has the form of a proclamation; if it is treated as one, the Mar. 3, 1921 joint resolution applies to it directly (RV-16). Either way the war ended by July 2, 1921 (RV-15). The viaduct was practically complete in FY1919. The overtime proviso is limited to 'the construction of the said viaduct'."], "", DC_LAW)
rec('2976', 'accept_with_correction', [
    "Status no/no is reachable only on the emergency-lapse ground.",
    "The vessel Pilot has no record of completion or cancellation. My own searches found only the 1917-18 plans and the item replacing the Taku, the Monthly Catalog summary of the order, and no Pilot in the FY1920 C&GS fleet accounting (per producer). So the project scope cannot be closed.",
    "The order says the vessel was 'needed for work in connection with war measures', which ties its national emergency to the war.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "LIMITING: same as 2950. If the emergency-lapse ground is not accepted, this record must be indeterminate (no completion or cancellation evidence).",
    COMMON_LAW, rp=False)
rec('2977', 'accept', ["None material. The wharf was rebuilt by D.C. day labor and was occupied again by FY1919 (XB-E32, XB-E33). The 1962 Act repealed day-labor coverage outright, with no savings clause. The overtime proviso is limited to 'the reconstruction of the said wharf'. The order declares the work an emergency 'relating to the conduct of the war', which is an extra end ground."], "", DC_LAW)
rec('2980', 'accept', ["Minor: the phrase 'four or more' launches is open-ended. Completion of four is documented (XB-E30). Any further launches would fall after the emergency lapsed (RV-02/03)."], "", COMMON_LAW[:2])
rec('2986', 'accept_with_correction', [
    "Status no/no stands; completion is now documented. The Chemist's FY1919 report has the Arlington laboratory still under construction, lent to the Ordnance Nitrate Division during the war (RV-10). By the end of FY1920 the laboratory had moved into the color laboratory building at Arlington Farm, though it was not yet fully equipped (RV-11). Equating that building with the order's 'additions to the old building ... for color investigations' is by description.",
    "The caps (no Sunday work, no more than 10 hours a day) are conditions on the suspension and end with it. Afterwards the stricter eight-hour law governed until 1962. They create no independent continuing norm.",
    "Rule P5's 'no 1962 contract' is inferred, not shown.",
    LAPSE],
    "", COMMON_LAW + ['RV-10', 'RV-11'], rp=False)
rec('2988', 'accept', ["None. Completed June 1919 (XB-E31)."], "", COMMON_LAW[:2])
rec('2999', 'accept', [
    "The question was when the 'present national emergency' ended for an order issued after the armistice. The President still treated the WWI emergency as present on Nov. 18, 1918.",
    "Under 7 Comp. Gen. 76-77 the suspension lasted only while that emergency continued. The Navy treated it as over at the armistice. The legal outer bound is 1921: the joint resolution of Mar. 3, 1921 for Acts and proclamations (RV-16), and the end of the state of war on July 2, 1921 (RV-15).",
    "The scope is also limited to alterations funded by the FY1919 repair appropriation. Its wage clause only refers back to the 1917 statute.",
    "The exact first cessation is unpinned (TC13). The status is unaffected."], "", COMMON_LAW)

out = []
for p in props:
    iid = p['instrument_id']; n = iid.split(':')[1]; r = R_[n]
    sub = p['proposed_substantive_effect']; anyx = p['proposed_any_operative_effect']
    out.append({
        "instrument_id": iid, "proposal_id": p['proposal_id'], "reviewer": "V9_WWIX_B_REV",
        "verdict": r['verdict'],
        "reviewer_substantive_effect": sub, "reviewer_any_operative_effect": anyx,
        "checks": {"quotes_exact": True, "sha_match": True, "text_complete": r['tc'], "refetched": r['ref'],
                   "footprint_complete": r['fp'], "law_checked": True, "later_changes_checked": True,
                   "rule_predicates_met": r['rp']},
        "problems": r['problems'],
        "dissent_or_limiting_predicates": r['dissent'],
        "reviewer_evidence": [{k: ev[e][k] for k in ("local_file", "sha256", "url", "retrieved_utc", "quote")} | {"evidence_id": e, "locator": ev[e]['locator']} for e in r['evids']],
        "text_refetch": None if n == '2928' else "Official U.S. Bulletin vols. 1-3 djvu OCR re-fetched by reviewer (cache/ia_ob01|02|03.txt), sha256 identical to producer/pilot copies; producer quotes are exact substrings",
    })
with open(os.path.join(R, 'reviews.jsonl'), 'w') as f:
    for o in out: f.write(json.dumps(o, ensure_ascii=False) + '\n')
from collections import Counter
print(len(out), Counter(o['verdict'] for o in out))
