# V9_WWIX_B_REV: independent review of shard S9_WWIX_B

- **Reviewer:** V9_WWIX_B_REV
- **Rules:** Codebook 2.0.0. Cutoff 2026-10-14, America/New_York.
- **Actual UTC times:**
  - Start: 2026-10-16T17:44:09Z.
  - End: 2026-10-16T19:30:33Z.
  - Work paused for a usage-limit break partway through; the exact pause times were not logged.
- **Proposals file reviewed:** `status_proposals.jsonl`, sha256 844c296f…a13a, mtime 17:41:54Z. It did not change during the review.
- **Outputs:**
  - `reviews.jsonl` (18 records).
  - `reviewer_evidence.jsonl` (RV-01 to RV-18). Every quote is checked by script as an exact substring of its file, with sha256.
  - `cache/`: original bytes plus a `.meta.json` with the real retrieval UTC.
  - `code/`: scripts and search logs.
  - `view/`: crops of page image n555.
- **Disk:** no PDF is larger than 20 MB.

## Verdict counts

| verdict | n | IDs |
|---|---|---|
| accept | 9 | 2883, 2902, 2924, 2969, 2977, 2980, 2988, 2999 (no/no); 2928 (indeterminate hold) |
| accept_with_correction | 9 | 2931, 2933, 2935, 2942, 2947, 2950, 2961, 2976, 2986 |
| reject_to_indeterminate | 0 | (but see the sensitivity note for 2950 and 2976) |
| reject_other | 0 | |

**Error rate** (non-accept / total) = 9/18 = **50%**.

- All 9 corrections are the medium-confidence project orders.
- In every one of them the stated ground for `no` was not shown on the record.
- The statuses survive only on a different ground, which I established myself (problem 1 below).

## What I checked

1. **Evidence fidelity.**
   - All 34 producer evidence items match: sha256 and exact-substring checks pass (`code/check_evidence.py`).
2. **Re-fetching the texts.**
   - I re-fetched Official U.S. Bulletin vols. 1-3 from archive.org. They are byte-identical to the producer and pilot copies.
   - I checked EO 2950 myself on page image n555. The words "construction, remodeling, etc." are in the printed text.
   - All 17 texts are complete as printed. Their source grade is hosted_transcript.
3. **Law I read myself.**
   - 39 Stat. 1192; 37 Stat. 138 sec. 2; 41 Stat. 1359-60 (Mar. 3, 1921); 76 Stat. 360 secs. 202-204.
   - 42 Stat. 105 (July 2, 1921, which ended the war). I fetched this one new.
   - 7 Comp. Gen. 74-77 (1927) and 474 (1928). I re-fetched these.
4. **Later changes.**
   - I relied on the pilot's search of both Lord 1944 volumes.
   - I added my own archive.org full-text searches (logs in `code/fts_*.log`).
   - I found no amending, extending or reviving order.

## Key findings

### 1. The 1962 Act alone does not close the medium orders. The producer's "no 1962 contract" is inferred, not shown.

- Pub. L. 87-581 sec. 203 saves "the provisions of such statutes" for contracts existing on 1962-10-12. That includes the 40 U.S.C. 326 suspension power.
- So an EO suspension that was still operative in 1962 would have kept governing any such contract.
- To close an order on the 1962 Act alone, you must show that no contract under it existed on that date, or that any such contract was later fully performed. The producer showed neither; it only found no evidence of one.
- Under the codebook, a residual with no proved surviving subjects leaves any-effect indeterminate. So that ground fails.

**What does close these orders** is that the suspension ended long before 1962:

- Every covered order's own text ties its "national emergency" finding to WWI war activities or war measures. The D.C. orders say "the present war."
- The Comptroller General (7 Comp. Gen. 76-77, 1927) held that a suspension under the 1917 proviso was "conditioned upon the continuance of the national emergency." When the emergency passed, the eight-hour law came back "by operation of law."
- The state of war was declared at an end on July 2, 1921 (42 Stat. 105).
- The Mar. 3, 1921 joint resolution treats the "present or existing emergency" as ended for Acts and proclamations.
- A savings clause keeps the law in force for existing contracts. It does not revive a suspension that had already lapsed.
- This answers the brief's question (iii): a 1962-contract showing becomes unnecessary only because of this earlier lapse, not because of the 1962 Act.

### 2. Completion evidence I found (agency and annual reports)

| Order | Evidence | Source |
|---|---|---|
| 2931 | Butler Building extension placed under contract FY1920, completed FY1921 | Treasury annual reports, RV-05/06 |
| 2933 | Liberty Loan Building was an existing Treasury building by 1927-28 | 7 Comp. Gen. 474, RV-04 |
| 2935 | Building in the National Museum court turned over to the Museum by June 30, 1919 | U.S. National Museum report FY1919, RV-07 |
| 2942 | Remodeled courthouse dedicated Oct. 27, 1919 | Records of the Columbia Historical Society vol. 23, RV-08 |
| 2947 | Built 1919-20, opened April 1920 | 2010 Boston Landmarks Commission study, secondary source, RV-09 |
| 2986 | Lab occupied by end of FY1920 | Chemist's reports FY1919/1920, RV-10/11 |

- In each case, I matched the documented building to the order's project from its description.

### 3. Counterexamples to project-scope reasoning (TC16)

These orders fail rule S9WWIX-R1 P3(b)/P5 as the producer stated them:

- **2950 (six marine hospitals).**
  - This is not "a single identified 1918 project."
  - The Mar. 28, 1918 funds were still largely unspent at June 30, 1920. Boston spent nothing in FY1920 (RV-12/13).
  - New construction money for Boston and Savannah followed in 1919-20 (RV-14).
  - Completion cannot be shown. The order stands **only** on the emergency-lapse ground in finding 1.
- **2933 and 2947.**
  - Construction on the same building happened again later: two more stories on the Liberty Loan Building in 1927-28, and upper stories at East Boston in the late 1920s or 1930s.
  - A completion reading alone would not exclude that later work. The emergency lapse does.
- **2931.** The work was contracted after the armistice (FY1920), so it was not a "1918 job."
- **2976 (vessel Pilot).** I found no record of completion or cancellation. The order stands only on the emergency-lapse ground.
- **2961 (D.C. paving).** The order closes on its own words, "emergency work relating to the conduct of the present war." Its completion is not specifically documented.

### 4. Clauses checked specifically

- **D.C. overtime provisos (2924, 2961, 2969, 2977).** Each grants time and a half "upon said construction" or "said operations." That ties it to the excepted work, so each ends with its exception:
  - 2924 ended on 1918-12-01.
  - 2969 and 2977 ended with completed work (FY1919), and with the end of the war.
  - 2961 ended with its war tie.
  - Accrued claims are historical (TC04).
- **2986 caps** (no Sunday work, no more than 10 hours a day). These are conditions on the suspension, so they end with it.
- **2999** (issued Nov. 18, 1918, with "present national emergency"):
  - The emergency is the WWI emergency, which the President still treated as present after the armistice.
  - Under 7 Comp. Gen. 76-77 the suspension lasted only while that emergency continued.
  - Its legal outer bound is 1921 (Mar. 3, 1921 joint resolution; July 2, 1921 end of war).
  - The first-cessation date is unpinned (TC13).
- **2969.** Lord says it has the form of a proclamation. If it is treated as one, the 1921 joint resolution applies to it directly.
- **2928 hold is correct.** My own 4 further searches found only the Lord list and catalog headings.

## Sensitivity (for the coordinator; the stricter view prevails at integration)

- **2950 and 2976** have no completion evidence. They rest wholly on the emergency-lapse ground (the order's war-activities emergency finding, 7 Comp. Gen. 76-77, and the 1921 end of the war).
  - If that ground is not accepted for orders with no express time term, both become indeterminate/indeterminate. The error rate stays 9/18, with 2 of the 9 moving to reject_to_indeterminate.
- **2961** has the stronger text tie ("the present war"), but its completion is likewise only inferred.
- **Rule S9WWIX-R1 should be narrowed:**
  - Rebase P5 on the emergency-lapse ground.
  - Drop the "1918 jobs" and "no 1962 contract" premises.
  - Move 2950 out of P3(b).

## Not verified

- No signed originals; the texts come only from the Bulletin printing.
- The Commissioner-General's FY1920 report (cited by the Boston study) was not read.
- The 41 Stat. courthouse appropriation was seen only as a search snippet.
- The Pilot's fate is unknown.
- The specific completion date of the 2961 paving job is unknown.
- The Lord 1944 list was not re-read by me; I relied on the pilot reviewer's search.
