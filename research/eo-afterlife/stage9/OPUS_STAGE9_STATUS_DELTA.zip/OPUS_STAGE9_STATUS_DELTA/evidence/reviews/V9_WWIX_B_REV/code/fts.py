import json,sys,urllib.parse,subprocess
q=sys.argv[1]; n=int(sys.argv[2]) if len(sys.argv)>2 else 25
u="https://archive.org/services/search/beta/page_production/?service_backend=fts&user_query="+urllib.parse.quote(q)+f"&hits_per_page={n}&page=1"
out=subprocess.run(["curl","-sS","--max-time","90",u],capture_output=True).stdout
try: d=json.loads(out)
except Exception as e: print("ERR",out[:200]); sys.exit()
b=d['response']['body']
if not b: print("ERR",d['response'].get('errors')); sys.exit()
print("Q:",q,"total",b['hits'].get('total'))
for h in b['hits']['hits']:
    f=h['fields']; hl=(h.get('highlight') or {}).get('text',[''])
    print(' ',f.get('identifier'),'|',str(f.get('title'))[:60],'|',f.get('year'),'|',(hl[0] if hl else '')[:160].replace('\n',' '))
