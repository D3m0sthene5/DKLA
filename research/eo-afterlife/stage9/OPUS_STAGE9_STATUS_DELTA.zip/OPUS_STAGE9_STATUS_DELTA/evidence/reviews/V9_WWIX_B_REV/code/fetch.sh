#!/bin/bash
# usage: fetch.sh <source_id> <url> <ext>
set -u
R=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWIX_B_REV
SID="$1"; URL="$2"; EXT="$3"
OUT="$R/cache/$SID.$EXT"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
RES=$(curl -sSL -A "Mozilla/5.0 (X11; Linux x86_64) research-afterlife-EOs" --retry 2 --max-time 300 -o "$OUT" -w '%{http_code}\t%{url_effective}\t%{content_type}' "$URL")
CODE=$(echo "$RES"|cut -f1); FINAL=$(echo "$RES"|cut -f2); CT=$(echo "$RES"|cut -f3)
SHA=$(sha256sum "$OUT"|cut -d' ' -f1)
python3 -I -c "
import json,sys,os,hashlib,subprocess
a=sys.argv[1:]
sid,url,final,ts,code,ct,sha,out,ext=a
m={'source_id':sid,'url':url,'final_url':final,'retrieved_utc':ts,'http_status':int(code) if code.isdigit() else code,'content_type':ct,'sha256':sha,'method':'curl original bytes','local_file':'cache/'+os.path.basename(out),'reviewer':'V9_WWIX_B_REV'}
if ext=='pdf':
    t=out[:-4]+'.txt'; subprocess.run(['pdftotext','-layout',out,t]); m['text_file']='cache/'+os.path.basename(t); m['text_sha256']=hashlib.sha256(open(t,'rb').read()).hexdigest(); m['text_extraction_method']='pdftotext -layout'
json.dump(m,open(out.rsplit('.',1)[0]+'.meta.json','w'),indent=1)
print(sid,code,sha,os.path.getsize(out),final[:100])
" "$SID" "$URL" "$FINAL" "$TS" "$CODE" "$CT" "$SHA" "$OUT" "$EXT"
