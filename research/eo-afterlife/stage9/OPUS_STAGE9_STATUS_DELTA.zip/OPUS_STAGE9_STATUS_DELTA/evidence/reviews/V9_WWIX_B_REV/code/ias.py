import json,sys,urllib.parse,subprocess
q=sys.argv[1]
u="https://archive.org/advancedsearch.php?q="+urllib.parse.quote(q)+"&fl[]=identifier&fl[]=title&fl[]=year&fl[]=date&rows=40&output=json"
d=json.loads(subprocess.run(["curl","-sS","--max-time","60",u],capture_output=True).stdout)
print("Q:",q,d['response']['numFound'])
for x in d['response']['docs']: print(' ',x['identifier'],'|',str(x.get('title'))[:90],'|',x.get('year'),x.get('date'))
