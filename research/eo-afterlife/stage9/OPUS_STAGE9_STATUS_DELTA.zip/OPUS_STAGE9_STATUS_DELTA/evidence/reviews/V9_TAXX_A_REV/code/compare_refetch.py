import json,glob,os,sys
B=sys.argv[1]
prod={}
for f in glob.glob(B+'shards/S9_TAXX_A/cache/fr_*.meta.json'):
    m=json.load(open(f)); sid=os.path.basename(f)[:-10]
    prod[sid]=m.get('original_sha256') or m.get('sha256'), m
out={}
for f in sorted(glob.glob(B+'reviews/V9_TAXX_A_REV/cache/fr/fr_*.meta.json')):
    m=json.load(open(f)); sid=os.path.basename(f)[:-10]
    p=prod.get(sid)
    pj=json.dumps(p[1]) if p else ''
    same = m['sha256'] in pj
    out[sid]={'reviewer_sha256':m['sha256'],'reviewer_retrieved_utc':m['retrieved_utc'],'producer_meta_has_same_sha':same}
    print(sid,m['retrieved_utc'],m['sha256'][:16],'IDENTICAL' if same else 'DIFF')
json.dump(out,open(B+'reviews/V9_TAXX_A_REV/refetch_comparison.json','w'),indent=1)
