import sys,re
f,num=sys.argv[1],sys.argv[2]
before=int(sys.argv[3]) if len(sys.argv)>3 else 2000
t=open(f,encoding='utf-8',errors='replace').read()
ms=[m.start() for m in re.finditer(r'No\.\s*'+re.escape(num),t)]
if not ms: print('NOT FOUND',num); sys.exit()
for i in ms[:1]:
    seg=t[max(0,i-before):i+40]
    j=seg.rfind('EXECUTIVE ORDER')
    print(seg[j:] if j>=0 else seg)
