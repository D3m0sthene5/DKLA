#!/bin/bash
# usage: gsearch.sh NAME 'QUERY'
N=$1; Q=$2; T=$(date -u +%Y-%m-%dT%H:%M:%SZ)
python3 -I -c 'import json,sys; print(json.dumps({"query":sys.argv[1],"pageSize":100,"offsetMark":"*","sorts":[{"field":"publishdate","sortOrder":"ASC"}]}))' "$Q" > /tmp/gq_$N.json
curl -sS -X POST "https://api.govinfo.gov/search?api_key=DEMO_KEY" -H 'Content-Type: application/json' --data @/tmp/gq_$N.json -o cache/govinfo_search/$N.json
S=$(sha256sum cache/govinfo_search/$N.json|cut -d' ' -f1)
echo "{\"url\":\"https://api.govinfo.gov/search (POST)\",\"query\":$(python3 -I -c 'import json,sys;print(json.dumps(sys.argv[1]))' "$Q"),\"retrieved_utc\":\"$T\",\"sha256\":\"$S\",\"method\":\"curl original bytes\"}" > cache/govinfo_search/$N.meta.json
python3 -I -c 'import json,sys; d=json.load(open(sys.argv[1])); print("count",d.get("count")); [print(r["packageId"],r.get("granuleId")) for r in d.get("results",[])]' cache/govinfo_search/$N.json
