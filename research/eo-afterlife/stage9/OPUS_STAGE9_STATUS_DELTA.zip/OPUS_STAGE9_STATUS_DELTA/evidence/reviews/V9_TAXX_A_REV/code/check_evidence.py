import json,hashlib,sys,os,collections
B=sys.argv[1]
E={};res={}
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
for l in open(B+'shards/S9_TAXX_A/evidence.jsonl'):
    d=json.loads(l); E[d['evidence_id']]=d
    r={}
    lf=B+d['local_file']; tf=B+d['text_file']
    r['local_exists']=os.path.exists(lf); r['text_exists']=os.path.exists(tf)
    r['local_sha']= r['local_exists'] and sha(lf)==d['local_file_sha256']
    r['text_sha']= r['text_exists'] and sha(tf)==d['text_sha256']
    txt=open(tf,encoding='utf-8',errors='replace').read() if r['text_exists'] else ''
    r['quote']= d['quote'] in txt
    # meta check
    mf=d.get('meta_file')
    if mf and os.path.exists(B+mf):
        m=json.load(open(B+mf))
        r['meta_sha_consistent']= d['local_file_sha256'] in json.dumps(m)
        if d.get('original_bytes_sha256'): r['meta_orig_sha']= d['original_bytes_sha256'] in json.dumps(m)
    res[d['evidence_id']]=r
bad={k:v for k,v in res.items() if not all(v.values())}
print('records',len(res),'bad',len(bad))
for k,v in bad.items(): print(k,v)
# proposals refs
P=[json.loads(l) for l in open(B+'shards/S9_TAXX_A/status_proposals.jsonl')]
per={}
for p in P:
    ids=set(p['evidence_ids'])|set(p['controlling_authority_evidence_ids'])
    for c in p['operative_footprint']: ids|=set(c['evidence_ids'])
    miss=[i for i in ids if i not in E]
    badp=[i for i in ids if i in bad]
    per[p['instrument_id']]={'n':len(ids),'missing':miss,'bad':badp}
    if miss or badp: print(p['instrument_id'],miss,badp)
json.dump({'per_record':res,'per_proposal':per},open(B+'reviews/V9_TAXX_A_REV/evidence_check.json','w'),indent=1)
print('proposals',len(P))
