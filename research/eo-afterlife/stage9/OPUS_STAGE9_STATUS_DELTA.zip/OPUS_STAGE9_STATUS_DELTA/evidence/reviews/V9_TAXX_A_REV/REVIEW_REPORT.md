# V9_TAXX_A_REV review of shard S9_TAXX_A

- Reviewer: V9_TAXX_A_REV. I am independent and did not produce this shard. Codebook 2.0.0; cutoff 2026-10-14.
- Actual UTC start: 2026-10-16T17:47:32Z. Actual UTC end: 2026-10-16T19:40Z. The run was paused once for a usage-limit reset.
- Outputs:
  - reviews.jsonl (42 records)
  - evidence_check.json
  - refetch_comparison.json
  - attempts.log
  - cache/ (original bytes or extracted text, each with a meta.json)
  - code/
- Ownership: every record stays OWNERSHIP_NOT_VERIFIED. Nothing is promoted.

## Counts by verdict (reviewer status: substantive / any-effect)

| Verdict | Count | Reviewer status | Orders |
|---|---|---|---|
| accept | 2 | indeterminate / indeterminate | holds 10316, 10447 |
| accept_with_correction | 6 | no / no | 7933-A, 8131, 9345, 9444, 9448, 9455 |
| reject_to_indeterminate | 34 | no / indeterminate | every other proposed no/no, i.e. all orders from EO 9764 (July 1946) on, except the two holds |
| reject_other | 0 | | |

- Error rate (non-accept / total) is 40/42 = 95%.
  - Every reject comes from one systematic issue: the confidentiality ruling below.
  - The 6 corrections are reasoning-only.
  - No substantive status is disputed. All 40 substantive "no" findings are accepted.

## Gate 1: evidence fidelity (script: code/check_evidence.py)
All 188 producer evidence records pass all three checks:
- the local-file sha256 matches;
- the text-file sha256 matches;
- each quote is an exact substring of its text file.

The meta files carry the same sha256 values. Every evidence id cited in a proposal exists.

## Gate 2: re-fetch (stratified sample: 19 packet orders plus amender 10801)
- I re-fetched 20 Federal Register daily issues from govinfo. All 20 are byte-identical to the producer's original bytes (refetch_comparison.json). They cover:
  - all 11 branch-(b) orders: 7933-A, 8131, 9345, 9444, 9448, 9455, 9764, 9812, 10132, 10279, 10304;
  - the variants 10518, 10275 and 10326, plus 10703 with its amender 10801;
  - the holds 10316 and 10447;
  - 10412 and 10855.
- I read every operative grant in my own pdftotext output. In each one, the recipient, purpose resolution and time limit match the producer's footprint.
- Variants confirmed:
  - 10518: "until and including January 3, 1955".
  - 10275: limited to the first session of the 82d Congress.
  - 10326: limited to the second session of the 82d Congress.
  - 10801 changes 10703 to read "during the Eighty-fifth Congress and as long as the Committee is authorized to act during the Eighty-sixth Congress", effective noon Jan 3, 1959.
- A script confirmed the own-text limit of all 29 branch-(a) orders in the producer's verified quotes.
- Branch (b) end evidence: I re-fetched the NARA guide chapters (House 4, 14, 22; Senate 8, 13, 18), and all 13 producer quotes (S01-S13) are found verbatim. End dates are latest bounds (TC13).
- EO 10304: I re-fetched the APP page.
  - APP prints the EO 10316 text (Senate Armed Services, "continuous watchfulness") under 10304's date, and its title also says Armed Services.
  - The FR (16 FR 11631) and T.D. 5866 show the Senate Committee on the District of Columbia and S.Res. 136 (82d).
  - The producer was right to follow the FR.
- Holds:
  - 10316 is open-ended, covers returns through 1950 (1939-Code returns), and its committee still exists.
  - 10447 is tied to S.Res. 245 "as extended by" S.Res. 47; Judiciary still exists; NARA shows the subcommittee's records running 1952-66.
  - Both holds stand.
- Later changes: I scanned 139 cached NARA disposition-table pages (pilot reviewer's copies plus the producer's) for every packet number. The only hits outside each order's own-year table were false positives on FR page numbers (e.g. "38 FR 8131"). There were no new amendments or revocations.

## MAIN ISSUE: the Treasury confidentiality clause

### Fact
From T.D. 5525 (Aug 1946, for EO 9764) on, every Treasury decision approved with these orders says: "Any information thus obtained by the committee or subcommittee shall be held confidential", except that relevant portions may be submitted to the House or Senate. This includes:
- the general regulations T.D. 6064 (26 CFR 458.321, 1954) and T.D. 6132 (301.6103(a)-101, 1955), which later orders incorporate.

I checked that the clause covers 36 of the 42 orders: 9764, 9812, 10132 (and 10279 through it), and every order from 1951 on, including the two holds.

The six earlier orders (7933-A, 8131, 9345, 9444, 9448, 9455) do not have it. Their T.D.s (4849, the 1939 T.D., 5268, 5200/5375, 5378/5390) only say that relevant information "may be submitted by the committee to the House".

### Ruling (1): the clause is part of the order's footprint
- Each order grants inspection "subject to the conditions stated in the Treasury decision ... approved by me this date" (or "in accordance and upon compliance with" the approved rules).
- The governing statute (1939 Code sec. 55(a); 1954 Code sec. 6103(a)) makes the President's approval of those rules part of the legal act.
- T.D. 6064 itself says inspection "shall be subject to the conditions and restrictions imposed by the Executive order and the rules and regulations".
- So the clause is an incorporated condition of the order's permission (TC09/TC08), not a free-standing Treasury rule.
- It is a residual, post-inspection term. It is not a substantive grant, so substantive can be "no" while it remains open (TC03).

### Ruling (2): it is not shown to have ended
- **"Part 458 is [Reserved]" is not a removal.**
  - The 2026 eCFR shows only the range "Parts 421-499 [Reserved]", and so does the 26 CFR Parts 300-499 edition of Apr 1, 1981.
  - Part 458 was still being amended on Aug 26, 1961 (T.D. 6570, new 458.326).
  - So it left the CFR between 1961 and 1981. I found no Federal Register document removing or redesignating it.
  - 301.6103(a)-101 was revised in 1975-76 and is absent from the 1981 text. The 1978-79 LSA entries list 301.6103(a)-(f) removals in volume 43 of the Federal Register, but the OCR lost the page numbers, so I did not retrieve the document.
- **The "duty runs with the committee's authority" theory fails on the text.**
  - The duty attaches to "information thus obtained", with no time term.
  - A confidentiality duty that lapsed when the inspection permission lapsed would defeat its own purpose.
- **The "26 U.S.C. 6103(f)/7213 now govern" theory is not proved for these orders.**
  - Every packet order reaches 1939-Code returns.
  - 26 U.S.C. 7851(a)(6)(A) applies subtitle F (6103/7213) to 1939-Code taxes "only" to a limited extent.
  - 7851(b)(1) continues "all rights and liabilities under such code".
  - 301.6103(a)-1 (T.D. 7723, 1980) carries pre-1977 order terms forward only for "a Federal agency", not for Congress. That is silent on committees either way.
- **The records the duty covers still exist.**
  - NARA's Senate guide, sec. 1.32, says: "Certain other records are closed by statute or Executive order of the President, such as income tax returns".
  - Committee records holding Treasury-furnished tax data survive, under chamber/NARA custody.

### Ruling (3): result
The confidentiality term is unresolved. Under TC04 and the codebook inference protocol ("Residual terms with no proved surviving subjects yield indeterminate any-effect"), any-effect is **indeterminate** for every order whose approved regulations carry the clause, while substantive stays **no**.

This applies equally to branch (a) and branch (b) orders:
- for branch (b), the custodian of the information (the chamber/NARA) outlives the committee;
- the producer's alternative reading ("only actor is the ended committee") is recorded as a dissent.

The record would close to no/no if either of these were retrieved:
- the Federal Register removal of the approved regulations, read as reaching information already obtained; or
- authority that post-1976 6103 governs pre-1977 congressional holdings of pre-1954 return information to the exclusion of the order terms.

### Reach to the accepted pilot (shards/S9_TAX; not edited)
Applied consistently, the ruling reaches 6 of the 8 accepted pilot "no/no" records. They should move to substantive no / any-effect indeterminate:
- **EO 10455** (T.D. 6012 carries the clause);
- **EO 10566** (inside 10455, TC09);
- **EO 11020, 11720, 11786, 11900** (all incorporate T.D. 6132 / 301.6103(a)-101; 11900 incorporates it "as amended").

11786 and 11900 reach only 1954-Code returns. For them, closure through the 1976 6103 rewrite is the most plausible, but the removal document is still unretrieved.

EO 9281 is not affected: T.D. 5200 has no confidentiality term (checked in the pilot's FR 1942-12-12 text). EO 6342 is not affected as far as checked: the pilot found no post-inspection term. I did not re-read its T.D. myself.

## Other systematic problems
1. Every proposal repeats "the only post-inspection term is the T.D. confidentiality proviso", including the six pre-1946 orders, where it is false. Those six are corrected, and their status is unchanged.
2. Every proposal says "Part 458 is [Reserved]". The correct statement is a range reservation (Parts 421-499) with no removal notice found.
3. Two holds remain:
   - 10316: 1939-Code continuity and a committee that still exists;
   - 10447: the end of the S.Res. 245/47 authority is not shown.

## Not verified
- I did not re-fetch orders outside the sample. Their texts rest on the producer's FR copies, whose sha256 hashes and quotes I verified by script.
- I did not repeat the APP citation searches. The NARA table scan was re-run.
- The removal or redesignation of 26 CFR Part 458 and of 301.6103(a)-101 was not retrieved:
  - the govinfo full-text search hit its DEMO_KEY rate limit after the first query;
  - Wayback is unavailable in this session;
  - HathiTrust and Google Books return a CAPTCHA.
  
  The first search did work: 38 FR hits for "Part 458" with "inspection of returns", the last on 1961-08-26. A later, keyed govinfo search for "Part 458" in 1961-1981 and for 43 FR 1978-79 "301.6103" should settle it. See attempts.log.
