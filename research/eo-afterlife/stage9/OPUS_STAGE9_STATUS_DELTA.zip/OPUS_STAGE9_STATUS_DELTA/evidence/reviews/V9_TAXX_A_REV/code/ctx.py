import sys,re
f,pat=sys.argv[1],sys.argv[2]; a=int(sys.argv[3]); b=int(sys.argv[4])
t=open(f,encoding='utf-8',errors='replace').read()
for m in list(re.finditer(pat,t))[:int(sys.argv[5]) if len(sys.argv)>5 else 2]:
    print('-----@',m.start()); print(t[max(0,m.start()-a):m.start()+b])
