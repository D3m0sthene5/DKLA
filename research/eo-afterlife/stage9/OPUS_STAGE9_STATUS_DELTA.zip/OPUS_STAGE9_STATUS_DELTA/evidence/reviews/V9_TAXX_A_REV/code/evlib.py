import json,hashlib,re,os
B='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/'
R=B+'reviews/V9_TAXX_A_REV/'
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
def ev(textfile, pattern, url, retrieved, extra=None, maxlen=400):
    """Return evidence dict with an exact slice of textfile matching regex pattern (DOTALL)."""
    p=B+textfile
    t=open(p,encoding='utf-8',errors='replace').read()
    m=re.search(pattern,t,re.S)
    if not m: raise SystemExit('PATTERN NOT FOUND: %s in %s'%(pattern,textfile))
    q=t[m.start():m.end()][:maxlen]
    assert q in t
    d={'local_file':textfile,'sha256':sha(p),'url':url,'retrieved_utc':retrieved,'quote':q}
    if extra: d.update(extra)
    return d
def frmeta(date):
    m=json.load(open(R+'cache/fr/fr_%s.meta.json'%date))
    return m
def fr_ev(date, pattern, maxlen=400):
    m=frmeta(date)
    return ev('reviews/V9_TAXX_A_REV/cache/fr/fr_%s.full.raw.txt'%date, pattern, m['url'], m['retrieved_utc'],
              {'original_bytes_sha256':m['sha256'],'note':'reviewer re-fetch; quote from pdftotext -raw of the reviewer copy; original bytes byte-identical to producer copy'},maxlen)
