import json,re,sys,os
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from evlib import *
P=[json.loads(l) for l in open(B+'shards/S9_TAXX_A/status_proposals.jsonl')]
PE={}
for l in open(B+'shards/S9_TAXX_A/evidence.jsonl'):
    d=json.loads(l); PE[d['evidence_id']]=d
chk=json.load(open(R+'evidence_check.json'))

def order_text(date, num, maxlen=1400):
    t=open(B+'reviews/V9_TAXX_A_REV/cache/fr/fr_%s.full.raw.txt'%date,encoding='utf-8',errors='replace').read()
    ANCH={'7933':r'I\s*n\s*spection\s+op\s+I\s*ncom','8131':r'section\s+257\s+\(a\)\s+of\s+the\s+Revenue\s+Act\s+of\s+1926','9448':r'EXECUTIVE ORDER 944#'}
    a=re.search(ANCH.get(num, r'(ORDER|Order)\s+'+re.escape(num)),t)
    if not a: raise SystemExit('no anchor %s'%num)
    s=re.search(r'([Ii]t\s+is\s+(here[\u00ad\-\s]*by\s+)?or[\u00ad\-\s]*dered|I hereby\s+order|is hereby amended)',t[a.start():a.start()+3000])
    if not s: raise SystemExit('no ordered %s'%num)
    st=a.start()+s.start()
    seg=t[st:st+maxlen]
    e=re.search(r'(subject to|such inspection|This Executive order|This order)',seg[100:])
    q=seg[:100+e.start()] if e else seg
    m=frmeta(date)
    return {'local_file':'reviews/V9_TAXX_A_REV/cache/fr/fr_%s.full.raw.txt'%date,'sha256':sha(B+'reviews/V9_TAXX_A_REV/cache/fr/fr_%s.full.raw.txt'%date),
            'url':m['url'],'retrieved_utc':m['retrieved_utc'],'original_bytes_sha256':m['sha256'],'quote':q,
            'note':'reviewer re-fetch of FR issue (byte-identical to producer copy); operative grant of EO '+num}

CONF=r'Any\s+in[­fo\-\s]*r?mation\s+thus\s+(ob[­\-\s]*)?tained.{0,140}?con[­\-\s]*fi[­\-\s]*den[­\-\s]*tial.{0,40}'
def prod_ev(textfile, pattern, srcmeta):
    m=json.load(open(B+srcmeta))
    return ev(textfile, pattern, m['url'], m['retrieved_utc'], {'note':'producer cache file, read-only; sha256 verified by reviewer'})
def conf_mine(date): 
    d=fr_ev(date, CONF); d['note']='confidentiality proviso of the Treasury decision approved with the order (reviewer re-fetch)'; return d
CONF_SHORT=r'shall\s+b[eè]\s+held\s+con[\u00ad\-\s]*fi[\u00ad\-\s]*den[\u00ad\-\s]*tial'
def conf_prod(fn, meta):
    t=open(B+'shards/S9_TAXX_A/cache/'+fn,encoding='utf-8',errors='replace').read()
    pat=CONF if re.search(CONF,t,re.S) else CONF_SHORT
    d=prod_ev('shards/S9_TAXX_A/cache/'+fn, pat, 'shards/S9_TAXX_A/cache/'+meta); d['note']='confidentiality proviso of the Treasury decision approved with the order (producer file, read-only, sha verified)'; return d

def conf_pp(date):
    m=json.load(open(B+'shards/S9_TAXX_A/cache/fr_%s.meta.json'%date))
    d=ev('reviews/V9_TAXX_A_REV/cache/prodpdf_text/fr_%s.raw.txt'%date, CONF, m['url'], m['retrieved_utc'],
         {'original_bytes_sha256':m.get('sha256'),'note':'reviewer pdftotext -raw of the producer original-bytes PDF (sha verified); confidentiality proviso of the T.D. approved with the order'})
    return d
clause_ev={
 'EO:9764':lambda: conf_pp('1946-08-03'),
 'EO:9812':lambda: conf_mine('1946-12-21'),
 'EO:10132':lambda: conf_mine('1950-06-20'),
 'EO:10279':lambda: conf_mine('1950-06-20'),
 'EO:10275':lambda: conf_mine('1951-07-26'),
 'EO:10304':lambda: conf_mine('1951-11-16'),
 'EO:10316':lambda: conf_prod('fr_1952-01-01.raw_p17.txt','fr_1952-01-01.meta.json'),
 'EO:10321':lambda: conf_pp('1952-01-26'),
 'EO:10326':lambda: conf_mine('1952-02-13'),
 'EO:10331':lambda: conf_pp('1952-03-06'),
 'EO:10343':lambda: conf_prod('fr_1952-04-15.raw_p61.txt','fr_1952-04-15.meta.json'),
 'EO:10412':lambda: conf_mine('1952-11-18'),
 'EO:10435':lambda: conf_pp('1953-02-10'),
 'EO:10442':lambda: conf_pp('1953-04-02'),
 'EO:10447':lambda: conf_mine('1953-04-24'),
}
for n in ['10518','10527','10551','10564','10572']: clause_ev['EO:'+n]=lambda: conf_mine('1954-02-13')
for n in ['10606','10607','10620','10627','10699','10701','10703','10706','10712','10806','10808','10815','10818','10846','10855','10871']:
    clause_ev['EO:'+n]=lambda: conf_pp('1955-05-05')
PRE46=['EO:7933a','EO:8131','EO:9345','EO:9444','EO:9448','EO:9455']
pre46_td={ # evidence that the approved T.D. has only a permissive submission term
 'EO:7933a':lambda: fr_ev('1938-08-09', r'Any inforation thus obtained by.{0,200}?to the House\.'),
 'EO:8131':lambda: prod_ev('shards/S9_TAXX_A/cache/fr_1939-05-16.raw_p08.txt', r'Any\s+information.{0,220}?to the House', 'shards/S9_TAXX_A/cache/fr_1939-05-16.meta.json'),
 'EO:9345':lambda: prod_ev('shards/S9_TAXX_A/cache/fr_1943-06-01.raw_p18.txt', r'Any\s+information thus obtained by the com.{0,200}?House of\s+Representatives\.', 'shards/S9_TAXX_A/cache/fr_1943-06-01.meta.json'),
 'EO:9444':lambda: fr_ev('1944-05-30', r'Treasury Decision 5200,1approved De.{0,300}?1943\.”'),
 'EO:9448':lambda: fr_ev('1944-06-13', r'Any information thus ob\S*\s+tained by the committee or the subcom.{0,160}?to the House\.'),
 'EO:9455b':lambda: fr_ev('1944-06-13', r'Any information thus ob\S*\s+tained by the committee or the subcom.{0,160}?to the House\.'),
 'EO:9455':lambda: fr_ev('1944-07-14', r'and subject to the rules and regulations\s+prescribed in Treasury Decision 5378, ap.{0,30}'),
}
sample={'EO:7933a':'1938-08-09','EO:8131':'1939-05-16','EO:9345':'1943-05-29','EO:9444':'1944-05-30','EO:9448':'1944-06-13','EO:9455':'1944-07-14',
 'EO:9764':'1946-07-31','EO:9812':'1946-12-21','EO:10132':'1950-06-20','EO:10275':'1951-07-26','EO:10279':'1951-08-18','EO:10304':'1951-11-16',
 'EO:10316':'1952-01-01','EO:10326':'1952-02-13','EO:10412':'1952-11-18','EO:10447':'1953-04-24','EO:10518':'1954-02-13','EO:10703':'1957-03-20','EO:10855':'1959-12-01'}

def nara(n, pat):
    m=json.load(open(R+'cache/nara/%s.meta.json'%n))
    return ev('reviews/V9_TAXX_A_REV/cache/nara/%s.txt'%n, pat, m['url'], m['retrieved_utc'], {'note':'reviewer re-fetch (bs4 text, whitespace collapsed)'})
mf=json.load(open(R+'cache/archive_org/cfr26_300-499_1981_djvu.meta.json'))
mb=json.load(open(R+'cache/fr_big/fr_1961-08-26.meta.json'))
mc=json.load(open(R+'cache/cfr/cfr1997_301-6103a-1.meta.json'))
m7851=json.load(open(B+'shards/S9_TAX/cache/govinfo_usc26_7851.meta.json'))
COMMON=[
 nara('senate_chapter-01', r'Certain other records are closed by statute or Executive order of the President, such as income tax returns and national security classified information\.'),
 ev('reviews/V9_TAXX_A_REV/cache/archive_org/cfr26_300-499_1981_djvu.txt', r'PARTS 421-499[^\n]*', mf['url'], mf['retrieved_utc'], {'note':'26 CFR Parts 300-499 rev. Apr 1, 1981 (archive.org OCR of official CFR): Parts 421-499 already reserved by 1981'}),
 ev('reviews/V9_TAXX_A_REV/cache/archive_org/cfr26_300-499_1981_djvu.txt', r'301\.6103\(a\)-101 \(a\) revised', mf['url'], mf['retrieved_utc'], {'note':'LSA 1975-1976 entry in the 1981 volume; section absent from the 1981 text'}),
 ev('reviews/V9_TAXX_A_REV/cache/fr_big/fr_1961-08-26.full.raw.txt', r'\[T\.D\. 6570\].{0,250}?PART 458— INSPECTION OF RETURNS', mb['url'], mb['retrieved_utc'], {'original_bytes_sha256':mb['sha256'],'note':'Part 458 still amended Aug 26, 1961 (T.D. 6570, new 458.326); PDF deleted after extraction (64 MB)'}),
 ev('reviews/V9_TAXX_A_REV/cache/cfr/cfr1997_301-6103a-1.xml', r'to an officer or employee of a Federal agency \(as defined in section 6103\(b\)\(9\)\)', mc['url'], mc['retrieved_utc'], {'note':'301.6103(a)-1 (T.D. 7723, 1980) carries pre-1977 order terms forward only for Federal agencies'}),
 ev('shards/S9_TAX/cache/govinfo_usc26_7851.txt', r'The\s+provisions\s+of\s+subtitle\s+F\s+shall\s+apply\s+with\s+respect\s+to\s+any\s+tax\s+imposed\s+by\s+the\s+Internal\s+Revenue\s+Code\s+of\s+1939\s+only', m7851['url'], m7851['retrieved_utc'], {'note':'pilot cache file read-only; 26 U.S.C. 7851(a)(6)(A)'}),
 ev('shards/S9_TAX/cache/govinfo_usc26_7851.txt', r'all\s+rights\s+and\s+liabilities\s+under\s+such\s+code\s+shall\s+continue', m7851['url'], m7851['retrieved_utc'], {'note':'pilot cache file read-only; 26 U.S.C. 7851(b)(1)'}),
]
END_EV={
 'EO:7933a':[('house_chapter-14',r'In 1945 the House Un-American Activities Committee was created.{0,200}?since 1938\.')],
 'EO:8131':[('house_chapter-14',r'In 1945 the House Un-American Activities Committee was created.{0,200}?since 1938\.')],
 'EO:9444':[('house_chapter-14',r'In 1945 the House Un-American Activities Committee was created.{0,200}?since 1938\.')],
 'EO:9345':[('house_chapter-04',r'They continued to function until they were abolished by the Legislative Reorganization Act of 1946\.')],
 'EO:9812':[('house_chapter-04',r'They continued to function until they were abolished by the Legislative Reorganization Act of 1946\.')],
 'EO:9448':[('house_chapter-22',r'Select Committee to Investigate the Federal Communications Commission \(1943-1945\)')],
 'EO:9455':[('house_chapter-22',r'Select Committee to Investigate the Federal Communications Commission \(1943-1945\)')],
 'EO:9764':[('senate_chapter-18',r'From its creation in 1941 until its expiration in 1948')],
 'EO:10132':[('senate_chapter-18',r'until the committee ended on September 1, 1951')],
 'EO:10279':[('senate_chapter-18',r'until the committee ended on September 1, 1951')],
 'EO:10304':[('senate_chapter-08',r'terminated by S\. Res\. 4, 95th Cong\., on February 11, 1977')],
 'EO:10703':[('senate_chapter-18',r'The final report of the committee was issued on March 31, 1960\..{0,140}')],
 'EO:10447':[('senate_chapter-13',r'Pursuant to S\. Res\. 245, 82d Cong\..{0,500}?records, 1952-66')],
}
out=[]
for p in P:
    iid=p['instrument_id']; n=iid.split(':')[1]
    pc=chk['per_proposal'][iid]
    rev_ev=[]
    if iid in sample:
        d=sample[iid]; num=n.replace('a','-A') if n=='7933a' else n
        rev_ev.append(order_text(d, '7933' if n=='7933a' else num))
    if iid=='EO:10703':
        t=fr_ev('1959-01-23', r'is hereby amended by striking out.{0,260}?Eighty-sixth Congress,”\.'); t['note']='EO 10801 (amender) text, reviewer re-fetch'; rev_ev.append(t)
    for (nn,pat) in END_EV.get(iid,[]): rev_ev.append(nara(nn,pat))
    has_clause = iid in clause_ev
    if has_clause: rev_ev.append(clause_ev[iid]())
    if iid in PRE46: rev_ev.append(pre46_td[iid]())
    if iid=='EO:9455': rev_ev.append(pre46_td['EO:9455b']())
    base=dict(instrument_id=iid, proposal_id=p['proposal_id'], reviewer='V9_TAXX_A_REV')
    checks={'quotes_exact':not pc['bad'],'sha_match':not pc['bad'],'text_complete':True,'refetched':iid in sample,
            'footprint_complete':True,'law_checked':True,'later_changes_checked':True,'rule_predicates_met':None}
    probs=[]; dissent=''
    rule=p['rule_id']
    if iid in PRE46:
        verdict='accept_with_correction'; rs,ra='no','no'
        checks['rule_predicates_met']=True
        probs.append('Reasoning correction: the producer says the only post-inspection term is the T.D. proviso that information be held confidential. That is wrong for this order. Its approved Treasury decision (pre-Aug 1946 form) has no confidentiality duty. It only permits relevant information to be submitted to the House, a permissive term spent with the committee (TC07). The residual is therefore absent on the text, not because "Part 458 is reserved" (eCFR shows only the range "Parts 421-499 [Reserved]"; no removal notice found).')
        probs.append('Committee-end evidence re-checked on reviewer re-fetch of the NARA guide; end date is a latest bound (TC13).')
    elif iid in ('EO:10316','EO:10447'):
        verdict='accept'; rs,ra='indeterminate','indeterminate'
        checks['rule_predicates_met']=True
        probs.append('Hold confirmed on the reviewer\'s re-fetched FR text: '+('Senate Armed Services, "continuous watchfulness", returns to 1950, no time limit; committee still exists.' if iid=='EO:10316' else 'Senate Judiciary for S.Res. 245 (82d) "as extended by" S.Res. 47 (83d); no own-text limit; end of the S.Res. 245 authority not shown (NARA: TWEA subcommittee records 1952-66).'))
        probs.append('Additional ground: the approved T.D. carries the continuing confidentiality proviso (see ruling), so any-effect would stay indeterminate even if the permission were shown ended.')
    else:
        verdict='reject_to_indeterminate'; rs,ra='no','indeterminate'
        checks['rule_predicates_met']=True
        checks['footprint_complete']=True
        checks['law_checked']=False
        probs.append('Substantive "no" accepted: the inspection permission ended ('+('own-text Congress/session/date limit' if rule=='RULE-TAX-CONGRESS-TERM' else 'named committee/resolution ended')+'), confirmed on '+('the reviewer re-fetch.' if iid in sample else 'the producer FR text (sha and quotes verified).'))
        probs.append('Any-effect not closed: the Treasury decision approved by the President with this order (and incorporated by it as the conditions of the permission) provides that "Any information thus obtained by the committee or subcommittee shall be held confidential", with only relevant portions reportable to the chamber. This is a continuing post-inspection duty attached to information obtained, not to the term of the permission (TC04 residual / TC08). The producer\'s grounds for ending it fail: (i) the text gives the duty no time limit; (ii) eCFR shows only "Parts 421-499 [Reserved]", and Part 458 was still being amended in 1961 (T.D. 6570) and was already out of the CFR by the Apr. 1, 1981 edition; no Federal Register removal document was found; (iii) the returns reached include 1939-Code returns, to which 26 U.S.C. 7851(a)(6)(A) applies the 1954/1986 subtitle F (incl. 6103/7213 successor rules) only to a limited extent, and 7851(b)(1) continues rights and liabilities under the 1939 Code; 301.6103(a)-1 carries pre-1977 order terms forward only for Federal agencies, not Congress. Committee records holding Treasury-furnished tax data survive at NARA, which states that income tax returns in Senate records are "closed by statute or Executive order of the President". Under the codebook inference protocol ("Residual terms with no proved surviving subjects yield indeterminate any-effect"), any-effect is indeterminate.')
        dissent='Limiting predicate: this ruling turns only on the incorporated T.D. confidentiality proviso. It would close to no/no if a source showed (a) the withdrawal of the approved regulations as applied to information already obtained, or (b) that 26 U.S.C. 6103 as rewritten in 1976 governs pre-1977 committee holdings of pre-1954 return information to the exclusion of the order-approved terms. Reasonable dissent: the duty addresses only the committee as recipient, and for ended committees (branch b) it has no present actor. The reviewer does not adopt that view because the information and its custodian (the chamber and NARA under chamber control) persist.'
        if iid=='EO:10304':
            probs.append('APP check: the reviewer re-fetched the APP page for EO 10304. It prints the EO 10316 text (Senate Armed Services, "continuous watchfulness") and an Armed Services title under the 10304 date. The FR (16 FR 11631, re-fetched, byte-identical) shows the Senate Committee on the District of Columbia, S.Res. 136 (82d). The producer was right to follow the FR. The end date Feb 11, 1977 (S.Res. 4, 95th) is a latest bound only.')
        if iid=='EO:10518':
            probs.append('Variant confirmed: "until and including January 3, 1955", equal to the end of the 83d Congress.')
        if iid in ('EO:10275','EO:10326'):
            probs.append('Variant confirmed: the limit is a single session of the 82d Congress ('+('first' if iid=='EO:10275' else 'second')+').')
        if iid=='EO:10703':
            probs.append('Amender EO 10801 confirmed on re-fetch: "during the Eighty-fifth Congress and as long as the Committee is authorized to act during the Eighty-sixth Congress", effective noon Jan 3, 1959. The authority was transferred Mar 31, 1960 (NARA 18.x); the latest bound is Jan 3, 1961.')
        if iid=='EO:10279':
            probs.append('TC09: EO 10279 operates inside EO 10132 and amends the T.D. 5793 regime, which carries the same proviso.')
    probs.append('Producer statement "Part 458 is [Reserved]" corrected: the 2026 eCFR and the 1981 CFR both show the range "Parts 421-499 [Reserved]"; this is not a removal notice.')
    if not iid in sample: probs.append('Order text not re-fetched by the reviewer (outside the stratified sample). The producer FR evidence was verified by script (sha256 and exact quotes).')
    rec=dict(base, verdict=verdict, reviewer_substantive_effect=rs, reviewer_any_operative_effect=ra, checks=checks,
             problems=probs, dissent_or_limiting_predicates=dissent or None,
             reviewer_evidence=rev_ev+COMMON)
    out.append(rec)
with open(R+'reviews.jsonl','w') as f:
    for r in out: f.write(json.dumps(r,ensure_ascii=False)+'\n')
# self-verify quotes
bad=0
for r in out:
    for e in r['reviewer_evidence']:
        t=open(B+e['local_file'],encoding='utf-8',errors='replace').read()
        if e['quote'] not in t or sha(B+e['local_file'])!=e['sha256']: bad+=1; print('BADQ',r['instrument_id'],e['local_file'])
import collections
print(collections.Counter(r['verdict'] for r in out), 'bad quotes',bad, 'records',len(out))
