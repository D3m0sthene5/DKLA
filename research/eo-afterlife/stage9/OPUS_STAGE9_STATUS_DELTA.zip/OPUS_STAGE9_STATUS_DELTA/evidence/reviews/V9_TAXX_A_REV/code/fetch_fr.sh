#!/bin/bash
# usage: fetch_fr.sh DATE ; saves original bytes to cache/fr/fr_DATE.pdf + meta.json
D=$1; OUT=cache/fr/fr_$D.pdf; URL="https://www.govinfo.gov/content/pkg/FR-$D/pdf/FR-$D.pdf"
T=$(date -u +%Y-%m-%dT%H:%M:%SZ)
INFO=$(curl -sSL --retry 3 --max-time 300 -o "$OUT" -w '%{http_code}|%{content_type}|%{url_effective}' "$URL")
S=$(sha256sum "$OUT"|cut -d' ' -f1); SZ=$(stat -c %s "$OUT")
IFS='|' read CODE CT FU <<< "$INFO"
cat > cache/fr/fr_$D.meta.json <<J
{"url":"$URL","final_url":"$FU","retrieved_utc":"$T","http_status":$CODE,"content_type":"$CT","sha256":"$S","size_bytes":$SZ,"method":"curl original bytes"}
J
echo "$D $CODE $SZ $S"
