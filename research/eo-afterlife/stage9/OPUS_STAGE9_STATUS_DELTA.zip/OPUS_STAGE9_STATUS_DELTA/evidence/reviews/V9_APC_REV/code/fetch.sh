#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
C=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_APC_REV/cache
id=$1; ext=$2; url=$3
ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
out=$(curl -sSL --retry 3 --max-time 1500 -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36" -o "$C/$id.$ext" -w '%{http_code}|%{content_type}|%{url_effective}' "$url")
code=${out%%|*}; rest=${out#*|}; ct=${rest%%|*}; fu=${rest#*|}
sha=$(sha256sum "$C/$id.$ext" | cut -d' ' -f1)
python3 -I -c "import json,sys; json.dump({'url':sys.argv[1],'final_url':sys.argv[2],'retrieved_utc':sys.argv[3],'http_status':int(sys.argv[4]),'content_type':sys.argv[5],'sha256':sys.argv[6],'method':'curl original bytes'},open(sys.argv[7],'w'),indent=1)" "$url" "$fu" "$ts" "$code" "$ct" "$sha" "$C/$id.meta.json"
echo "$id $code $ct $(stat -c %s $C/$id.$ext)"
