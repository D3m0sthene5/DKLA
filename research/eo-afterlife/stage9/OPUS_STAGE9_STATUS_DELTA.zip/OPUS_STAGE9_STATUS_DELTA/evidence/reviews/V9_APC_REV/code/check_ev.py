import json, hashlib, os, sys
S=sys.argv[1]
ev={}
for l in open(os.path.join(S,'evidence.jsonl')):
    d=json.loads(l); ev[d['evidence_id']]=d
res={}
for eid,d in ev.items():
    lf=d['local_file']
    p=lf if os.path.isabs(lf) else os.path.join(S,lf)
    if not os.path.exists(p):
        res[eid]=('MISSING',lf); continue
    b=open(p,'rb').read()
    sha=hashlib.sha256(b).hexdigest()
    shaok = sha==d['local_file_sha256']
    t=b.decode('utf-8','replace')
    q=d['quote']
    qok = q in t
    res[eid]=(shaok,qok)
    if not (shaok and qok):
        print('PROBLEM',eid,lf,shaok,qok,repr(q[:80]))
print(len(ev),'evidence records checked')
json.dump({k:list(v) for k,v in res.items()},open(sys.argv[2],'w'),indent=0)
