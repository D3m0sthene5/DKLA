import json, hashlib, os, sys
R='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_APC_REV'
SC='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/S9_APC/cache'
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
def ev(path, quote, visual=False):
    meta=path.rsplit('.',1)[0]+'.meta.json'
    m=json.load(open(meta))
    if not visual:
        t=open(path,encoding='utf-8',errors='replace').read()
        assert quote in t, (path, quote)
    return {"local_file":path,"sha256":sha(path),"url":m['url'],"retrieved_utc":m['retrieved_utc'],
            "quote":quote, **({"note":"reviewer visual transcription from page image (scan has no text layer); not a text-file substring"} if visual else {})}
C=R+'/cache'
T19=C+'/apc1919_sdoc65_435.txt'; T23=C+'/apc1923_hdoc68_49.txt'; T24=C+'/apc1924_sdoc68_203.txt'; SCAN=C+'/twea1920_scan.pdf'
STAT=SC+'/stat_40_459.txt'
statq="shall have the right to reject all bids and resell such\n                           property at public sale or otherwise as the President may direct."
E={}
E['2954_op']=ev(T19,"Now, therefore, IT hereby declare the said sale to be void and of no effect, and’1")
E['2954_scan']=ev(SCAN,"Now, therefore, I hereby declare the said sale to be void and of no effect, and I hereby authorize and direct the Alien Property Custodian to reject all bids received at the said sale, including the bid of the said Compania Mercantil de Filipinas. [compilation p. 66, No. 2954]",True)
E['stat']=ev(STAT,statq)
E['3016N_scan1']=ev(SCAN,"The Alien Property Custodian may, and he is hereby authorized and directed to transfer, dispose of, release, surrender, and quitclaim to Ludwig Vogelstein ... all the rights which the Alien Property Custodian and Aron Hirsch & Sohn, or either of them, have acquired or may acquire by reason of the deposit of the said shares [compilation p. 102]",True)
E['3016N_scan2']=ev(SCAN,"which authority has been delegated to me by Executive Order No. 3016 and signed by the President on the third day of December, 1918 ... Done in the District of Columbia this 18th day of April ... Frank L. Polk. [compilation pp. 102-103]",True)
E['3016N_23']=ev(T23,"Disposition: All stock pledged pending an accounting, and trustees’returned")
E['3016N_24']=ev(T24,"Disposition: All stock pledged pending an accounting, and trustees returned")
E['vog_claim24']=ev(T24,"16586 L. Vogelstein & Co. (Inc.); pending.")
E['polk19']=ev(T19,"ders which, while not technically such, are substantially Executive")
E['2858_date']=ev(T19,"              9 May, 1918.")
E['hammar24']=ev(T24,"7838 Hammar & Co.(Ltd.); pending.")
E['busch24']=ev(T24,"4384 Mrs. Lilly Busch; suits under sec. 9.")
E['busch19']=ev(T19,"Lilly Busch.    vs ooaivaacs Ownership...           8, 500,000.00 | Application to Attor- | Allowed.")
E['lynar24']=ev(T24,"17748   Count George zu Lynar; allowed Jan. 16,")
E['braesecke24']=ev(T24,"20942   Luise E. Braesecke; canceled.")
E['saleseo24']=ev(T24,"Other sales have been made by Executive order designating specific")
json.dump(E,open(R+'/code/_ev.json','w'),indent=1)
print('all quotes verified', len(E))
