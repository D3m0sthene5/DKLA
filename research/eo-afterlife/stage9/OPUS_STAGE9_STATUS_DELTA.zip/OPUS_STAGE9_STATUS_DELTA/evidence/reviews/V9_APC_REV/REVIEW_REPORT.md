# Review of shard S9_APC (reviewer V9_APC_REV)

**Actual UTC start:** 2026-10-16T17:02:33Z. **Actual UTC end:** 2026-10-16T17:10:54Z (both from `date -u`).

## Verdicts (10 proposals)

| Verdict | Count | Orders |
|---|---|---|
| accept | 6 | 2843, 2858, 2953, 3016C, 3150, 3456 |
| accept_with_correction | 4 | 2954, 3016N, 3639A, 4007 |
| reject_to_indeterminate | 0 | |
| reject_other | 0 | |

**Error rate:**
- Strict (any verdict other than plain accept, divided by total): 4/10 = 0.40.
- Status-level (any reject): 0/10 = 0.00.

All of my substantive and any-effect statuses match the producer's:
- no / no for EO 2954 and EO 3016N.
- indeterminate / indeterminate for the other 8.

## Checks

**Evidence fidelity.**
- All 44 producer evidence quotes are exact substrings of the cited files.
- All 44 file sha256 values match the evidence records.
- Checked with `code/check_ev.py` under `python3 -I`; results are in `ev_check.json`.

**Re-fetches.** Original bytes and meta files are in `cache/`.
- **S. Doc. 65-435 (1919 APC report)** and **H. Doc. 68-49 (1923 APC report)** from govinfo. Both are byte-identical to the producer's copies.
- **The archive.org Google scan PDF of the 1920 GPO TWEA compilation.** It has no text layer, so I read the page images for p. 66 (EO 2954) and pp. 101-103 (EO 3016N and the neighbouring Polk order). My quotes from it are marked as visual transcriptions.
- **S. Doc. 68-203 (1924 APC report).** New; the producer did not download it.

**Law.** I re-read TWEA sec. 12 as amended (40 Stat. 460) myself. The proviso reads "reject all bids and resell such property at public sale or otherwise as the President may direct".

## Key findings

1. **EO 2954 is a sound no/no.**
   - The whole order consists of: a void declaration of the May 1918 Manila sale, a direction to reject the bids at that sale, and recited reasons.
   - It contains no resale direction, no reserved interest and no continuing condition. The War Trade Board licence liquidation appears only among the reasons.
   - The 1920 compilation has no later Froehlich & Kuttner order.
   - Correction: the producer did not address the resale half of the statutory proviso.
   - Unlogged counterevidence: Franz Kuttner's claim was disallowed in 1921. It is immaterial to this order's own commands.
   - Limiting predicate: a rejection order that also directs a resale (e.g. the Polk order of 8 Apr 1919 on the Schaap bid) falls outside rule R2.

2. **EO 3016N is a sound no/no.**
   - The text was confirmed from the page images.
   - The disposition line ("trustees returned stock upon payment to Alien Property Custodian by American debtor") appears in both the 1923 and the 1924 reports.
   - The producer did not log pending claim 16586 (L. Vogelstein & Co. (Inc.)) or the Vogelstein/Hothorn sec. 9 claims. These are claims for return and do not keep the release power alive.
   - Grade inconsistency: the text came from an archived scan, but the proposal labels it plain official_publication.

3. **Identity conflicts.** These are recorded in `conflicts.jsonl`; the ledger was not corrected.
   - EO 2858 was signed 9 May 1918, not 7 May (4 copies agree).
   - 3016C and 3016N are Polk delegated orders under EO 3016 para. V, which the 1919 APC report itself calls "substantially Executive orders". Whether they belong in the ledger is a scope question for root.

4. **Spot-checked holds.**
   - **EO 4007.** The producer's named settling source, the 1924 APC report, was fetched and searched. It does not show the Standard Oil (N.J.) sale, and the owners' claims are not property-specific. The hold is justified, and the queue should mark this source as checked.
   - **EO 2953.** Lilly Busch's ownership claim was allowed in 1918-19, but claim 4384 ("suits under sec. 9") was still open in 1923-24. Return of the Riverside Drive / W. 181st St. parcel therefore cannot be inferred. The hold is justified.

5. **Missed cheap lead.** The 1924 report shows the zu Lynar claims (17748-17750) allowed on 16 Jan 1924. This is relevant to EO 3639A, but it does not close it, because the 12-page text is still needed.

## Systematic problems

- **Counterevidence logging is selective.** Pending or disallowed claims of the same parties were not listed for 2954 or 3016N.
- **Statutory provisos were paraphrased only in part** (2954).
- **A settling source the producer itself named was left unfetched under the pivot rule** (1924 report). Fetching it took about 3 minutes and checked 4007 and 3639A.
- **Grade labels in the proposals overstate the archive.org copies.**

## Not done

- I did not re-read the page images for 3016C or 3150.
- I did not independently re-test the 3016C prospective-clause analysis beyond the producer's quotes.
- Retrieval attempts I made for 3456, 3639A and 4007 texts:
  - HathiTrust `ls`: 403.
  - archive.org scrape/advancedsearch: 0 hits.
  - WebSearch (Busch parcel): no lead.

The producer had already tried the rest of the ladder (Wayback Machine, Google Books, mocat).
