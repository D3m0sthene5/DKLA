"""Locator search (not evidence). usage: locs.py "<q>" d1 d2 regex [before] [after]"""
import sys,json,re,subprocess,time,urllib.parse
q,d1,d2,rx=sys.argv[1:5]; B=int(sys.argv[5]) if len(sys.argv)>5 else 200; A=int(sys.argv[6]) if len(sys.argv)>6 else 800
def get(u,js=True):
    for a in range(4):
        o=subprocess.run(["curl","-sSL","-m","120",u],capture_output=True).stdout
        if not js: return o
        try: return json.loads(o)
        except Exception: time.sleep(8*(a+1))
    return {}
u="https://www.loc.gov/collections/chronicling-america/?q="+urllib.parse.quote_plus(q)+f"&dates={d1}/{d2}&fo=json&c=15"+("&fa=location_state:district+of+columbia" if len(sys.argv)>7 else "")
d=get(u); res=d.get('results',[])
print('results',len(res))
for r in res:
    rid=r.get('id'); 
    ft=None
    for k in ('fulltext_file',):
        pass
    j=get(rid.replace('http://','https://')+('&' if '?' in rid else '?')+'fo=json')
    ft=j.get('resource',{}).get('fulltext_file')
    title=(r.get('partof_title') or r.get('title') or '')
    if not ft: print('NOFT',rid); continue
    t=get(ft,js=False).decode('utf-8','replace')
    try: txt=' '.join(v.get('full_text','') for v in json.loads(t).values())
    except Exception: txt=re.sub(r'<[^>]+>',' ',t)
    txt=re.sub(r'\s+',' ',txt)
    m=re.search(rx,txt,re.I)
    print('###',r.get('date'),str(title)[:60],rid,'|',ft, 'MATCH' if m else 'nomatch')
    if m: print(txt[max(0,m.start()-B):m.end()+A])
