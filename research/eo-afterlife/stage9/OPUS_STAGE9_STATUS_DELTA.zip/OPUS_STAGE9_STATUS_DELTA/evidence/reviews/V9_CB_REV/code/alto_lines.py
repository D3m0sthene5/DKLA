import sys,re,xml.etree.ElementTree as ET
# usage: alto_lines.py file.xml regex before after  -> prints lines w/ coords, and bbox
f,pat=sys.argv[1],sys.argv[2]; nb=int(sys.argv[3]); na=int(sys.argv[4])
r=ET.parse(f).getroot(); ns={'a':r.tag.split('}')[0].strip('{')}
page=r.find('.//a:Page',ns)
L=[]
for b in r.findall('.//a:TextBlock',ns):
    for tl in b.findall('a:TextLine',ns):
        L.append((b.get('ID'),int(float(tl.get('HPOS'))),int(float(tl.get('VPOS'))),int(float(tl.get('WIDTH'))),int(float(tl.get('HEIGHT'))),' '.join(s.get('CONTENT') for s in tl.findall('a:String',ns))))
full=[l[5] for l in L]
# join with index to allow multi-line regex
joined=''; starts=[]
for i,t in enumerate(full):
    starts.append(len(joined)); joined+=t+'\n'
import bisect
for m in re.finditer(pat,joined,re.I|re.S):
    i=bisect.bisect_right(starts,m.start())-1
    lo,hi=max(0,i-nb),min(len(L),i+na+1)
    xs=[L[k][1] for k in range(lo,hi)]; ys=[L[k][2] for k in range(lo,hi)]
    x2=[L[k][1]+L[k][3] for k in range(lo,hi)]; y2=[L[k][2]+L[k][4] for k in range(lo,hi)]
    print('PAGE',page.get('WIDTH'),page.get('HEIGHT'),'BBOX',min(xs),min(ys),max(x2)-min(xs),max(y2)-min(ys))
    for k in range(lo,hi): print(f'{k:5d} {L[k][0]:>8} {L[k][1]:6d} {L[k][2]:6d} | {L[k][5]}')
    print('-----')
