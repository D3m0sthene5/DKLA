import sys,json,hashlib
from bs4 import BeautifulSoup
for h in sys.argv[1:]:
    s=BeautifulSoup(open(h,'rb').read(),'html.parser')
    title=s.find('h1').get_text(' ',strip=True) if s.find('h1') else ''
    date=s.select_one('.field-docs-start-date-time')
    body=s.select_one('.field-docs-content')
    t=title+'\n'+(date.get_text(' ',strip=True) if date else '')+'\n'+(body.get_text('\n',strip=True) if body else '')
    tp=h[:-5]+'.txt'; open(tp,'w').write(t)
    mp=h[:-5]+'.meta.json'; m=json.load(open(mp)); m['text_file']=tp.split('/')[-1]; m['text_sha256']=hashlib.sha256(t.encode()).hexdigest(); m['extraction']='python3 -I bs4: h1 + .field-docs-start-date-time + .field-docs-content get_text("\\n")'; json.dump(m,open(mp,'w'),indent=1)
