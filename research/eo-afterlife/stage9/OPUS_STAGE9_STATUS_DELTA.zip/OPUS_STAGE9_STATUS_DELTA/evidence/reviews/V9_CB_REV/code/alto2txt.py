import sys,json,hashlib,xml.etree.ElementTree as ET
for f in sys.argv[1:]:
    r=ET.parse(f).getroot(); ns={'a':r.tag.split('}')[0].strip('{')}
    out=[]
    for b in r.findall('.//a:TextBlock',ns):
        for tl in b.findall('a:TextLine',ns):
            out.append(' '.join(s.get('CONTENT') for s in tl.findall('a:String',ns)))
        out.append('')
    t='\n'.join(out); tp=f[:-4]+'.txt'; open(tp,'w').write(t)
    mp=f[:-4]+'.meta.json'; m=json.load(open(mp)); m['text_file']=tp.split('/')[-1]; m['text_sha256']=hashlib.sha256(t.encode()).hexdigest(); m['extraction']='python3 -I ElementTree: ALTO TextLine String CONTENT joined by spaces, one line per TextLine'; json.dump(m,open(mp,'w'),indent=1)
