import json,hashlib,os,sys
base=sys.argv[1]
n=0;bad=[]
for l in open(os.path.join(base,'evidence.jsonl')):
    e=json.loads(l); n+=1
    probs=[]
    p=os.path.join(base,e['local_file'])
    if not os.path.exists(p): probs.append('raw missing')
    elif hashlib.sha256(open(p,'rb').read()).hexdigest()!=e['local_file_sha256']: probs.append('raw sha')
    tf=e.get('text_file') or e['local_file']
    tp=os.path.join(base,tf)
    if not os.path.exists(tp): probs.append('txt missing '+tf)
    else:
        b=open(tp,'rb').read()
        if e.get('text_file_sha256') and hashlib.sha256(b).hexdigest()!=e['text_file_sha256']: probs.append('txt sha')
        if e['quote'] not in b.decode('utf-8','replace'): probs.append('quote not in txt')
    if probs: bad.append((e['evidence_id'],probs))
print('total',n,'bad',len(bad))
for x in bad: print(x)
