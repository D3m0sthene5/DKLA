import sys,re,xml.etree.ElementTree as ET
# usage: alto_find.py file.xml regex [context_blocks]
f,pat=sys.argv[1],sys.argv[2]
ctx=int(sys.argv[3]) if len(sys.argv)>3 else 0
t=ET.parse(f); r=t.getroot()
ns={'a':r.tag.split('}')[0].strip('{')}
mu=r.find('.//a:MeasurementUnit',ns)
page=r.find('.//a:Page',ns)
print('unit',mu.text if mu is not None else None,'page',page.get('WIDTH'),page.get('HEIGHT'))
blocks=r.findall('.//a:TextBlock',ns)
def btext(b):
    lines=[]
    for tl in b.findall('a:TextLine',ns):
        lines.append(' '.join(s.get('CONTENT') for s in tl.findall('a:String',ns)))
    return '\n'.join(lines)
for i,b in enumerate(blocks):
    tx=btext(b)
    if re.search(pat,tx,re.I|re.S):
        for j in range(max(0,i-ctx),min(len(blocks),i+ctx+1)):
            bb=blocks[j]
            print('=== block',j,bb.get('ID'),'HPOS',bb.get('HPOS'),'VPOS',bb.get('VPOS'),'W',bb.get('WIDTH'),'H',bb.get('HEIGHT'))
            print(btext(bb))
