import sys,json,hashlib,re
for f in sys.argv[1:]:
    d=json.load(open(f)); t=re.sub(r'\s+',' ',' '.join(v.get('full_text','') for v in d.values()))
    tp=f[:-5]+'.txt'; open(tp,'w').write(t)
    mp=f[:-5]+'.meta.json'; m=json.load(open(mp)); m['text_file']=tp.split('/')[-1]; m['text_sha256']=hashlib.sha256(t.encode()).hexdigest(); m['extraction']='python3 -I: word-coordinates JSON full_text values joined, whitespace collapsed'; json.dump(m,open(mp,'w'),indent=1)
