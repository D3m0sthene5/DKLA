"""Locator grep on LOC resource pages. usage: pg.py regex before after rid..."""
import sys,json,re,subprocess,time
rx,B,A=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
def get(u,js=True):
    for a in range(4):
        o=subprocess.run(["curl","-sSL","-m","120",u],capture_output=True).stdout
        if not js: return o
        try: return json.loads(o)
        except Exception: time.sleep(8*(a+1))
    return {}
for rid in sys.argv[4:]:
    rid=rid.replace('http://','https://')
    j=get(rid+('&' if '?' in rid else '?')+'fo=json')
    ft=j.get('resource',{}).get('fulltext_file')
    if not ft: print('NOFT',rid); continue
    t=get(ft,js=False).decode('utf-8','replace')
    try: txt=' '.join(v.get('full_text','') for v in json.loads(t).values())
    except Exception: txt=re.sub(r'<[^>]+>',' ',t)
    txt=re.sub(r'\s+',' ',txt)
    ms=list(re.finditer(rx,txt,re.I))
    print('###',rid,'|',ft,len(ms))
    for m in ms[:2]: print(txt[max(0,m.start()-B):m.end()+A]); print('..')
