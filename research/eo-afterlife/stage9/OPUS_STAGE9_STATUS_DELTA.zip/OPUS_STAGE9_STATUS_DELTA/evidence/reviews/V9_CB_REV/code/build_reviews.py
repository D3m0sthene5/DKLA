import json,hashlib,os
B=os.path.dirname(os.path.abspath(__file__))+'/../'
C=B+'cache/'
PROD=B+'../../shards/S9_CLOSE_BOARD/'
def ev(src, quote, note=None, prod=False):
    base = PROD+'cache/' if prod else C
    if prod:
        tf=base+src; raw=tf
        sha=hashlib.sha256(open(raw,'rb').read()).hexdigest()
        url='(producer cache, read-only reuse) '+src; ts=None
        mp=base+src.rsplit('.',1)[0]+'.meta.json'
        if os.path.exists(mp):
            m=json.load(open(mp)); url=m.get('url'); ts=m.get('retrieved_utc')
        t=open(tf,encoding='utf-8',errors='replace').read()
    else:
        m=json.load(open(C+src+'.meta.json'))
        rawname=[f for f in os.listdir(C) if f.startswith(src+'.') and not f.endswith(('.meta.json','.txt'))][0]
        sha=m['sha256']; assert sha==hashlib.sha256(open(C+rawname,'rb').read()).hexdigest()
        url=m['url']; ts=m['retrieved_utc']
        tf=C+m['text_file'] if 'text_file' in m else None
        t=open(tf,encoding='utf-8').read() if tf else ''
    if quote:
        assert quote in t, (src, quote[:60])
    d={'local_file':('reviews/V9_CB_REV/cache/' if not prod else 'shards/S9_CLOSE_BOARD/cache/')+(src if prod else rawname),'sha256':sha,'url':url,'retrieved_utc':ts,'quote':quote}
    if not prod and tf: d['text_file']='reviews/V9_CB_REV/cache/'+os.path.basename(tf); d['text_sha256']=m.get('text_sha256')
    if note: d['note']=note
    return d
ALLCHK=lambda tc=True,fc=True,rp=True: {"quotes_exact":True,"sha_match":True,"text_complete":tc,"refetched":True,"footprint_complete":fc,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":rp}
R=[]
def add(iid,verdict,s,a,problems,dissent,evs,chk):
    R.append({"instrument_id":iid,"proposal_id":"opus:s9:status:"+iid,"reviewer":"V9_CB_REV","verdict":verdict,"reviewer_substantive_effect":s,"reviewer_any_operative_effect":a,"checks":chk,"problems":problems,"dissent_or_limiting_predicates":dissent,"reviewer_evidence":evs})
CLOSE_LIM="Spent dated closing (TC07): every clause tied to a past date; no standing pay/leave rule, future-holiday rule or amendment of another order in the text; pay for the excused day is a historical consequence (TC04)."
add("EO:5","accept","no","no",[], CLOSE_LIM+" Identity of APP 'Executive Order' Apr. 13, 1866 (Seward, Dept. of State) with Lord no. 5 rests on matching date, signer and subject (Lord marks no. 5 as signed by Seward).",
 [ev('rv_app_executive-order-398','The undersigned is therefore directed by the President to announce that in commemoration of that event the public offices will be closed to-morrow, the 14th instant.',"Re-fetched APP bytes identical to producer copy (same sha256).")],ALLCHK())
add("EO:254","accept","no","no",[],
 CLOSE_LIM+" Completeness shown: the page images of two printings (Evening Star, Washington, p1; Minnesota paper sn83045366 p2) show the same one-sentence order in opening and closing quotation marks, introduced as 'the following executive order'/'the following order'. The two printings are probably from the same White House release, so they are consistent but not fully independent. The only differences are in the senator's style ('late senator of the United States from the state of Ohio' vs 'late senator from the state of Ohio') and in the day wording; neither affects scope.",
 [ev('loc_star1904_alto','from the state of Ohio, It is hereby ordered'),ev('loc_mn1904_alto','day, the 19th inst."'),
  ev('img_star1904_eo254','',"IIIF page-image crop, read visually: '...it is hereby ordered that all federal offices in Ohio be closed during the hours of the funeral tomorrow, the 19th instant.'"),
  ev('img_mn1904_eo254','',"IIIF page-image crop, read visually: same sentence, ending 'to-morrow, Friday, the 19th inst.'")],ALLCHK())
add("EO:2171","accept","no","no",[],
 CLOSE_LIM+" Completeness shown: page image (Norwich Bulletin sn82014086 p1) shows the order in full from the preamble ('As an evidence of the profound affection...') to '(Signed) WOODROW WILSON'. A Texas printing (sn88084272) has identical operative text. The merchant-ship clause is a non-binding request for the same day.",
 [ev('loc_ct1915_alto','"WOODROW WILSON."'),ev('loc_tx1915_alto','tional flag at half mast."'),
  ev('img_ct1915_eo2171','',"IIIF page-image crop, read visually: full order text, ending with the signature.")],ALLCHK())
add("EO:3885A","accept","indeterminate","indeterminate",[],
 "Hold confirmed. My Evening Star Aug. 4, 1923 search found the 3885-B closing text, and a separate same-day 'executive order' on flags, calls and entertainments, which matches Lord 3885-C (mourning). It found no 'approval' document. New lead: the Washington Times says 'By order of President Coolidge, the Secretary of State today issued an order', so 3885-A is probably the President's approval of the 3885-B closing. Without text it cannot be closed (TC15).",
 [ev('loc_star1923-08-04_p1_wc','At the same time an execu tive order was issued ordering flags to remain at half-staff until the close of Monday.')],ALLCHK(tc=False,fc=False,rp=None))
add("EO:3885B","accept","no","no",["Minor: the producer cites only the Washington Times printing, but a second contemporaneous printing exists (Evening Star Aug. 4, 1923 p1, 'The order follows:'), and its wording matches."],
 CLOSE_LIM+" Completeness shown three ways: (1) the Washington Times front-page banner (page image checked) prints the whole order, signed CHARLES E. HUGHES. (2) The Evening Star prints the same text in quotation marks. (3) 3885-D (Aug. 6), as printed, recites 3885-B's whole operative content and extends it 'on the said days' only.",
 [ev('loc_wtimes1923_alto','CHARLES E. HUGHES.”'),ev('loc_star1923-08-04_p1_wc','The order follows: ••By order of the President, all executive departments will be closed on Tuesday, August 7, at and after 1 o’clock p.m., and on Wednesday. Thursday and Fri day, August 8, 9 and 10.”'),
  ev('loc_star1923d_alto','and 10, 192.”.. shall apply to all execu'),ev('img_wtimes1923_eo3885b','',"IIIF page-image crop, read visually: banner text matches the OCR (right edge cropped).")],ALLCHK())
add("EO:4354","accept","no","no",[],
 CLOSE_LIM+" Completeness shown: two DC newspapers (Evening Star p1, page image checked; Washington Times p3) print the identical order, beginning 'As an experiment, not as a precedent' and ending 'excused from duty on that day.' The 'in lieu of' clause replaces only the 1925 half-day orders. The appended note (wording known only from a summary) says no Jan. 2 [1926] closing order will issue. That is a statement about one date, not a standing rule.",
 [ev('loc_star1925_alto','from duty on that day.”'),ev('loc_wtimes1925_alto',"Year's Day will be Issued."),ev('img_star1925_eo4354','',"IIIF page-image crop, read visually: complete quoted order.")],ALLCHK())
add("EO:4782","accept","no","no",["Only one printing (Washington Times Dec. 16, 1927 p1). My searches of DC papers for Dec. 16-18, 1927 found no second printing. The Evening Star of Dec. 18 printed only the parallel D.C. Commissioners' order. The 1928 CSR p.78 printing cited by Lord was not reachable (no archive.org copy found; HathiTrust and Google Books are behind CAPTCHA per NETWORK_NOTES)."],
 CLOSE_LIM+" Limiting predicate: completeness is inferred, not proved. The reprint is introduced 'His order follows:' and runs in quotation marks from 'It is hereby ordered' to 'excused from duty on that date.' (page image checked). Its wording is identical to the closing sentence of EO 5008 (Star, 'in full') and EO 5238 (APP). Those orders' only additional sentence is 'This order is not to be deemed as establishing a precedent', which could only reinforce 'no'. Lord's entry describes only the closing and excusal, and Lord records amendments of other orders when an order makes them (see 3885-D, 5353, 4644). So a hidden standing clause is very unlikely, and 'no' holds on the visible dated text.",
 [ev('loc_wtimes1927_alto','mas season. His order follows:'),ev('loc_wtimes1927_alto','excused from duty on that date.”'),ev('loc_star1927_p1_wc','',"Evening Star 1927-12-16 p1 checked: no reprint (locator only)."),
  ev('img_wtimes1927_eo4782','',"IIIF page-image crop, read visually: quoted order complete between quotation marks."),
  ev('lord_v1_djvu.txt','Dec.  24,  1927.  1928  CSR  78.',None,prod=True)],ALLCHK())
add("EO:5008","accept","no","no",[],
 CLOSE_LIM+" Completeness shown: page image confirms 'The order, in full, follows:' and both quoted paragraphs, including 'This order is not to be deemed as establishing a precedent.' The text is identical in form to APP EO 5238.",
 [ev('loc_star1928_alto','The order, in full, follows:'),ev('loc_star1928_alto','tablishing a precedent.”'),ev('img_star1928_eo5008','',"IIIF page-image crop, read visually: full order.")],ALLCHK())
add("EO:5238","accept","no","no",[],CLOSE_LIM,[ev('rv_app_eo5238','This order is not to be deemed as establishing a precedent.')],ALLCHK())
add("EO:5353","accept","no","no",[],
 CLOSE_LIM+" TC09 mapping confirmed. The deferral clause ('In view of this order ... will be deferred to the second Saturday in June') is tied to the May 31, 1930 closing, and the order 'is not to be deemed as establishing a precedent'. Its footprint in host EO 4644 is the 1930 season start only (Sat. June 7, 1930). Even on a permanent-amendment reading, the Act of Mar. 3, 1931 (46 Stat. 1482) made four hours 'a day's work on Saturdays throughout the year' for covered employees, which leaves any June start date with no work. EO 4644's own text was not obtained, which does not affect the result.",
 [ev('rv_app_eo5353','In view of this order the application of the provisions of Executive Order No. 4644, of May 9, 1927, relating to hours of duty on Saturdays in June, July, August, and September, will be deferred to the second Saturday in June.'),
  ev('stat_46_1482.txt','luncheon, shall constitute a day’s work on Saturdays throughout the',None,prod=True)],ALLCHK())
add("EO:5763","accept","no","no",[],CLOSE_LIM,[ev('rv_app_eo5763','be closed on Saturday, December 26, 1931,')],ALLCHK())
add("EO:6920","accept","no","no",[],CLOSE_LIM,[ev('rv_app_eo6920','are hereby excused from duty at 1 P.M. on Monday, December 24, 1934, and at 1 P.M. on Monday, December 31, 1934.')],ALLCHK())
add("EO:7249","accept","no","no",[],CLOSE_LIM+" The shift clause is limited to 'the dates specified'.",[ev('rv_app_eo7249','be excused from duty after four hours of work on the dates specified')],ALLCHK())
add("EO:9172","accept","no","no",[],
 "Revoked in full by EO 9883: verified in the official FR printing (12 FR 5481, Aug. 13, 1947), which has no savings clause. NMB reports say the Panel operated to Aug. 11, 1947. A revival would need an explicit reinstatement (TC11), and none is listed by NARA. Panel-board awards incorporated into agreements are historical consequences (TC04).",
 [ev('rv_app_eo9172','There is hereby created, for the duration of the war and six months thereafter, a National Railway Labor Panel of nine members'),
  ev('rv_fr_1947-08-13','utive Order No. 9172 be, and it is hereby,'),ev('rv_app_eo9883','it is ordered that the said Executive Order No. 9172 be, and it is hereby, revoked.')],ALLCHK(rp=None))
SAVE=("EO 9801 savings clause (official FR text, 11 FR 13435) read by reviewer. It keeps the terminated stabilization orders 'in force for the purpose of sustaining any proper suit, action, or prosecution' only for offenses, rights or liabilities incurred before Nov. 9, 1946. Reviewer finds this is not a current effect (TC04/TC08). (a) The clause saves pre-1946 liabilities through a successor instrument. It does not apply the board order's terms to any present actor or object (TC05). (b) Any such suit is now time-barred: civil penalties 5 years (28 U.S.C. 2462), offenses 5 years (18 U.S.C. 3282), actions against the U.S. 6 years (28 U.S.C. 2401(a)). No proceeding citing the order exists (CourtListener: 0). Dissent noted for the record: under the codebook line 'residual terms with no proved surviving subjects yield indeterminate', a stricter reviewer could hold any-effect indeterminate. I reject that, because the limitation statutes close the saved scope by rule, not by inference from silence.")
add("EO:9379","accept_with_correction","no","no",
 ["Completion evidence should be stated more strongly. The producer calls the Nov. 4, 1943 story 'OCR-damaged'. The page image is clearly legible: Vinson approved an additional 5-cent increase 'recommended by a special emergency board appointed by President Roosevelt after the workers struck last July' (matching EO 9379's preamble and the NMB FY1943 report on the 13-cent to 3-cent reduction).",
  "The 'no' does not depend on that story. Clause 1 confines the board to wage adjustments 'within the limitations of the Act of October 2, 1942 and the Executive Orders and Directives issued thereunder'. Clause 3's effectiveness mechanism runs through the Economic Stabilization Director. EO 9801 terminated all such wage controls 'including any Executive order ... issued thereunder', and OES functions had already been transferred (EO 9762, July 1946). The Panel the members came from was revoked in 1947. So no power under the order can be exercised now (TC05), even if the 1943 report were treated as unproved (TC10: the deadline is not relied on).",
  "Correction to the rule text: EO 9379 rests on the First War Powers Act, not the Stabilization Act. EO 9801 reaches its stabilization controls (the limitation and the ESD effectiveness clause), not the creation of the board as such. The rule predicate 'Mandate defined by the Stabilization Act' should read 'mandate confined within Stabilization Act limits'.",
  "Supporting: the NMB FY1945 report shows a new Panel emergency board for Pacific Electric passenger trainmen (Case A-1603), appointed Dec. 6, 1944, which supports the conclusion that the special board's role had ended."],
 SAVE,
 [ev('img_1943_eo9379','',"IIIF page-image crop of sn95047217 1943-11-04 p4, read visually: 'The added increase was recommended by a special emergency board appointed by President Roosevelt after the workers struck last July when Vinson disapproved a recommendation for a 13-cents-an-hour increase.'"),
  ev('rv_app_eo9379','within the limitations of the Act of October 2, 1942 and the Executive Orders and Directives issued thereunder'),
  ev('rv_fr_1946-11-13','All controls heretofore in effect stabi'),ev('rv_fr_1946-11-13','pose of sustaining any proper suit, ac'),
  ev('nmb_ar_1945.txt','An emergency board was appointed December 6, 1944, composed of James H.',None,prod=True),
  ev('lii_28_2462','shall not be entertained unless commenced within five years from the date when the claim first accrued'),
  ev('lii_18_3282','unless the indictment is found or the information is instituted within five years next after such offense shall have been committed'),
  ev('lii_28_2401','every civil action commenced against the United States shall be barred unless the complaint is filed within six years after the right of action first accrues')],ALLCHK())
add("EO:9388","accept","no","no",[],
 "Completion is shown by EO 9413's official recital: the ESD order of Nov. 4, 1943 made the board's recommendations effective Nov. 19, 1943. The one-time effectiveness clause was used. The stabilization frame was terminated by EO 9801 and the Panel by EO 9883. "+SAVE,
 [ev('rv_app_eo9413','the Economic Stabilization Director on November 4, 1943, entered an order authorizing the wage adjustments recommended by said Special Emergency Board to become effective on November 19, 1943'),ev('rv_fr_1946-11-13','pose of sustaining any proper suit, ac')],ALLCHK())
add("EO:9413","accept","no","no",[],
 "The dispute was settled Jan. 17, 1944 by an ESD-approved agreement (NMB FY1944 report). EO 9413 expressly invokes the Stabilization Act, so EO 9801's termination of 'any Executive order ... issued thereunder' reaches it directly. The effectiveness clause was never triggered. "+SAVE,
 [ev('rv_app_eo9413','particularly by the First War Powers Act, 1941, the Railway Labor Act and the Stabilization Act of October 2, 1942'),ev('nmb_ar_1944.txt','1943, and for the nonoperating groups on January 17, 1944. The',None,prod=True)],ALLCHK())
add("EO:9958","accept","no","no",[],
 "Verified. EO 9965 (official FR 13 FR 3009, June 5, 1948) supersedes EO 9958 and names the same three members. PEB No. 62 reported July 9, 1948 as the board 'designated ... under Executive Order 9958 ... and redesignated by Executive Order 9965'. The sec. 10 status quo ran to 30 days after the report. EO 12553 (Feb. 25, 1986) revoked EO 9965. EO 9958's status-quo clause only restates RLA sec. 10.",
 [ev('rv_fr_1948-06-05','No. 9958, dated May 15, 1948.'),ev('rv_app_eo9965','This order supersedes Executive Order No. 9958, dated May 15, 1948.'),
  ev('nmb_peb062.txt','Executive Order 9958 of May 15,1948, and redesignated by Executive',None,prod=True),
  ev('rv_app_eo12553','9965 Creating an emergency board to investigate airline labor disputes.'),
  ev('gi_usc2024_45_160.txt','for thirty days after such board has made its report to the President, no change, except by agreement, shall be made by the parties to the controversy in the conditions out of which the dispute arose.',None,prod=True)],ALLCHK())
ids=[json.loads(l)['instrument_id'] for l in open(PROD+'status_proposals.jsonl')]
assert sorted(ids)==sorted(r['instrument_id'] for r in R), (sorted(ids),)
with open(B+'reviews.jsonl','w') as f:
    for r in R: f.write(json.dumps(r,ensure_ascii=False)+'\n')
from collections import Counter
print(Counter(r['verdict'] for r in R), len(R))
