#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
D=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_CB_REV/cache
id=$1; ext=$2; url=$3
out=$D/$id.$ext
T=$(date -u +%Y-%m-%dT%H:%M:%SZ)
res=$(curl -sSL --max-time 90 --retry 2 --retry-delay 4 -o "$out" -w '%{http_code}|%{content_type}|%{url_effective}' "$url")
code=${res%%|*}; rest=${res#*|}; ct=${rest%%|*}; fu=${rest#*|}
sha=$(sha256sum "$out" | cut -d' ' -f1)
python3 -I -c "import json,sys; json.dump({'url':sys.argv[1],'final_url':sys.argv[2],'retrieved_utc':sys.argv[3],'http_status':int(sys.argv[4] or 0),'content_type':sys.argv[5],'sha256':sys.argv[6],'method':'curl original bytes','bytes':int(sys.argv[7])},open(sys.argv[8],'w'),indent=1)" "$url" "$fu" "$T" "$code" "$ct" "$sha" "$(stat -c %s "$out")" "$D/$id.meta.json"
echo "$id $code $ct $(stat -c %s "$out") $sha"
