# V9_CB_REV review of shard S9_CLOSE_BOARD

- Reviewer: V9_CB_REV (independent; did not produce this shard)
- Actual UTC start: 2026-10-16T17:46:18Z. Actual UTC end: 2026-10-16T19:55:48Z (both from `date -u`). The work was interrupted by a usage-limit pause and then resumed.
- Inputs: REVIEWER_PROTOCOL.md, PRODUCER_PROTOCOL.md (incl. STANDING RULE), CODEBOOK_2.0.0_UNCHANGED.json, COORDINATOR_RULINGS.md, and the shard's proposals, evidence, rules, queue and conflicts.

## Verdicts (18 proposals)

| Verdict | Count | IDs |
|---|---|---|
| accept | 17 | EO 5, 254, 2171, 3885-A (indeterminate/indeterminate), 3885-B, 4354, 4782, 5008, 5238, 5353, 5763, 6920, 7249, 9172, 9388, 9413, 9958 |
| accept_with_correction | 1 | EO 9379 |
| reject_to_indeterminate | 0 | |
| reject_other | 0 | |

Error rate (non-accept / total): 1/18 = 5.6%. The one non-accept is a correction to reasoning, evidence and rule wording. No status changed, so there are 0 status errors.

## Gate 1: evidence fidelity
I checked all 91 evidence records with a script (`code/check_ev2.py`). Every raw-file sha256 matches. Every text-file sha256 matches where one is recorded. Every quote is an exact substring of its text file. No mismatches.

## Gate 2: re-fetch and text completeness
- **APP texts.** I re-fetched from APP the texts for EO 5, 5238, 5353, 5763, 6920, 7249, 9172, 9379, 9388, 9413, 9801, 9883, 9958, 9965 and 12553. Each re-fetched operative body is contained word for word in the producer's text. The EO 5 page bytes are identical to the producer's copy.
- **Federal Register.** I re-fetched three official FR issues:
  - 1946-11-13, EO 9801 at 11 FR 13435
  - 1947-08-13, EO 9883 at 12 FR 5481
  - 1948-06-05, EO 9965 at 13 FR 3009

  I kept no PDF over 20 MB; the largest is 12 MB.
- **Newspaper-only orders (focus a).** I re-fetched the LOC ALTO OCR for all six. LOC page PDFs are behind a Cloudflare challenge, so I read the page images through the LOC IIIF image server, cropping by percentage regions.

  | EO | Result |
  |---|---|
  | 254 | Complete. Page images of two printings (Evening Star; Minnesota sn83045366) show the one-sentence order in quotation marks. |
  | 2171 | Complete. Page image shows the full text through "(Signed) WOODROW WILSON". A Texas printing is identical. |
  | 3885-B | Complete. Washington Times banner (image checked, signed Hughes), plus a second printing the producer did not cite (Evening Star Aug. 4, 1923 p1), plus the recital in 3885-D. |
  | 4354 | Complete. Two DC papers (Star p1, Times p3) print an identical order. The Star image was checked. |
  | 5008 | Complete. The Star image confirms "The order, in full, follows:" and both paragraphs. |
  | 4782 | Only one printing (Washington Times, image checked). See below. |

  For EO 4782, my searches of DC papers for Dec. 16-18, 1927 found no second printing. The 1928 Civil Service Commission report (Lord: "1928 CSR 78") is not on archive.org; HathiTrust and Google Books are behind CAPTCHA (NETWORK_NOTES), and I did not bypass it. I still accept "no", with a limiting predicate:
  - The quoted text runs between quotation marks from "It is hereby ordered" to "excused from duty on that date."
  - It is word for word the template sentence of EO 5008 and EO 5238. The only extra sentence in those orders is "not ... a precedent", which can only reinforce "no".
  - Lord records amendments of other orders whenever an order makes them (5353, 3885-D, 4644). Its 4782 entry records none.
  - So a hidden standing clause is very unlikely.
- **No other independent official printings found** for these six (APP, Congressional Record or department circulars). I list the attempts below.

## Focus findings
- **(b) EO 5353 / TC09: confirmed.**
  - The deferral of EO 4644 is tied "In view of this order" to the May 31, 1930 closing, and the order says it is "not to be deemed as establishing a precedent". Its footprint is the 1930 season start only.
  - Even if read as a permanent amendment, the deferral had nothing left to act on after the Act of Mar. 3, 1931 (46 Stat. 1482): four-hour Saturdays "throughout the year".
- **(c) EO 9379 and the other wage boards.**
  - The "OCR-damaged" 1943 story is clearly legible in the page image. It confirms that Vinson approved the increase recommended by the special emergency board.
  - The "no" does not depend on that story. The board can act only "within the limitations of the Act of October 2, 1942 and the Executive Orders and Directives issued thereunder". Its effectiveness clause runs through the Economic Stabilization Director.
    - EO 9801 (FR text verified) terminated all such controls "including any Executive order ... issued thereunder".
    - OES functions had already been transferred (EO 9762).
    - The Panel the members came from was revoked (EO 9883).
  - Correction: EO 9379 and EO 9388 cite the First War Powers Act. EO 9801 reaches their stabilization controls, not the creation of the boards as such. EO 9413 also cites the Stabilization Act, so EO 9801 reaches it directly.
  - **EO 9801 savings clause: not a current effect (TC04/TC08).**
    - It keeps the old orders in force only "for the purpose of sustaining any proper suit, action, or prosecution" about pre-Nov. 9, 1946 offenses, rights or liabilities.
    - It does not apply the board orders' terms to any present actor (TC05).
    - Every such suit is time-barred: 28 U.S.C. 2462 (5 years), 18 U.S.C. 3282 (5 years) and 28 U.S.C. 2401(a) (6 years), all read from LII.
    - CourtListener finds 0 cases citing EO 9379, 9388 or 9413.
    - Dissent noted for the record: a stricter reviewer could cite the codebook line "residual terms with no proved surviving subjects yield indeterminate". I reject that reading because the limitation statutes close the saved scope by rule, not by inference from silence.
- **(d) EO 9172: verified.** The FR text of EO 9883 revokes EO 9172 in full, with no savings clause.
- **(e) EO 9958: verified.**
  - EO 9965 supersedes it, per both the FR and APP texts.
  - PEB No. 62 reported on July 9, 1948 as the board "designated ... under Executive Order 9958 ... and redesignated by Executive Order 9965".
  - The 30-day status quo has run.
  - EO 12553 (1986) lists EO 9965 as revoked.

## Rules (TC16)
- **R-S9CB-DATED-CLOSING-SPENT:** all 12 covered orders meet every predicate on their own text.
- **R-S9CB-WARTIME-SPECIAL-WAGE-BOARD-SPENT:** should be reworded. Make "mandate confined within Stabilization Act limits, frame terminated by EO 9801" the deciding predicate, and treat completion evidence as supporting. The current wording "mandate defined by the Stabilization Act" is wrong for 9379 and 9388.
- **R-S9CB-RLA10-BOARD-SUPERSEDED-AND-REPORTED (EO 9958):** predicates met.

## Systematic problems
- No systematic errors found.
- Minor issues:
  - The producer under-reported corroboration: the second 3885-B printing, and the legible 1943 page image.
  - The 9379/9388 authority wording in the rule is imprecise.
  - EO 4782 remains single-source, with completeness inferred.

## Retrieval log (STANDING RULE)
| Source | Attempt | Result |
|---|---|---|
| tile.loc.gov page PDF | curl, with and without browser UA | 403 Cloudflare "Just a moment"; not bypassed |
| tile.loc.gov IIIF image (pixel region + info.json) | curl | info.json timed out or gave 503 at times; switched to `pct:` regions, then 200 |
| tile.loc.gov ALTO XML | curl | 200, with one 520 (retried) |
| loc.gov search JSON | curl with browser UA | 403 Cloudflare challenge |
| loc.gov search JSON | curl default UA | 200 |
| archive.org advancedsearch, US CSC annual reports 1926-32 | 3 queries | Not held (only 1903 volumes) |
| HathiTrust / Google Books | per NETWORK_NOTES | CAPTCHA; not attempted further, by rule |
| govinfo FR issues | 3 issues | 200 |
| APP | 15 documents | 200 |
| LII (28 U.S.C. 2462, 2401; 18 U.S.C. 3282) | curl | 200 |

## Files
- `reviews.jsonl` (18 records).
- Scripts in `code/`.
- `cache/` holds original bytes with `.meta.json` (url, retrieved_utc, sha256, text_sha256, extraction method), extracted `.txt` files, and IIIF page-image crops `img_*.jpg`.
