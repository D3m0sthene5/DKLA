import json,hashlib,os,sys
base=sys.argv[1]
ok=0;bad=[]
for l in open(os.path.join(base,'evidence.jsonl')):
    e=json.loads(l)
    lf=e['local_file']
    p=lf if os.path.isabs(lf) else os.path.join(base,lf)
    if not os.path.exists(p):
        # try relative to s9
        p2=os.path.join(base,'..','..',lf)
        p = p2 if os.path.exists(p2) else p
    if not os.path.exists(p):
        bad.append((e['evidence_id'],'missing',lf));continue
    b=open(p,'rb').read()
    sha=hashlib.sha256(b).hexdigest()
    shaok = sha==e['local_file_sha256']
    t=b.decode('utf-8','replace')
    qok = e['quote'] in t
    if not (shaok and qok): bad.append((e['evidence_id'],'sha' if not shaok else '', 'quote' if not qok else '',lf))
    else: ok+=1
print('ok',ok); 
for x in bad: print(x)
