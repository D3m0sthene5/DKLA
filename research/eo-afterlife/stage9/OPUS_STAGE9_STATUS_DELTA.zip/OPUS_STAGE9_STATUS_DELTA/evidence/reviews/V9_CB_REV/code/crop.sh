#!/bin/bash
# crop.sh <id> <ndnp path> <altoW> <altoH> <x> <y> <w> <h>   (IIIF pct region; no info.json needed)
id=$1; p=$2; AW=$3; AH=$4; x=$5; y=$6; w=$7; h=$8
iid="service:ndnp:$(echo $p | tr '/' ':')"
R=$(python3 -I -c "print('pct:%.3f,%.3f,%.3f,%.3f'%($x*100/$AW,$y*100/$AH,$w*100/$AW,$h*100/$AH))")
$(dirname $0)/fetch.sh "$id" jpg "https://tile.loc.gov/image-services/iiif/$iid/$R/pct:60/0/default.jpg"
