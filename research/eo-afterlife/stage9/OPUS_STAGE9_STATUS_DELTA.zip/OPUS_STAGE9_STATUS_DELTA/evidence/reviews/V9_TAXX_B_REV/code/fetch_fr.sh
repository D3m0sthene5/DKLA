#!/bin/bash
# usage: fetch_fr.sh DATE  -> cache/fr_DATE.pdf (+meta, txt); deletes PDF if >20MB after recording sha
D=$1; C=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_TAXX_B_REV/cache
U="https://www.govinfo.gov/content/pkg/FR-$D/pdf/FR-$D.pdf"
T=$(date -u +%Y-%m-%dT%H:%M:%SZ)
out=$(curl -sSL -o $C/fr_$D.pdf -w '%{http_code} %{content_type} %{url_effective} %{size_download}' "$U")
read code ct fu sz <<<"$out"
sha=$(sha256sum $C/fr_$D.pdf | cut -d' ' -f1)
pdftotext -layout $C/fr_$D.pdf $C/fr_$D.txt 2>/dev/null
tsha=$(sha256sum $C/fr_$D.txt | cut -d' ' -f1)
kept=true
if [ "$sz" -gt 20000000 ]; then rm $C/fr_$D.pdf; kept=false; fi
cat > $C/fr_$D.meta.json <<J
{"url":"$U","final_url":"$fu","retrieved_utc":"$T","http_status":$code,"content_type":"$ct","size_bytes":$sz,"sha256":"$sha","method":"curl original bytes","text_file":"fr_$D.txt","text_extraction":"pdftotext -layout","text_sha256":"$tsha","pdf_kept":$kept,"note":"PDF deleted after hashing if >20MB (disk rule); sha256 is of the original bytes"}
J
echo "$D $code $sz $sha kept=$kept"
