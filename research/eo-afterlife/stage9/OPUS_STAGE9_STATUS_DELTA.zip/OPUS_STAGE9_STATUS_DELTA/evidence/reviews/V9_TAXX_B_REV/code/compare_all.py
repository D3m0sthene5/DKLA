import json,re,hashlib,sys
B='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/'
S=B+'shards/S9_TAXX_B/'; R=B+'reviews/V9_TAXX_B_REV/'
E={json.loads(l)['evidence_id']:json.loads(l) for l in open(S+'evidence.jsonl')}
pc=json.load(open(R+'predicate_check.json'))
fmap={l.split()[0]:l.split()[3] for l in open(S+'code/fr_map.txt')}
out={}
for l in open(S+'status_proposals.jsonl'):
    p=json.loads(l); n=p['instrument_id'][3:]; d=fmap[n]
    pm=json.load(open(S+'cache/fr_'+d+'.meta.json')); rm=json.load(open(R+'cache/fr_'+d+'.meta.json'))
    mytxt=open(R+'cache/fr_'+d+'.txt',encoding='utf-8',errors='replace').read()
    frq=[E[i]['quote'] for i in p['evidence_ids'] if i in E and E[i]['source_id']=='fr_'+d]
    lim=p['family_rule_predicate_check']['own_text_limit']
    limkey=lim.replace('during the ','').split()[0][:8]
    # find limit word near the order heading in my text
    flat=' '.join(mytxt.split())
    pos=[m.start() for m in re.finditer(n[:2]+r'\s?'+n[2:],flat)]
    near=any(limkey.lower() in flat[x:x+3000].lower() for x in pos)
    out[n]={'fr_date':d,'orig_sha_identical':pm['sha256']==rm['sha256'],'text_sha_identical':pm.get('text_sha256')==rm['text_sha256'],
            'producer_fr_quotes_in_my_text':all(q in mytxt for q in frq),'n_fr_quotes':len(frq),'own_limit_found_near_order_in_my_text':near,'retrieved_utc':rm['retrieved_utc'],'url':rm['url'],'sha256':rm['sha256']}
    print(n,d,out[n]['orig_sha_identical'],out[n]['text_sha_identical'],out[n]['producer_fr_quotes_in_my_text'],len(frq),near)
json.dump(out,open(R+'refetch_compare.json','w'),indent=1)
print('all identical:',all(v['orig_sha_identical'] for v in out.values()), 'all limits found:',all(v['own_limit_found_near_order_in_my_text'] for v in out.values()))
