# V9_TAXX_B_REV review of shard S9_TAXX_B

- Reviewer: V9_TAXX_B_REV. I did not produce this shard. Codebook 2.0.0; cutoff 2026-10-14.
- Actual UTC start: 2026-10-16T17:49:18Z. Actual UTC end: 2026-10-16T19:41Z. The work paused in between for a usage-limit reset; fetch times in the meta files are the real `date -u` values.
- Outputs:
  - reviews.jsonl (42 records)
  - evidence_check.json
  - predicate_check.json
  - refetch_compare.json
  - nara_sample_check.json
  - cache/ (original bytes or hashes, meta.json, .txt)
  - code/
  - attempts.log
- No agents were launched. The sister shard was not consulted. No PDF over 20 MB is kept: each was hashed, its text extracted, and the PDF deleted.

## Counts by verdict
- accept: 0
- accept_with_correction: 42. All 42 are no/no, the same statuses the producer proposed.
- reject_to_indeterminate: 0
- reject_other: 0
- **Error rate (non-accept / total): 42/42 = 100% by the protocol formula. Status disagreement: 0/42 = 0%.**
- Every record needed a correction for the same two reasons, described under "Systematic problems" below. Neither one changes a status.
- Ownership: every record stays OWNERSHIP_NOT_VERIFIED. This review promotes nothing.

## Gate 1: evidence fidelity (script: code/check_evidence.py)
- 352/352 producer evidence records pass all of these checks:
  - the quote is an exact substring of its .txt file;
  - the text sha256 matches;
  - the original-file sha256 matches, or, for excerpted PDFs, the meta sha256 equals the original's and the excerpt sha256 matches;
  - the meta.json sha256 and retrieval time agree with the evidence record.
- No dangling evidence IDs. All 42/42 proposals are clean.

## Gate 2: re-fetch (all 42, not just a sample)
- I re-fetched all 41 Federal Register (FR) daily issues that carry the 42 orders from govinfo (11655 and 11656 share one issue). Each is byte-identical to the producer's copy (same original sha256 and same pdftotext sha256).
- Every producer FR quote is present in my text. Each order's own limit ("during the Nth Congress", or for 11080 "during the period ending on June 30, 1963") was located in my own extraction. Six of these needed a manual read because of OCR splits: 11194, 11204, 11235, 11454, 11461 and 11465. All six were confirmed.
- Detailed read of the full operative text for 16 orders: 11080, 11859, 11535, 11055, 10916, 11065, 11082, 11133, 11624, 11711, 11505 (with 11859, 9 Senate-committee orders in this sample), 10935, 11217, 11722, 11370, 11611.
- I re-fetched APP myself for 11055, 11080, 11859 and 11535.
- NARA disposition tables, fetched myself:
  - Tables: 1961-kennedy, 1963-kennedy, 1963-johnson, 1965, 1967, 1970, 1971, 1973, 1975. The 1962 table is a real 404.
  - The 14 sample entries show no Amended, Revoked or See line.
  - No 1963 Foreign Relations order extends EO 11080.

## Focus findings
- **EO 11080.** FR and APP both read "shall, during the period ending on June 30, 1963, be open to inspection". The time phrase limits the grant itself. That makes it a sunset, not a TC10 performance deadline. **RULE-TAXX-OWN-DATE-LIMIT is sound** for its one member. For any future member, the predicate should require two things:
  - the date qualifies the grant of access;
  - no clause operates after that date.
- **EO 11859.**
  - It cites only 1954 Code sec. 6103(a). Under 26 U.S.C. 7851(a)(6)(A), subtitle F reaches 1939-Code taxes only as (B)/(C) provide. So the order is 1954-Code-only by its authority, even though some returns filed in 1955 (estates, fiscal years) were 1939-Code returns.
  - First cessation is 1977-01-01 (TRA 1976 sec. 1202, no savings). Its own 94th-Congress limit (1977-01-03) is a backstop.
  - The Privacy Act clause governs "such inspection" and ends with the permission.
  - Correction: its flag post_term_clause=true contradicts the record's own text.
- **EO 11535.** The copy clause reads "Whenever a return is open to inspection…" and ends with the 91st Congress. Same flag correction as 11859.
- **EO 11055.** FR (byte-identical re-fetch) says "1950 to 1962". My APP re-fetch says "1950 to 1969". FR controls, and the status is unaffected.
- **1939-Code check.** The 27 orders that cite 1939 Code sec. 55(a) each rest 'no' on their own limit; none rests on TRA 1976. This was checked by script against each order's own APP text, and against FR for the sample. The 1939 flag matched the cited authority in 42/42.

## RULING on the confidentiality clause
**The text.** I retrieved FR 1955-05-05 (20 FR 3024-25) myself.
- T.D. 6133 adds 26 CFR (1939) **§458.324** (1939 Code). T.D. 6132 adds **§301.6103(a)-101** (1954 Code).
- Both were approved by President Eisenhower on May 3, 1955. Both say: "Any information thus obtained by such committee or subcommittee shall be held confidential: Provided, however, That any portion thereof relevant or pertinent to the purpose of the investigation may be submitted by the investigating committee to the appropriate house of the Congress."
- They apply to committees "specially authorized … by an Executive order issued … on or after the date of the approval of this section". Inspection is "subject to the conditions and restrictions imposed by the Executive order and the rules and regulations".
- The producer never retrieved this text.

**(1) Footprint: the duty belongs to the regulation, not to the order.**
- None of the 42 orders states a confidentiality duty. Each says only that "Such inspection shall be in accordance and upon compliance with" the regulations.
- That makes the regulations a condition on an inspection permission that has ended.
- The duty's legal source is the statute (old 6103(a) / 1939 sec. 55(a): "rules and regulations prescribed by the Secretary … and approved by the President") plus a separate presidential approval on May 3, 1955. That approval predates all 42 orders.
- The order's only role is a historical trigger: it made the committee "specially authorized". Under TC08, a residual needs continued application of EO terms or EO authority. A duty that rests on separately authorized regulation text, applied to information received in the past, is a historical consequence that TC04 excludes by default.
- So it is not a TC04 residual or a TC08 residual of these orders.

**(2) Whether and how it ended.**
- 1954 Code: §301.6103(a)-101 was **deleted by T.D. 7573**. Source: 43 FR 55759-60, Nov 29, 1978, effective that day, saying the pre-1976 sec. 6103 regulations "have been made obsolete by reason of the amendments of section 6103". I confirmed this in the FR text and in the 1981 CFR List of Sections Affected (archive.org scan).
- Since 1977-01-01, disclosure of returns and return information is governed by statute: 26 U.S.C. 6103(a) ("shall be confidential … except as authorized by this title"; it covers former officers and employees), 7213(a)(1), and 6103(f)(3)-(4).
- Treasury's continuity rule, §301.6103(a)-1 (T.D. 7723, 1980), covers Federal-agency recipients only. Congress is not a Federal agency.
- 1939 Code: I found **no removal notice for 26 CFR (1939) §458.324**. It is absent from the 1981 Title 26 Parts 300-499 volume, but the 1939-Code regulations were a separate CFR series. Whether new 6103 reaches 1939-Code returns is also unsettled; new 6103(b)(1) defines returns "under the provisions of this title". This part is unresolved, but under (1) it does not matter.

**(3) Result.**
- Any-effect stays **no** for all 42. The duty is outside the orders' footprint, not an unresolved EO residual.
- Recorded dissent and limiting predicate: under the stricter view, the duty is incorporated into the order by its "upon compliance with" clause. On that view:
  - the 27 orders that reach 1939-Code returns would become any-effect **indeterminate**, pending proof that §458.324 ended;
  - the 15 orders that are 1954-Code-only stay no/no under either view, because of the 1978 deletion and TRA 1976.
- **Pilot S9_TAX (8 accepted 'no', not edited):**
  - My ruling changes nothing there.
  - Under the stricter view, the pilot orders that reach 1939-Code returns (6342, 9281, 10455/10566, 11020, 11720) would face the same question, about their own Part 458 regulations (for example, §458.320 for EO 10455, approved May 22, 1953 as a separate T.D.).
  - 11786 and 11900 (1954-Code-only) would not.

## Systematic problems (corrections in every record; no status changes)
1. The T.D. 6132/6133 text was not retrieved, and the confidentiality term was not mapped. The 'Condition' clause end basis ("no inspection possible") overlooks a duty that operates after inspection. This is a footprint/residual gap, which I close with the ruling above.
2. The rule predicate "Treasury regulations approved with it" and the flag `treasury_regs_approved_with_it=true` are inaccurate. The regulations were approved on 1955-05-03 and only referenced by the orders. The producer's own report says no new regulations were printed with the orders.
3. `post_term_clause=true` on 11535 and 11859 contradicts the records' text. It should be renamed (for example, `extra_clause`).

## Not verified
- When or whether §458.324 (1939 series) was removed.
- The content of the 1975-76 revision of §301.6103(a)-101(a) (40 FR).
- Whether congressional members or staff are "officers or employees of the United States" under 6103(a)(1). That question does not affect the EO ruling.
- The NARA 1962 table (404). EOs 11055 and 11065 are closed by their own 87th-Congress text.
