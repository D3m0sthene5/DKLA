import sys,re
txt=open(sys.argv[1],encoding='utf-8',errors='replace').read()
n=sys.argv[2]
for m in re.finditer(r'Executive\s+Order\s+'+n, txt):
    print('=== at',m.start()); print(txt[m.start():m.start()+int(sys.argv[3]) if len(sys.argv)>3 else m.start()+3500]); break
