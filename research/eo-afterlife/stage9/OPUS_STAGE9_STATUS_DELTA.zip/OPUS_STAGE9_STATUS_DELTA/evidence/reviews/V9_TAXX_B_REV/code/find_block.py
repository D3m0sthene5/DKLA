import sys,re
L=open(sys.argv[1],encoding='utf-8',errors='replace').read().split('\n')
n=sys.argv[2]; pat=re.compile(r'(?i)(executive|order)\W*(order)?\W*'+n[0]+r'\s*'+r'\s*'.join(n[1:])+r'\b')
for i,l in enumerate(L):
    if pat.search(l) and not re.search(r'_{3,}|-{4,}',l):
        out=[]
        for j in range(i,min(i+45,len(L))):
            out.append(L[j].rstrip()[:115])
            if re.search(r'(?i)fi\s*l\s*e\s*d',L[j]) and j>i+3: break
        print('\n'.join(x for x in out if x.strip())); print('-----'); break
