import json,hashlib,sys,os
B='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9'
S=B+'/shards/S9_TAXX_B'
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
res={}
E={}
for l in open(S+'/evidence.jsonl'):
    e=json.loads(l); E[e['evidence_id']]=e
    root=B if e.get('path_base') else S
    r={}
    tf=os.path.join(root,e['text_file'])
    txt=open(tf,'rb').read().decode('utf-8','replace')
    r['quote_in_txt']= e['quote'] in txt
    r['quote_nonempty']=len(e['quote'].strip())>0
    r['txt_sha']= sha(tf)==e['text_sha256']
    lf=os.path.join(root,e['local_file'])
    r['local_exists']=os.path.exists(lf)
    if e.get('local_file_note'):
        mp=os.path.join(S,'cache',e['source_id']+'.meta.json')
        m=json.load(open(mp))
        r['orig_sha_meta']= m.get('sha256')==e['local_file_sha256']
        ex=m.get('excerpt',{})
        r['excerpt_sha']= r['local_exists'] and sha(lf)==ex.get('sha256')
        r['sha_ok']=r['orig_sha_meta'] and r['excerpt_sha']
    else:
        r['sha_ok']= r['local_exists'] and sha(lf)==e['local_file_sha256']
    # meta file match
    mp=os.path.join(root, os.path.dirname(e['local_file']), e['source_id']+'.meta.json')
    if os.path.exists(mp):
        m=json.load(open(mp)); r['meta_sha_match']= m.get('sha256')==e['local_file_sha256']; r['meta_time_match']=m.get('retrieved_utc')==e['retrieved_utc']
    else: r['meta_sha_match']=None
    res[e['evidence_id']]=r
bad={k:v for k,v in res.items() if not (v['quote_in_txt'] and v['txt_sha'] and v['sha_ok'] and v['quote_nonempty'])}
metabad={k:v for k,v in res.items() if v['meta_sha_match'] is False or v.get('meta_time_match') is False}
nometa=[k for k,v in res.items() if v['meta_sha_match'] is None]
print('total',len(res),'bad',len(bad)); print(json.dumps(bad,indent=0)[:3000])
print('meta mismatches',json.dumps(metabad)[:2000]); print('no meta',nometa)
# per proposal
P=[json.loads(l) for l in open(S+'/status_proposals.jsonl')]
per={}
for p in P:
    refs=set(p['evidence_ids'])|set(p['controlling_authority_evidence_ids'])
    for f in p['operative_footprint']: refs|=set(f['evidence_ids'])
    dang=sorted(refs-set(E))
    q=all(res[i]['quote_in_txt'] for i in refs if i in res); s=all(res[i]['sha_ok'] and res[i]['txt_sha'] for i in refs if i in res)
    per[p['instrument_id']]={'n_refs':len(refs),'dangling':dang,'quotes_exact':q and not dang,'sha_match':s and not dang}
json.dump({'per_evidence':res,'per_proposal':per},open(sys.argv[1],'w'),indent=1)
print(sum(1 for v in per.values() if v['quotes_exact'] and v['sha_match']),'of',len(per),'proposals fully clean')
print([k for k,v in per.items() if v['dangling']])
