import sys,re
# print block from heading containing order number to "Filed" line
txt=open(sys.argv[1],encoding='utf-8',errors='replace').read().split('\n')
n=sys.argv[2]
for i,l in enumerate(txt):
    if re.search(r'(Executive|Order)[\s\-]*(Order)?[\s\-]*'+n[:2]+r'\s?'+n[2:], l) and i<len(txt):
        for j in range(i, min(i+70,len(txt))):
            print(txt[j][:110])
            if 'Filed' in txt[j]: break
        print('-----'); break
