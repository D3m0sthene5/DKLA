import json,re,sys
B='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/S9_TAXX_B/'
E={json.loads(l)['evidence_id']:json.loads(l) for l in open(B+'evidence.jsonl')}
out={}
for l in open(B+'status_proposals.jsonl'):
    p=json.loads(l); n=p['instrument_id'][3:]
    frs=[E[i] for i in p['evidence_ids'] if i in E and E[i]['source_id'].startswith('fr_')]
    apps=[E[i] for i in p['evidence_ids'] if i in E and E[i]['source_id'].startswith('app_')]
    app=open(B+apps[0]['text_file'],encoding='utf-8',errors='replace').read() if apps else ''
    a=' '.join(app.split())
    i=a.find('By virtue'); blk=a[i:i+2500]
    cites1939=bool(re.search(r'1939',blk[:400]))
    m=re.search(r'years? (\d{4}) (?:to|through) (\d{4})',blk)
    cong=re.search(r'during the ([A-Z][a-z\-]+(?: [A-Z]?[a-z\-]+)?) Congress',blk)
    datelim=re.search(r'during the period ending on ([A-Z][a-z]+ \d+, \d{4})',blk)
    c=p['family_rule_predicate_check']; fc=p.get('first_cessation',{})
    perm_end=p['operative_footprint'][0]['end']
    extra=[f['clause'][:60] for f in p['operative_footprint'][1:] if not f['clause'].startswith(('Condition','Effective','No effective'))]
    out[n]={'app_cites_1939':cites1939,'years':m.groups() if m else None,'congress':cong.group(1) if cong else None,'datelim':datelim.group(1) if datelim else None,
      'flag_1939':c['reaches_1939_code_returns'],'own_limit':c['own_text_limit'],'first_cess':fc,'perm_end_basis':perm_end['basis'][:80],'extra':extra,
      'confidential_mentioned': 'confiden' in json.dumps(p).lower()}
    o=out[n]
    issues=[]
    if o['app_cites_1939']!=o['flag_1939']: issues.append('1939flag_vs_authority')
    if o['flag_1939'] and 'TRA' in perm_end['basis']: issues.append('1939_order_closed_by_TRA')
    lim=o['congress'] or o['datelim']
    if not lim or lim.split()[0].lower() not in o['own_limit'].lower(): issues.append('limit_mismatch')
    o['issues']=issues
    print(n,o['years'],lim,'1939auth',o['app_cites_1939'],'flag',o['flag_1939'],'|',fc.get('mechanism'),'|',issues,'| conf:',o['confidential_mentioned'],o['extra'])
json.dump(out,open(sys.argv[1],'w'),indent=1)
