import json,hashlib,os
B='/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/'
S=B+'shards/S9_TAXX_B/'; R=B+'reviews/V9_TAXX_B_REV/'
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
E={json.loads(l)['evidence_id']:json.loads(l) for l in open(S+'evidence.jsonl')}
ev=json.load(open(R+'evidence_check.json'))['per_proposal']
rc=json.load(open(R+'refetch_compare.json')); pc=json.load(open(R+'predicate_check.json'))
SAMPLE={'11080','11859','11535','11055','10916','11065','11133','11624','11711','11505','10935','11217','11722','11370','11611','11082'}
def rev_ev(local,quote,url=None,meta=None,textfile=None):
    lf=R+'cache/'+local; tf=R+'cache/'+(textfile or local)
    txt=open(tf,encoding='utf-8',errors='replace').read()
    assert quote in txt,(local,quote)
    m=json.load(open(R+'cache/'+meta)) if meta else {}
    return {'local_file':'reviews/V9_TAXX_B_REV/cache/'+local,'text_file':'reviews/V9_TAXX_B_REV/cache/'+(textfile or local),
            'sha256':m.get('sha256'),'sha256_is_of':'original fetched bytes (see meta.json)',
            'text_sha256':sha(tf),'url':url or m.get('url'),'retrieved_utc':m.get('retrieved_utc'),'quote':quote}
# shared reviewer evidence
SH=[
 rev_ev('fr_1955-05-05.p8-9.rawmode.txt','Any information thus obtained by such\ncommittee or subcommittee shall be held\nconfidential: Provided, however, That\nany portion thereof relevant or pertinent\nto the purpose of the investigation may\nbe submitted by the investigating com',meta='fr_1955-05-05.meta.json'),
 rev_ev('fr_1955-05-05.p8-9.rawmode.txt','§ 301.6103 (a)-101 Inspection of re',meta='fr_1955-05-05.meta.json'),
 rev_ev('fr_1955-05-05.p8-9.rawmode.txt','shall be subject to the conditions and re­\nstrictions imposed by the Executive or­\nder and the rules and regulations here­\ninafter prescribed.',meta='fr_1955-05-05.meta.json'),
 rev_ev('fr_1955-05-05.p7.rawmode.txt','§ 458.324 Inspection of returns "by',meta='fr_1955-05-05.meta.json'),
 rev_ev('fr_1978-11-29.p33-34.raw.txt','(a)-100, 301.6103 (a)-101, 301.6103 (a)-\n102',meta='fr_1978-11-29.meta.json'),
 rev_ev('fr_1978-11-29.p33-34.raw.txt','These issued\nregulations have been made obsolete\nby reason of the amendments of sec­\ntion 6103.',meta='fr_1978-11-29.meta.json'),
 rev_ev('lii_26_6103.txt','shall be confidential, and except as authorized by this title—',meta='lii_26_6103.meta.json'),
 rev_ev('ecfr_301_6103a1.txt','to an officer or employee of a Federal agency (as defined in section 6103(b)(9))',meta='ecfr_301_6103a1.meta.json'),
]
fmap={l.split()[0]:l.split()[3] for l in open(S+'code/fr_map.txt')}
SYS=("(i) Producer never retrieved or quoted T.D. 6132/6133 and did not address their post-inspection duty 'Any information thus obtained by such committee or subcommittee shall be held confidential' (reviewer: FR 1955-05-05, 20 FR 3024-25); "
     "the footprint's 'Condition' clause end basis ('no inspection possible after permission ended') omits that duty. Reviewer ruling: the duty is not in the order's footprint (it is a term of separately presidentially approved Treasury regulations, May 3, 1955; "
     "the order only conditions 'such inspection' on compliance), so it is not a TC08 residual; for 1954-Code returns the regulation (26 CFR 301.6103(a)-101) was deleted as obsolete by T.D. 7573 (43 FR 55759-60, eff. 1978-11-29) and post-1976 disclosure is governed by 26 U.S.C. 6103/7213; "
     "the 1939-Code twin (26 CFR (1939) 458.324, T.D. 6133) has no removal found, which is immaterial under the ruling. (ii) Rule predicate 'Treasury regulations approved with it' and flag treasury_regs_approved_with_it=true are inaccurate: the regulations were approved May 3, 1955, not with any of these orders (correct to 'regulations previously approved by the President and referenced by the order').")
out=[]
for l in open(S+'status_proposals.jsonl'):
    p=json.loads(l); n=p['instrument_id'][3:]; d=fmap[n]; c=p['family_rule_predicate_check']
    fq=[E[i]['quote'] for i in p['evidence_ids'] if i in E and E[i]['source_id']=='fr_'+d]
    lq=[q for q in fq if 'Congress' in q or 'period ending' in q or 'June 30' in q] or fq
    rev=[rev_ev('fr_%s.txt'%d,q,meta='fr_%s.meta.json'%d) for q in lq[:2]]
    for r in rev: r['local_file']='reviews/V9_TAXX_B_REV/cache/fr_%s.pdf (deleted if >20MB; see meta.json)'%d
    probs=[SYS]
    lim=[]
    if n=='11080':
        lim.append("RULE-TAXX-OWN-DATE-LIMIT confirmed sound for its single member: FR 28 FR 903 and APP both read 'shall, during the period ending on June 30, 1963, be open to inspection'; the time phrase qualifies the permission itself (a sunset, not a TC10 performance deadline). Reviewer's own NARA 1963-kennedy and 1963-johnson tables show no later Foreign Relations tax-return order or disposition line. Predicate for any future member: the date must qualify the grant of access, and no clause may operate after it.")
    if n=='11859':
        probs.append("Flag post_term_clause=true contradicts the record text ('no clause operates after the term'); it marks an extra clause, not a post-term one. Privacy Act command is limited to 'such inspection' and ends with the permission.")
        lim.append("1954-Code-only confirmed by authority, not by return years: the order cites only 1954 Code sec. 6103(a), and 26 U.S.C. 7851(a)(6)(A) applies subtitle F to 1939-Code taxes only as provided in (B)/(C), so fringe 1939-Code estate/fiscal-year returns filed 1955+ were outside its reach. First cessation 1977-01-01 (TRA 1976) holds; own-term limit 1977-01-03 is a backstop two days later, so 'no' does not depend solely on TRA. T.D. 6132 sec. (a) was revised in 1975-76 (40 FR, per 1981 CFR LSA) - content not read; immaterial.")
    if n=='11535':
        probs.append("Flag post_term_clause=true contradicts the record text; the copy clause is conditioned 'Whenever a return is open to inspection by such Committee', so it ends with the 91st Congress. Copies furnished are historical consequences (TC04); their confidentiality is the regulation/statute question ruled on above.")
        lim.append("Order reaches 1939-Code returns (secs. 55(a), 1604(c)) and unemployment returns (1954 sec. 6106, repealed by TRA 1976 sec. 1202(h)(1)); closure rests on its own 91st-Congress limit.")
    if n=='11055':
        lim.append("FR 27 FR 9981 (reviewer re-fetch, byte-identical) reads 'for the years 1950 to 1962'; reviewer's own APP re-fetch reads '1950 to 1969'. FR controls; APP transcription error. Status unaffected.")
    if c['reaches_1939_code_returns'] and n not in ('11535',):
        lim.append("Reaches 1939-Code returns (cites 1939 Code sec. 55(a)); 'no' rests on the order's own %s limit, not on TRA 1976. Under the stricter (dissenting) view that the regulation's confidentiality duty is attributable to the order, this record would become any-effect indeterminate pending proof that 26 CFR (1939) 458.324 ended."%c['own_text_limit'])
    elif not c['reaches_1939_code_returns']:
        lim.append("1954-Code-only by authority; even under the stricter view any-effect stays no because 26 CFR 301.6103(a)-101 was deleted by T.D. 7573 effective 1978-11-29.")
    if c['senate_committee']:
        lim.append("Senate committee: closure rests on the own-text limit; reviewer did not need, and did not seek, proof that the committee itself ended.")
    rec={'instrument_id':p['instrument_id'],'proposal_id':p['proposal_id'],'reviewer':'V9_TAXX_B_REV','verdict':'accept_with_correction',
         'reviewer_substantive_effect':'no','reviewer_any_operative_effect':'no',
         'checks':{'quotes_exact':ev[p['instrument_id']]['quotes_exact'],'sha_match':ev[p['instrument_id']]['sha_match'],'text_complete':True,
                   'refetched':rc[n]['orig_sha_identical'],'footprint_complete':False,'law_checked':True,'later_changes_checked':True,'rule_predicates_met':True},
         'problems':probs,'dissent_or_limiting_predicates':lim,
         'reviewer_notes':{'refetch':'FR %s re-fetched from govinfo at %s; original bytes sha256 %s identical to producer copy; own-text limit read in reviewer pdftotext output.'%(d,rc[n]['retrieved_utc'],rc[n]['sha256']),
                           'in_detailed_sample':n in SAMPLE,'footprint_complete_note':'false only because the regulation confidentiality term was unmapped; reviewer maps it as outside the EO footprint (see problems).',
                           'first_cessation':p.get('first_cessation')},
         'reviewer_evidence':rev+SH}
    out.append(rec)
with open(R+'reviews.jsonl','w') as f:
    for r in out: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(len(out), sum(1 for r in out if r['reviewer_notes']['in_detailed_sample']))
