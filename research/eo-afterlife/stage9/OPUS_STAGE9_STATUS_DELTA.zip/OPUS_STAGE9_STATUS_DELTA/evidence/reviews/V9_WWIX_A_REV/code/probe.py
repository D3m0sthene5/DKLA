import sys
sys.path.insert(0,sys.argv[1])
from ev import ev
R="reviews/V9_WWIX_A_REV/cache/"
tests=[
(R+"ia_cgi_ar1920.txt","The new immigration station at Baltimore, adjoining the Fort","preparations are under way for assuming custody of the"),
(R+"ia_paschj_191901.txt","At U. S. A. General Hospital No. 2, lo-","large brick buildings"),
(R+"ia_jama_19200626.txt","Immigration Station Turned Over to U. S. Public Health","General Hospital No. 2 group."),
(R+"ia_interior_1919.txt","Semipermanent  buildings. — The  semipermanent  buildings  which","partly  occupied."),
(R+"ia_dc_1919_2.txt","Work was completed on the extension of a 24-inch trunk water main in","area affected."),
(R+"ia_dc_1919_2.txt","The following gravity trunk mains were laid and put into service.","above-mentioned territory."),
(R+"ia_usda_whattosee1924.txt","The  Graham  Building,   14th  and  E  Sts .","INTRODUCTION  of  the  BUREAU  OF  PLMT  INDUSTRY,"),
("reviews/V9_WWI_REV/cache/ia_compgen_v7.txt","It is obvious that the purpose of the act of March 4, 1917","ceased to exist."),
("reviews/V9_WWI_REV/cache/ia_compgen_v7.txt","8-hour law (whereby laborers on Government work were not per-","tion condition."),
("reviews/V9_WWI_REV/cache/ia_compgen_v7.txt","was conditioned upon the continuance of the national emergency","the emergency had passed."),
("shards/S9_WWIX_A/cache/ia_phs_ar1920.txt","Savannah,  Ga.    (act  Nov.  4,  1918) 26,000.00","Savannah,  Ga.    (act  Nov.  4,  1918) 26,000.00"),
("shards/S9_WWIX_A/cache/ia_phs_ar1920.txt","ANNUAL  REPORT  OF  THE  SURGEON  GENERAL","1921"),
("shards/S9_WWIX_A/cache/ia_phs_ar1920.txt","a  7- foot  iron  fence.  A  new  laundry  has  been  constructed;","tractors."),
("shards/S9_WWI/cache/ia_lord_v1.txt","2813:  Feb.  26","2817 : Mar.  5"),
("shards/S9_WWI/cache/stat_76_357.txt","SEC. 203. The following statutes are hereby repealed","are outstanding at the time of the enactment of this Act.\n                        Approved"),
]
for t in tests:
    try:
        e=ev(*t,note="")
        print("OK",len(e['quote']),repr(e['quote'][:80]))
    except Exception as x: print("FAIL",t[1][:40],x)
