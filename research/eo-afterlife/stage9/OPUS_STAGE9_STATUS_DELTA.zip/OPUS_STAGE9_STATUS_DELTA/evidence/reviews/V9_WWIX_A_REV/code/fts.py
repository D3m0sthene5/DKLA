import json,sys,urllib.parse,subprocess
q=sys.argv[1]
u="https://archive.org/services/search/beta/page_production/?service_backend=fts&user_query="+urllib.parse.quote(q)+"&hits_per_page=30&page=1"
out=subprocess.run(["curl","-sS","--max-time","90",u],capture_output=True).stdout
try:
    d=json.loads(out)
except Exception as e:
    print("BADJSON",out[:200]); sys.exit()
b=d['response']['body']
if not b: print("ERR",d['response'].get('errors')); sys.exit()
print("total",b['hits'].get('total'))
for h in b['hits']['hits']:
    f=h['fields']; hl=h.get('highlight') or {}
    print(f.get('identifier'),'|',str(f.get('title'))[:70],'|',f.get('year'),'|',str(hl)[:300].replace('\n',' '))
