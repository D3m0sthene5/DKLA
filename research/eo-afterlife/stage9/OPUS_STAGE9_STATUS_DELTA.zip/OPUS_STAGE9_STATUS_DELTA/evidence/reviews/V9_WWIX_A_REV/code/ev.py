import json,hashlib,os
B="/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/"
def sha(p): return hashlib.sha256(open(B+p,'rb').read()).hexdigest()
def ev(txtrel,start,end,note,metarel=None):
    t=open(B+txtrel,encoding='utf-8').read()
    i=t.index(start); j=t.index(end,i)+len(end)
    q=t[i:j]; assert q in t
    metarel=metarel or os.path.splitext(txtrel)[0]+'.meta.json'
    m=json.load(open(B+metarel))
    return {"local_file":txtrel,"sha256":sha(txtrel),"url":m.get('url'),"retrieved_utc":m.get('retrieved_utc'),"quote":q,"note":note}
def img(rel,note):
    m=json.load(open(B+rel.replace('.jpg','.meta.json')))
    assert m['sha256']==sha(rel)
    return {"local_file":rel,"sha256":m['sha256'],"url":m['url'],"retrieved_utc":m['retrieved_utc'],"quote":None,"note":note}
