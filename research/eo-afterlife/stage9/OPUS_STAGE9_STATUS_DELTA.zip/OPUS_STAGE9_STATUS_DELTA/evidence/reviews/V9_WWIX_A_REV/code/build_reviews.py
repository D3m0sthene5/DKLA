import json,sys
sys.path.insert(0,sys.argv[1])
from ev import ev,img,B
R="reviews/V9_WWIX_A_REV/cache/"
P="shards/S9_WWIX_A/cache/"
PW="shards/S9_WWI/cache/"
RW="reviews/V9_WWI_REV/cache/"

LAW=ev(PW+"stat_76_357.txt","SEC. 203. The following statutes are hereby repealed","are outstanding at the time of the enactment of this Act.\n                        Approved August 13, 1962","Pub. L. 87-581 secs. 203-204 (76 Stat. 360), read by reviewer: repeal of 40 U.S.C. 321-322, D.C. Code 22-3407/3408 (31 Stat. 1334 secs. 892-893), 40 U.S.C. 324-325 and 326; savings only for contracts existing on 1962-10-12 or let under bids then outstanding.")
PROVISO=ev(PW+"stat_39_1168.txt","That   in case of national emergency the President is authorized to","less than time and one-half for all hours work in excess of eight hours.","39 Stat. 1192: the suspension power exists only 'in case of national emergency'.")
CG1=ev(RW+"ia_compgen_v7.txt","It is obvious that the purpose of the act of March 4, 1917","ceased to exist.","7 Comp. Gen. 73, 76 (July 27, 1927): suspension authorized under the statute and the order only to meet the emergency; when that need ceased, the authority for the suspension ceased.")
CG2=ev(RW+"ia_compgen_v7.txt","The restoration of the prohibitions of the so-called","condi- \ntion.","7 Comp. Gen. 76: restoration of the eight-hour law after the emergency passed was 'imposed by operation of law'.")
CG3=ev(RW+"ia_compgen_v7.txt","was conditioned upon the continuance of the national emergency","the emergency had passed.","7 Comp. Gen. 77: an EO suspension under the 1917 Act 'was conditioned upon the continuance of the national emergency which prompted the President to authorize such suspension'.")
EMERG=[CG1,CG2,CG3,PROVISO,LAW]

def obimg(n,note): return img(R+f"ob01_n{n}.jpg",note)

CHECKS={"quotes_exact":True,"sha_match":True,"text_complete":True,"refetched":True,"footprint_complete":True,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":True}

LEGAL=("Reviewer's closure ground (iii), legal: each of these orders recites, in its own text, that the national emergency on which the suspension rests is the war-related need to finish the work ('in connection with war measures/war activities ... a national emergency'). The 1917 power exists only 'in case of national emergency' (39 Stat. 1192). The Comptroller General held in 1927 (7 Comp. Gen. 73, 76-77) that a suspension under this Act and an EO 'was conditioned upon the continuance of the national emergency which prompted the President to authorize such suspension', that the authority 'ceased to exist' when the need ceased, and that the eight-hour law was restored 'by operation of law' when the emergency passed. The decision treats the WWI emergency as passed by 1927 (restoration after the Nov. 11, 1918 armistice). So the suspension ended by operation of law well before 1962-10-12, the order was not operative on that date, and the 1962 savings clause (sec. 203-204) could not carry it, whether or not some contract for the same object existed in 1962. Limits: the Comptroller General binds executive accounting officers, not courts; the 1927 decision concerned EO 2554, whose operative clause itself says 'present emergency conditions'; and the exact date the emergency ended for each order is not pinned.")
NEED1962=("Is a showing that no contract under the order existed in 1962 needed? Reviewer answer: some showing is needed, because the 1962 savings clause kept the sec. 326 suspension power for contracts existing on 1962-10-12. It can be made in one of two ways: (a) the order was no longer operative on that date (project shown completed, a fixed term, or a legal end such as the lapse of the emergency), or (b) direct evidence about 1962 contracts. The producer's ground for this order was only that no source shows later work, plus 'any 1962 contract was long performed (TC14)'. That is inference, not a showing, so the producer's record does not support 'no' as written. The reviewer closes it with the evidence below.")
WAGE=("Wage/any-effect: the overtime right (time and a half) came from the 1917 proviso, not the order. Penalty claims and Court of Claims jurisdiction were saved only for contracts existing in 1962 (sec. 202(b)). Claims accruing 1917-1921 are long time-barred (28 U.S.C. 2501, current text; the 1918 text was not re-read by this reviewer either). No residual EO effect found.")

recs=[]
def rec(iid,verdict,sub,anyv,problems,dissent,evid,checks=None):
    c=dict(CHECKS); c.update(checks or {})
    recs.append({"instrument_id":iid,"proposal_id":f"opus:s9:status:{iid}","reviewer":"V9_WWIX_A_REV","verdict":verdict,
      "reviewer_substantive_effect":sub,"reviewer_any_operative_effect":anyv,"checks":c,"problems":problems,
      "dissent_or_limiting_predicates":dissent,"reviewer_evidence":evid})

APPSTART={2572:"I do hereby authorize",2705:"It is hereby ordered",2718:"I do hereby suspend"}
APP=lambda n:ev(R+f"app_eo{n}.txt",APPSTART[n],"WOODROW WILSON",f"APP page re-fetched by reviewer; original bytes identical (sha256) to producer copy; operative text identical.",R+f"app_eo{n}.meta.json")

# --- high confidence
rec("EO:2572","accept","no","no",[],["Own fixed term 'for thirty days' (ends c. 1917-05-03). Text re-fetched from APP, byte-identical; second printing (Messages and Papers vol. 17) in producer evidence.",WAGE],[APP(2572),LAW])
rec("EO:2705","accept","no","no",["Minor: the object includes 'other buildings that may be erected ... in connection with the present national emergency', an open-ended object; it is bounded by the order's own 'during the present national emergency' term, so P3(c) carries it, not P3(b)."],["Ends with the WWI emergency by its own term; 7 Comp. Gen. 73 (1927) confirms the emergency had passed. APP re-fetched, byte-identical.",WAGE],[APP(2705)]+EMERG)
rec("EO:2805","accept","no","no",[],["Own 'during the present national emergency' term. Page image re-fetched (OB Feb. 1918, leaf n500); bytes stored, not visually inspected.",WAGE],[obimg(500,"Official Bulletin page with EO 2805 (re-fetched original bytes)")]+EMERG)
rec("EO:2814","accept","no","no",["Date conflict confirmed: the page image (Official Bulletin, Mar. 14, 1918, p. 6, viewed) dates the order 'March 2, 1918'. Lord (1944) gives Feb. 2, but places 2814 between 2813 (Feb. 26) and 2815 (Mar. 2; OCR prints '2816' twice), so Feb. 2 is out of sequence and is very likely a Lord error copied into the ledger. Status unaffected. The printed text carries no EO number; the number rests on the Lord title match (Treasury Annex)."],["Completion documented: Treasury Annex is in the Supervising Architect's list of buildings completed during FY1920 (WX-E23). The legal emergency-lapse ground also applies.",WAGE],[obimg(723,"Official Bulletin Mar. 14, 1918, p. 6, viewed: EO 2814 text signed 'March 2, 1918' and EO 2817 text signed '5 March, 1918'"),ev(PW+"ia_lord_v1.txt","2813:  Feb.  26","2817 : Mar.  5","Lord list sequence around 2814")])
rec("EO:2817","accept","no","no",["Small tension disclosed by producer: the same FY1920 report lists the New York assay office among contracts not complete on 1920-06-30 while the Mint section says the building 'has been completed' (report issued late 1920). Completion therefore falls c. mid/late 1920; immaterial."],["Completion documented (WX-E24). Text verified on page image (OB Mar. 14, 1918, p. 6).",WAGE],[obimg(723,"Official Bulletin Mar. 14, 1918, p. 6, viewed: EO 2817")])
rec("EO:2851","accept","no","no",[],["Completion documented: Boston quarantine-station additional construction completed March 1919 (WX-E21). Text verified on page image (OB Apr. 30, 1918, p. 7, viewed; whole order on p. 7, not pp. 7-8 as the producer's locator says). The legal emergency-lapse ground also applies.",WAGE],[obimg(1220,"Official Bulletin Apr. 30, 1918, p. 7, viewed: full EO 2851 signed April 27, 1918")])
rec("EO:2881","accept","no","no",[],["Repairs accomplished during FY1919 (WX-E22). Text verified on page image (OB June 22, 1918, p. 19, viewed); ledger 'construction' vs text 'repairs' conflict correctly logged.",WAGE],[obimg(1880,"Official Bulletin June 22, 1918, p. 19, viewed: EO 2865 (May 24, 1918) and EO 2881 (June 12, 1918)")])

# --- medium confidence
rec("EO:2718","accept_with_correction","no","no",
 ["Producer's ground (completion 'not documented'; 1962 contract absence inferred) does not support 'no' as written. Reviewer supplies completion evidence: the Commissioner General of Immigration's FY1920 report says the new Baltimore immigration station buildings had been in use by the Army as a general hospital and that 'the buildings and plant' would be returned to the Immigration Service on July 1, 1920; a Jan. 1919 account describes the station's 'three large brick buildings' as the nucleus of U.S.A. General Hospital No. 2; JAMA (June 26, 1920) reports the group 'was nearing completion' in 1917 and was turned over to the War Department. The construction project the order covers was therefore finished and occupied by 1918-1920."],
 [NEED1962,LEGAL,WAGE],
 [ev(R+"ia_cgi_ar1920.txt","The new immigration station at Baltimore, adjoining the Fort","preparations are under way for assuming custody of the","Annual Report of the Commissioner General of Immigration FY1920 (official)"),
  ev(R+"ia_paschj_191901.txt","At U. S. A. General Hospital No. 2, lo-","large brick buildings","Pennsylvania School Journal, Jan. 1919"),
  ev(R+"ia_jama_19200626.txt","The site was given to the","General Hospital No. 2 group.","JAMA June 26, 1920 (news item)"),APP(2718)]+EMERG)
rec("EO:2806","accept_with_correction","no","no",
 ["Producer's ground is inferential (completion of the court structure not documented; absence of a 1962 contract inferred). Reviewer found no completion record either (Treasury FY1918-FY1920 reports searched; archive.org full text: only the Bulletin itself). The record is closed only by the legal emergency-lapse ground: the order's own text says the early completion is for the Division of Loans and Currency 'engaged on work in connection with war measures, creating a national emergency'."],
 [NEED1962,LEGAL,"If the coordinator does not accept the emergency-lapse ground (7 Comp. Gen. 73) for orders without an express 'during the present emergency' term, this record must revert to indeterminate/indeterminate (hold: completion of the BEP court structure; source: Treasury/BEP FY1918-1919 reports or NARA RG 121/RG 56 files).","Text verified on page image (OB Feb. 16, 1918, p. 4, viewed; signed Feb. 13, 1918).",WAGE],
 [obimg(505,"Official Bulletin Feb. 16, 1918, p. 4, viewed: full EO 2806")]+EMERG)
rec("EO:2831","accept_with_correction","no","no",
 ["OCR join checked against the page image: the Official Bulletin, Apr. 5, 1918, p. 4 prints the order in the middle column, ending '... I do hereby suspend the provisions of law prohibiting', and continues it below a rule at the foot of the right-hand column on the same page ('more than eight hours of labor ... belonging to the Government in the block on the west side of Fourteenth Street NW., between D and E Streets ... Woodrow Wilson. The White House, April 1, 1918.'). The producer's join (WX-E11 + WX-E12) is correct and the text is complete.",
  "Producer's closure is inferential. Reviewer adds: (a) the legal emergency-lapse ground (the order's text ties the remodeling to Treasury 'work in connection with war measures creating a national emergency'); (b) supporting occupancy evidence: by 1924 the Graham Building at 14th and E Sts. housed the USDA Office of Foreign Seed and Plant Introduction, i.e. the building had passed out of the 1918 Treasury war use. (b) shows the building in ordinary use, not a dated completion of the remodeling."],
 [NEED1962,LEGAL,"If the emergency-lapse ground is not accepted, this record rests on occupancy-by-1924 only and should be treated as indeterminate (hold: completion of 1918 remodeling; source: Treasury FY1918-1919 reports or NARA RG 121).",WAGE],
 [obimg(969,"Official Bulletin Apr. 5, 1918, p. 4, viewed: EO 2831 in middle column with continuation at foot of right column"),
  ev(R+"ia_usda_whattosee1924.txt","The  Graham  Building,   14th  and  E  Sts .","INTRODUCTION  of  the  BUREAU  OF  PLMT  INDUSTRY,","USDA, 'What there is to see in the U.S. Dept. of Agriculture' (1924)")]+EMERG)
rec("EO:2841","accept_with_correction","no","no",
 ["Savannah part: completion is not only undocumented, there is counterevidence. The PHS report the producer cached as 'FY1920' (ia_phs_ar1920.txt) is in fact the FY1921 report (title page 'FOR THE FISCAL YEAR 1921'); it shows the Nov. 4, 1918 Savannah quarantine appropriation ($26,000, voted 'to provide for the completion of the work ... as originally planned') wholly unspent on June 30, 1921, and the Savannah station section reports only repairs and painting. So the planned Savannah buildings were not completed by mid-1921 and may never have been built as planned. The completion ground fails for Savannah.",
  "Cape Charles part: the producer's 'ended with transfer' is reasonable (the Fisherman's Island station was given up to the War Department and replaced by Craney Island, a different station), but the 'Cape Charles (act Nov. 4, 1918)' appropriation was still being spent in 1921 on the replacement, so this too is not a clean completion.",
  "The record is closed by the legal emergency-lapse ground: the order's text says the early completion 'in connection with war activities, constitutes a national emergency'."],
 [NEED1962,LEGAL,"If the emergency-lapse ground is not accepted, this record must revert to indeterminate (hold: Savannah quarantine buildings; source: PHS FY1922-1925 reports, Supervising Architect reports, NARA RG 90).","Text verified on page image (OB Apr. 23, 1918, p. 15, viewed; signed Apr. 18, 1918).",WAGE],
 [obimg(1164,"Official Bulletin Apr. 23, 1918, p. 15, viewed: full EO 2841"),
  ev(P+"ia_phs_ar1920.txt","FOR  THE  FISCAL  YEAR","1921","Producer-cached PHS report is FY1921, not FY1920"),
  ev(P+"ia_phs_ar1920.txt","Savannah,  Ga.    (act  Nov.  4,  1918) 26,000.00","Savannah,  Ga.    (act  Nov.  4,  1918) 26,000.00","PHS FY1921: Nov. 1918 Savannah quarantine appropriation unspent at June 30, 1921 (counterevidence to completion)"),
  ev(P+"ia_phs_ar1920.txt","Cape  Charles  (act  Nov.  4,  1918)  :","Balance  June  30,  1921 75,963.98","PHS FY1921: Cape Charles appropriation balance")]+EMERG)
rec("EO:2842","accept_with_correction","no","no",
 ["Producer's closure is inferential (completion 'not documented'). Reviewer found it: the D.C. Commissioners' FY1919 report (Water Department) says 'Work was completed on the extension of a 24-inch trunk water main in Twenty-first Street NW., southward from L Street ...' and lists the 24-inch mains in B Street, Twenty-first Street and E Street, the 20-inch main in Missouri Avenue, the 16-inch main in B Street and the 12-inch main between Seventh and Ninth Streets as 'laid and put into service' for the new Government buildings. Some segments named in the order (E St. to 19th, 16-inch B St. to 26th and 26th St., parts of Virginia/New York Avenues and 17th St.) are not separately listed; they were either not built or not reported, and in either case the order's own recital limits the funds to FY1919.",
  "Statutory basis: besides 40 U.S.C. 321-322, the D.C. eight-hour law (Act of Mar. 3, 1901, secs. 892-893, 31 Stat. 1334; D.C. Code 22-3407, 3408), which the order more likely invoked ('eight-hour law relating to the employment of laborers and mechanics in the District of Columbia'), was also repealed by sec. 203 of the 1962 Act. The producer should cite it; the result is the same under either statute.",
  "Ground (i) applies on the order's own text: the exception is declared 'an emergency measure relating to the conduct of the present war'."],
 [NEED1962,"The wage proviso (time and a half for overtime 'spent upon said construction') is limited to that construction; any accrued claim is a historical consequence and long time-barred.",LEGAL,"Text verified on page image (OB May 14, 1918, p. 15, viewed; signed Apr. 20, 1918)."],
 [obimg(1396,"Official Bulletin May 14, 1918, p. 15, viewed: full EO 2842"),
  ev(R+"ia_dc_1919_2.txt","Work was completed on the extension of a 24-inch trunk water main in","area affected.","Report of the Commissioners of D.C., FY1919, vol. 2, Water Dept. engineering division"),
  ev(R+"ia_dc_1919_2.txt","The following gravity trunk mains were laid and put into service.","above-mentioned territory.","Same report, Engineer Department"),LAW])
rec("EO:2855","accept_with_correction","no","no",
 ["Producer's ground is inferential (vault reconstruction completion not documented). Reviewer found no completion record (Treasury FY1918-FY1919 reports searched). Closed only by the legal emergency-lapse ground: the order's text says the vault is for Treasury activities 'in connection with war measures constituting a national emergency'."],
 [NEED1962,LEGAL,"If the emergency-lapse ground is not accepted, revert to indeterminate (hold: completion of vault No. 17; source: Treasury FY1918-1919 reports, NARA RG 56/121).","Text verified on page image (OB May 9, 1918, p. 8, viewed; signed May 4, 1918).",WAGE],
 [obimg(1333,"Official Bulletin May 9, 1918, p. 8, viewed: full EO 2855")]+EMERG)
rec("EO:2865","accept_with_correction","no","no",
 ["Producer's closure is inferential ('completion not documented'). Reviewer found it: the St. Elizabeths Hospital report in the Interior Department's FY1919 reports says the semipermanent buildings authorized Oct. 6, 1917 ('seven ward buildings, one dining hall, and kitchen building') 'were completed and are partly occupied'. This matches the order's object (ward buildings, dining hall, kitchen and appurtenances). Later Interior reports (1938-40, seen only as search snippets) describe the same group as due for replacement."],
 [NEED1962,LEGAL,"Text verified on page image (OB June 22, 1918, p. 19, viewed); the date reads 'May 24, 1918', resolving the producer's OCR 'May %!h'.",WAGE],
 [obimg(1880,"Official Bulletin June 22, 1918, p. 19, viewed: EO 2865 signed May 24, 1918"),
  ev(R+"ia_interior_1919.txt","Semipermanent  buildings. — The  semipermanent  buildings  which","partly  occupied.","Reports of the Department of the Interior FY1919, St. Elizabeths Hospital report, p. 780")]+EMERG)
rec("EO:2873","accept_with_correction","no","no",
 ["Producer's closure is inferential, and the counterevidence is stronger than disclosed: the PHS FY1921 report (producer's 'FY1920' file) says that at Stapleton a new laundry 'has been constructed', a new building for the power plant, kitchen and dining room 'is completed', and the new ice plant and elevators were 'nearing completion, but have not yet been accepted from the contractors'. So construction at Stapleton ran past mid-1921, and which of these were the 'proposed new structures' of May 1918 is not settled. The completion ground does not close this order.",
  "Closed only by the legal emergency-lapse ground: the order's text says the early completion 'in connection with war activities constitutes a national emergency'."],
 [NEED1962,LEGAL,"If the emergency-lapse ground is not accepted, revert to indeterminate (hold: completion of the 1918 Stapleton buildings; source: PHS FY1922-1923 reports, Supervising Architect reports).","Text verified on page image (OB June 6, 1918, p. 16, viewed; signed May 31, 1918).",WAGE],
 [obimg(1669,"Official Bulletin June 6, 1918, p. 16, viewed: full EO 2873"),
  ev(P+"ia_phs_ar1920.txt","a  7- foot  iron  fence.  A  new  laundry  has  been  constructed;","tractors.","PHS FY1921, Marine Hospital No. 21, Stapleton (counterevidence: work ongoing in 1921)")]+EMERG)

# --- holds
for iid,note in [("EO:2656","Only Lord title and Monthly Catalog summary exist in the record; the catalog says the 1912 Act, not the 1917 proviso, may be the authority."),
                 ("EO:2769","Only Lord title; 'certain ... construction' may be several projects."),
                 ("EO:2864","Only Lord title; Reclamation Service contracts may be program-wide. Reviewer's inside-text search of the Jan.-June 1918 Official Bulletin for 'Reclamation' found no order text.")]:
    rec(iid,"accept","indeterminate","indeterminate",
        ["No operative text; the hold is correct under TC15 and the producer protocol. Reviewer did not find text either."],
        [note,"If text is found and shows a suspension premised on the WWI emergency, the emergency-lapse ground above would very likely support no/no; not decided here."],[],
        {"text_complete":False,"refetched":False,"footprint_complete":False,"rule_predicates_met":None})

order={r['instrument_id']:r for r in recs}
ids=[json.loads(l)['instrument_id'] for l in open(B+"shards/S9_WWIX_A/status_proposals.jsonl")]
assert set(ids)==set(order), (set(ids)^set(order))
with open(B+"reviews/V9_WWIX_A_REV/reviews.jsonl","w") as f:
    for i in ids: f.write(json.dumps(order[i],ensure_ascii=False)+"\n")
from collections import Counter
print(Counter(r['verdict'] for r in recs))
