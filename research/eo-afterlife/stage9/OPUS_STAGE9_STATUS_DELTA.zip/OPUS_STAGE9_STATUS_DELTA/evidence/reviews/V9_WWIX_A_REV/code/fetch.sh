#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
set -u
SID="$1"; EXT="$2"; URL="$3"
D=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWIX_A_REV/cache
OUT="$D/$SID.$EXT"
UA="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
INFO=$(curl -sSL -A "$UA" --max-time 300 -o "$OUT" -w '%{http_code}\t%{content_type}\t%{url_effective}' "$URL")
CODE=$(echo "$INFO" | cut -f1); CT=$(echo "$INFO" | cut -f2); FU=$(echo "$INFO" | cut -f3)
SHA=$(sha256sum "$OUT" | cut -d' ' -f1); SZ=$(stat -c %s "$OUT")
python3 -I - "$D/$SID.meta.json" "$SID" "$URL" "$FU" "$TS" "$CODE" "$CT" "$SHA" "$SZ" <<'PY'
import json,sys
p,sid,url,fu,ts,code,ct,sha,sz=sys.argv[1:]
json.dump({"source_id":sid,"url":url,"final_url":fu,"retrieved_utc":ts,"http_status":int(code),"content_type":ct,"sha256":sha,"bytes":int(sz),"method":"curl original bytes","retrieved_by":"V9_WWIX_A_REV"},open(p,"w"),indent=1)
PY
echo "$SID $CODE $CT $SZ $SHA"
