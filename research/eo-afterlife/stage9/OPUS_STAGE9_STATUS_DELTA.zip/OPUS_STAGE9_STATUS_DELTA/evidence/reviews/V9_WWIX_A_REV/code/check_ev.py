import json, hashlib, sys, os
base = sys.argv[1]
def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()
res=[]
for l in open(os.path.join(base,'shards/S9_WWIX_A/evidence.jsonl')):
    d=json.loads(l)
    lf=os.path.join(base,d['local_file']); tf=d.get('text_file')
    if tf: tf=os.path.join(base,tf)
    else:
        tf=lf if lf.endswith('.txt') else os.path.splitext(lf)[0]+'.txt'
    ok_sha = os.path.exists(lf) and sha(lf)==d['local_file_sha256']
    tsha_ok = None
    if d.get('text_file_sha256'): tsha_ok = sha(tf)==d['text_file_sha256']
    txt=open(tf,encoding='utf-8',errors='replace').read() if os.path.exists(tf) else ''
    q_ok = d['quote'] in txt
    print(d['evidence_id'], 'sha', ok_sha, 'tsha', tsha_ok, 'quote', q_ok, len(d['quote']))
