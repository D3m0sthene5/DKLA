# V9_WWIX_A_REV: independent review of shard S9_WWIX_A

- Reviewer: V9_WWIX_A_REV. Codebook 2.0.0. Cutoff 2026-10-14 America/New_York.
- Actual UTC start: 2026-10-16T17:32:36Z. Actual UTC end: 2026-10-16T19:26Z. The work stopped for a usage-limit pause partway through and resumed at 19:22Z. Active work was about 40 minutes.
- Outputs:
  - `reviews.jsonl` (18 records, in the same order as `status_proposals.jsonl`).
  - `cache/`: original bytes, each with a `.meta.json` giving URL, real retrieval UTC and sha256.
  - `view/`: downscaled page images that I looked at.
  - `code/`.
  - `work/`: the archive.org scandata file, used to find page-image numbers.
- Disk: no PDFs were downloaded. The largest file is a 4.5 MB text file.

## Verdict counts

| verdict | n | IDs |
|---|---|---|
| accept | 10 | 2572, 2705, 2805, 2814, 2817, 2851, 2881 (no/no); 2656, 2769, 2864 (indeterminate holds) |
| accept_with_correction | 8 | 2718, 2806, 2831, 2841, 2842, 2855, 2865, 2873 (all eight "medium" no/no records) |
| reject_to_indeterminate | 0 | |
| reject_other | 0 | |

**Error rate** (non-accept / total) = 8/18 = **44%**.

All 8 corrections are the same problem. As the producer wrote them, the medium records do not support `no`. The `no` stands only because of evidence or a legal ground that I added.

**Sensitivity.** Four orders (2806, 2855, 2873, 2841) rest only on the legal "emergency lapse" ground below. If the coordinator does not accept that ground, those four become `reject_to_indeterminate`. So does 2831, which would then have only occupancy-by-1924 evidence. On that view: 5 reject_to_indeterminate, 3 accept_with_correction, error rate unchanged at 44%.

## The key question: is a "no 1962 contract" showing needed?

Yes, some showing is needed.

- The 1962 Act (Pub. L. 87-581 secs. 203-204, which I re-read) kept "the provisions of such statutes" for contracts existing on 1962-10-12. Those statutes include the sec. 326 suspension power.
- So an order still operative on that date could have carried on for a contract existing then.
- The showing can be made in two ways:
  - (a) Prove the order was no longer operative on 1962-10-12, by a fixed term, a completed project, or a legal end.
  - (b) Prove directly that no such contract existed.
- The producer offered neither for the 8 medium orders. It offered only that no source shows later work, plus "any 1962 contract was long performed (TC14)". That is inference, so the records as written fail.

I closed the eight myself on the grounds below.

1. **Completion found by me (strong):**
   - **2718** (Baltimore immigration station). The Commissioner General of Immigration's FY1920 report says the buildings were in Army hospital use and that "the buildings and plant" were to be returned on 1920-07-01. A January 1919 account and JAMA (June 1920) agree.
   - **2865** (St. Elizabeths semipermanent wards). The Interior Department's FY1919 report says the seven wards, dining hall and kitchen "were completed and are partly occupied".
   - **2842** (D.C. water mains). The D.C. Commissioners' FY1919 report says the 24-, 20-, 16- and 12-inch mains were "laid and put into service". A few listed segments are not mentioned. The order itself limits the funds to FY1919 and ties the work to "the conduct of the present war".
2. **Legal ground, which applies to all project orders under the 1917 proviso:**
   - The power exists only "in case of national emergency" (39 Stat. 1192).
   - Each medium order's own text says its emergency is the war-related need to finish the work.
   - The Comptroller General ruled in 1927 (7 Comp. Gen. 73, 76-77) that such a suspension "was conditioned upon the continuance of the national emergency which prompted" it. When that need passed, the authority "ceased to exist" and the eight-hour law came back "by operation of law".
   - So these suspensions ended long before 1962, and the savings clause could not carry them.
   - Limits:
     - Comptroller General rulings bind executive accounting officers, not courts.
     - The 1927 case was about EO 2554, whose operative clause itself says "present emergency conditions".
     - The exact end date of the emergency is not pinned for any order.
   - I accept the ground, but I record above that the stricter view would turn these orders back to indeterminate.
3. **Completion not available, and counterevidence found:**
   - **2841, Savannah part.** The $26,000 voted in November 1918 "for the completion of the work ... as originally planned" was wholly unspent on 1921-06-30.
   - **2873, Stapleton.** Construction (laundry, power-plant and kitchen building, ice plant, elevators) was still being finished or accepted in FY1921.
   - **2806 and 2855.** I found no completion record. The Treasury FY1918-1920 reports and archive.org full text turned up nothing.
   - These four depend on ground 2.

## The other two checks the coordinator asked for

- **EO 2831 OCR join.** I viewed the page image: Official Bulletin, 1918-04-05, p. 4. The order runs down the middle column to "I do hereby suspend the provisions of law prohibiting". It continues below a rule at the foot of the right-hand column on the same page and ends "Woodrow Wilson. The White House, April 1, 1918." The producer's join is correct and the text is complete.
- **EO 2814 date conflict.** The page image (Official Bulletin, 1918-03-14, p. 6) dates the order "March 2, 1918". Lord (1944) and the ledger say Feb. 2. But Lord lists 2814 between 2813 (Feb. 26) and 2815 (Mar. 2), so Feb. 2 is out of sequence and is very likely a Lord error. The status is not affected. The printed text carries no EO number; the number comes from matching the Lord title.

## What I checked

1. **Evidence fidelity.**
   - I re-hashed all 35 evidence records with python3 -I. All sha256 values match, and every quote is an exact substring of its text file.
   - Mislabel: `cache/ia_phs_ar1920.txt` is the PHS report for **FY1921**; its title page says "FOR THE FISCAL YEAR 1921". The SHARD_REPORT calls it FY1920. No producer evidence quotes it, but the attempts log and report do.
2. **Text re-fetch, done for all 15 `no` orders.**
   - APP 2572, 2705 and 2718 re-fetched: byte-identical to the producer's copies.
   - Official Bulletin page images re-fetched for the other 12 orders. I viewed the pages for 2806, 2814, 2817, 2831, 2841, 2842, 2851, 2855, 2865, 2873 and 2881. For 2805 I re-fetched the page bytes but did not look at them.
   - Every viewed text is complete and matches the OCR.
   - The 2865 date reads "May 24, 1918".
3. **Law.**
   - I re-read 39 Stat. 1192 and 76 Stat. 360 secs. 202-204.
   - Correction for 2842: sec. 203 also repealed the D.C. eight-hour law (Act of Mar. 3, 1901, secs. 892-893; D.C. Code 22-3407 and 22-3408). That law is probably the one the order excepted the work from. The result is the same.
4. **Later changes.** The Lord vol. 2 subject index has no revoking or amending entries.
   - Minor: the index's "Suspended for" list does not name 2814, 2831, 2842, 2855 or 2865, so the producer's WX-E26 statement that it "lists the packet orders" is too broad.
   - Disposition tables do not cover 1917-18.
5. **Shared rule S9WWIXA-R1.**
   - P1-P3 and P5 hold for each covered order on its own text.
   - P4 ("no source shows it under way") is not a valid predicate for the six project orders plus 2841. It should be replaced by "completion shown, or the emergency-lapse ground".
   - Stapleton and Savannah are counterexamples to the rule's completion premise.
6. **Holds (2656, 2769, 2864).** These are correct: there is no operative text. My search of the January-June 1918 Official Bulletin for "Reclamation" found no order text.

## Not verified

- The exact end date of the WWI emergency for each order.
- The six-year claim limit as it read in 1918.
- I did not view the 2805 page image.
- Graham Building occupancy by the USDA in 1924 comes from a USDA guide. It does not date when the 1918 remodeling was finished.
- The Interior Department's 1938-40 references to replacing the St. Elizabeths semipermanent buildings were seen only as search snippets.
