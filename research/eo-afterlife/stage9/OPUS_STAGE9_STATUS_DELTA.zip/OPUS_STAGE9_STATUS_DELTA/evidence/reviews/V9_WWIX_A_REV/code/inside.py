import json,sys,urllib.parse,subprocess
item=sys.argv[1]; srv=sys.argv[2]; path=sys.argv[3]; q=sys.argv[4]
u=f"https://{srv}/fulltext/inside.php?item_id={item}&doc={item}&path={path}&q="+urllib.parse.quote(q)
d=json.loads(subprocess.run(["curl","-sS","--max-time","60",u],capture_output=True).stdout)
for m in d.get("matches",[]):
    pages=sorted({p["page"] for p in m["par"]})
    print(pages, m["text"][:160].replace("\n"," "))
