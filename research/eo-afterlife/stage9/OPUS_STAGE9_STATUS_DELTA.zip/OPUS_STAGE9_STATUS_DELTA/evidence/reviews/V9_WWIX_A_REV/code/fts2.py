import json,sys,urllib.parse,subprocess
q=sys.argv[1]; lo=int(sys.argv[2]) if len(sys.argv)>2 else 1915; hi=int(sys.argv[3]) if len(sys.argv)>3 else 1935
for page in (1,2):
    u="https://archive.org/services/search/beta/page_production/?service_backend=fts&user_query="+urllib.parse.quote(q)+"&hits_per_page=50&page=%d"%page
    out=subprocess.run(["curl","-sS","--max-time","90",u],capture_output=True).stdout
    try: d=json.loads(out)
    except Exception: print("BADJSON",out[:150]); break
    b=d['response']['body']
    if not b: print("ERR",d['response'].get('errors')); break
    if page==1: print("total",b['hits'].get('total'))
    for h in b['hits']['hits']:
        f=h['fields']; hl=h.get('highlight') or {}
        y=f.get('year')
        try: y=int(str(y)[:4])
        except Exception: y=None
        if y is None or lo<=y<=hi:
            print(f.get('identifier'),'|',str(f.get('title'))[:70],'|',y,'|',' ## '.join(hl.get('text',[]))[:400].replace('\n',' '))
