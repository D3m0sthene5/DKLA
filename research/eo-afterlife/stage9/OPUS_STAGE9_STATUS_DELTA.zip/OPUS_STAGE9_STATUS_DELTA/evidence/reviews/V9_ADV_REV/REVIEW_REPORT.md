# V9_ADV_REV review of shard S9_ADV (advisory committee continuance orders)

Actual UTC start: 2026-10-16T17:03:54Z. Actual UTC end: 2026-10-16T17:20:23Z.

## What I reviewed, and when
- 11 records (11948, 12692, 12774, 13316, 13511, 13585, 13591, 13708, 13811, 14109, 14354) were reviewed from the files as they stood at 17:03-17:10Z.
- The 3 records that were still changing were reviewed last. I read EO 13138 at 17:11:35Z, EO 13385 at 17:13:09Z and EO 13652 at 17:13:50Z. In all three reads, status_proposals.jsonl had mtime 17:09:20Z. At 17:19:15Z and 17:20:23Z the file was still unchanged (sha256 6b302dd4...5b4c). At that point 13385 and 13652 were no/no (medium), and evidence.jsonl had 129 entries.
- I applied coordinator ruling CR-1 to 13138, 13385, 13652 and 13591 element by element (see reviews.jsonl). I do not dissent from CR-1. One limiting note: a FACA charter's termination sentence does not fix a presidential committee's term. It should corroborate the host clause or statute, not stand in for it.

## Counts by verdict (14)
- accept: 12 (11948, 12692, 12774, 13138, 13316, 13511, 13585, 13591, 13708, 13811, 14109, 14354)
- accept_with_correction: 2 (13385, 13652)
- reject_to_indeterminate: 0
- reject_other: 0
- Error rate (non-accept / total): 2/14 = 14.3%. No status was changed.

Reviewer statuses: yes/yes for 14354 and 13708; no/no for the other 12.

## Checks performed
- Evidence fidelity: I checked all 129 producer evidence quotes and found every one is an exact substring of its .txt file. Each txt sha256 matches its evidence record, and each meta sha256 matches the original bytes. No mismatches.
- Re-fetch: I fetched every order myself. 11 orders (1999 and later) came from govinfo FR HTML granules (official). 11948, 12692 and 12774 came from APP transcripts (hosted_transcript). I compared their operative provisions with the producer's text and they agree. APP misdates the 11948 signature as 1975; this does not affect anything. federalregister.gov full-text pages returned an "IP blocked / Request Access" page, so I switched to govinfo. The FR API returned intermittent 403s; retrying after a backoff with the default user agent worked (see attempts.log).
- Hosts and later instruments I verified myself:
  - EO 13596: rewrote all of EO 12131 sec. 1-102.
  - EO 14031 sec. 4(a): superseded EO 13515.
  - EO 14148 sec. 2: revoked 14031 and 14084. The 2026 notice that cites 14148 concerns only EO 14110.
  - EO 13646: created a new council and did not extend the EO 13530 council.
  - EO 13286 restated EO 13231. EO 13385 sec. 5 then struck NIAC's host sunset (3(d)(ii)) and kept only 3(c).
  - EO 13043 sec. 4: this is the text EO 13652 sec. 5 struck.
  - EO 14048: amends other EOs, not 12829.
  - Statute: 5 U.S.C. 1013, USCODE-2024, including sec. 1013(c).
- Later-change searches (FR API, all presidential documents through the retrieval date):
  - "14354" after 2025-10-01: only the order itself.
  - "12829" after 2015-10-06: EO 13764 (a cross-reference) and the continuance orders only.
  - "12367" after 2015-10-06: 0 results.
  - "12216" and "13231" after 2015-10-06: continuance orders up to 2023 only.
  - Committee names: NIAC (presidential, after 2025-01-01) 0; ILO committee (all documents, after 2024-01-01) 0.
  - "advisory committee" presidential documents after 2025-10-07: 8. None affects these records.
  - FR EO list for orders signed 2025-08-01..2026-10-14: 109 EOs. None continues or re-establishes ILO, NIAC or PCAH.
  - The Jan. 2026 international-organization withdrawal memo does not name the ILO.

## Systematic problems
1. **Overstated EO-list evidence.** Records 13385 and 13652 cite E_eo_list_2025_2026, saying "303 EOs ... titles reviewed". The cached file is page 1 only: 200 EOs signed 2025-01-03..2025-08-11. It does not reach EO 14354 or anything later. I closed the gap with my own list from Aug 2025 to Oct 2026.
2. **Stale rules.jsonl (TC16 mismatch).** The exception in rule ADV-R4 still says the ILO and NIAC committees fail its predicates, so they should be indeterminate. The proposals for 13385 and 13652 now rest on CR-1 instead. queue.jsonl also still lists both as blocked. The rules and queue files should be updated, or the records should cite CR-1 as their rule.
3. **Statute citation is incomplete.** The producer cites only 5 U.S.C. 1013(a)(2). The controlling text for continued committees is 1013(c): continuance is possible only by action taken before the committee would otherwise terminate. This text is also what satisfies CR-1 element 2.
4. **NIAC termination basis needs restating.** EO 13231 has had no sunset of its own since 2005. NIAC's end rests on the statute plus the EO 14109 date. The DHS charter is only corroboration.
5. **Spent partial repeal in a live host.** EO 13652 sec. 5 struck EO 13043 sec. 4, and EO 13043 is still unrevoked. Under the TC07 primary convention this is a spent partial repeal. It should carry a durable_disposition / alternate-convention flag.
6. **Minor footprint gap.** One paragraph in EO 13385 sec. 5 (the NS/EP paragraph) sits outside the quotation marks. It was re-enacted by 13652 and ends with NIAC either way.

## Sensitivity
13138, 13385 and 13652 each turn on CR-1. If integration adopts a stricter "dormant text" view, those three records become indeterminate/indeterminate.

## Files
- reviews.jsonl
- cache/ (original bytes, meta.json, txt)
- code/ (fetch.sh, fetch_noua.sh, h2t.py, app2t.py, check_ev.py, build_reviews.py)
- attempts.log
