import sys, html, re, hashlib, json
for p in sys.argv[1:]:
    raw = open(p,'rb').read().decode('utf-8','replace')
    m = re.search(r'<pre>(.*)</pre>', raw, re.S)
    t = re.sub(r'<[^>]+>','', m.group(1) if m else raw)
    t = html.unescape(t)
    out = p.rsplit('.',1)[0]+'.txt'
    open(out,'w').write(t)
    mp = p.rsplit('.',1)[0]+'.meta.json'
    d = json.load(open(mp)); d['extraction_method']='python3 -I regex strip of <pre> block + html.unescape (code/h2t.py)'; d['text_file_sha256']=hashlib.sha256(t.encode()).hexdigest()
    json.dump(d, open(mp,'w'), indent=1)
