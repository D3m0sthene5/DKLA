#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
id=$1; ext=$2; url=$3
out=cache/$id.$ext
hdr=$(mktemp)
code=$(curl -sSL -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36" -D "$hdr" -o "$out" -w '%{http_code}|%{url_effective}|%{content_type}' "$url")
ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
sha=$(sha256sum "$out" | cut -d' ' -f1)
IFS='|' read st fu ct <<< "$code"
cat > cache/$id.meta.json <<J
{"url":"$url","final_url":"$fu","retrieved_utc":"$ts","http_status":$st,"content_type":"$ct","sha256":"$sha","method":"curl original bytes","reviewer":"V9_ADV_REV"}
J
echo "$id $st $(stat -c%s $out) $sha"
rm -f "$hdr"
