import json, hashlib, os, sys
base = sys.argv[1]
ev = {}
bad = []
for l in open(os.path.join(base,'evidence.jsonl')):
    d = json.loads(l); ev[d['evidence_id']] = d
for eid, d in ev.items():
    lf = d['local_file']
    p = lf if os.path.isabs(lf) else os.path.join(base, lf)
    if not os.path.exists(p):
        bad.append((eid,'missing file',lf)); continue
    b = open(p,'rb').read()
    sha = hashlib.sha256(b).hexdigest()
    if sha != d['local_file_sha256']:
        bad.append((eid,'sha mismatch',lf))
    t = b.decode('utf-8','replace')
    if d['quote'] not in t:
        bad.append((eid,'quote not substring',lf, d['quote'][:80]))
print('evidence records', len(ev))
for x in bad: print(x)
# proposal evidence refs
for l in open(os.path.join(base,'status_proposals.jsonl')):
    p = json.loads(l)
    ids = set(p.get('evidence_ids',[]))|set(p.get('controlling_authority_evidence_ids',[]))
    for c in p['operative_footprint']: ids |= set(c.get('evidence_ids',[]))
    missing = [i for i in ids if i not in ev]
    print(p['instrument_id'], len(ids), 'missing refs:', missing)
