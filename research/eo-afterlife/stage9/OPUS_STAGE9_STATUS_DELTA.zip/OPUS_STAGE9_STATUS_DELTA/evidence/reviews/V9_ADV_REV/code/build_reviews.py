import json, hashlib, os, sys
B = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def ev(src, quote):
    txt = os.path.join(B,'cache',src+'.txt')
    t = open(txt,encoding='utf-8',errors='replace').read()
    assert quote in t, (src, quote)
    m = json.load(open(os.path.join(B,'cache',src+'.meta.json')))
    return {"local_file":"reviews/V9_ADV_REV/cache/%s.txt"%src,"sha256":hashlib.sha256(open(txt,'rb').read()).hexdigest(),
            "source_bytes_sha256":m['sha256'],"url":m['url'],"retrieved_utc":m['retrieved_utc'],"quote":quote}
CK = lambda fp=True: {"quotes_exact":True,"sha_match":True,"text_complete":True,"refetched":True,"footprint_complete":fp,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":True}
R = []
def add(i, verdict, s, a, problems, dissent, evs, ck=None):
    R.append({"instrument_id":i,"proposal_id":"opus:s9:status:"+i,"reviewer":"V9_ADV_REV","verdict":verdict,
              "reviewer_substantive_effect":s,"reviewer_any_operative_effect":a,"checks":ck or CK(),
              "problems":problems,"dissent_or_limiting_predicates":dissent,"reviewer_evidence":evs})
add("EO:11948","accept","no","no",
 ["None material. APP transcript (re-fetch) misdates the signature 'December 20, 1975'; FR 41 FR 55705 shows 1976. No effect on status."],
 "All clauses: sec.1 continuance to 1978-12-31 (superseded by EO 12110 sec.1-104, checked in producer FR 1979-01-03 text); sec.2 delegation tied to sec.1; secs 3-4 pure revocations/supersession (TC07). No amendment of any other EO.",
 [ev("app_eo11948","Each advisory committee listed below is hereby continued until December 31, 1978"),
  ev("app_eo11948","Executive Order No. 11827, as amended, is superseded.")])
add("EO:12692","accept","no","no",["None."],
 "Secs 1-2 ended 1991-09-30 and superseded by EO 12774 sec.4; sec.3 revocations and sec.4 supersession of EO 12610 spent (TC07). No amendment of another EO.",
 [ev("app_eo12692","Each advisory committee listed below is continued until September 30, 1991"),
  ev("app_eo12774","Sec. 4. Executive Order No. 12692 is superseded.")])
add("EO:12774","accept","no","no",["Supersession by EO 12869 rests on an APP transcript; own end date 1993-09-30 independently ends secs 1-2."],
 "Sec.3 revokes only (incl. sec.3-401 of EO 12661) - spent. No amendment of another EO.",
 [ev("app_eo12774","Each advisory committee listed below is continued until September 30, 1993."),
  ev("app_eo12774","Sec. 4. Executive Order No. 12692 is superseded.")])
add("EO:13138","accept","no","no",
 ["Rule linkage: the termination rule for continued committees is 5 U.S.C. 1013(a)(2) together with 1013(c) (continuance only by action taken before the committee would otherwise terminate); the producer cites only 1013(a)(2). Not outcome-changing.",
  "E12367_sunset comes from the NARA codification (historical, 1945-1989 text, page last reviewed 2016); it proves the host sunset clause, not current wording - correctly labeled historical by the producer."],
 "CR-1 applied to sec.7 (EO 12367, PCAH), host formally unrevoked: (1) operative rule: EO 12367 sec.4(b) 'shall terminate ... unless sooner extended' + last extension by EO 13708 to 2017-09-30 + 5 U.S.C. 1013(a)(2),(c) - MET (not inactivity; EO 13811, 13889, 14048, 14109, 14354 all omit 12367; FR presidential search '12367' since 2015-10-06 = 0). (2) revival needs new presidential act - MET (1013(c) bars post-expiry continuance; PCAH was in fact re-created by a new order, EO 14084, itself revoked by EO 14148). (3) no standing exercisable power in the 13138 sec.7 text (functions sentence; gift-funds-for-Committee-expenses sentence presuppose a live committee) - MET. (4) no extension through 2026-10-14 - MET (my FR searches + EO list Aug 2025-Oct 2026). Sec.6 (EO 13115 task force): own 6-month existence clause, extension power held only by Secretary of Transportation during existence; task force reported (FR 2000 notice); finite completed event - no. Secs 5, 8: host text displaced (EO 13316, EO 13596) / host revoked (EO 13265). No dissent from CR-1. Sensitivity: if integration adopts a stricter dormant-text convention, sec.7 flips this record to indeterminate.",
 [ev("gihtml_eo13138","Sec. 7. Executive Order 12367, as amended, is further"),
  ev("gihtml_eo13596","further amended to read as follows:"),
  ev("uscode_5_1013_htm","may be continued only for successive 2-year periods by appropriate action taken by the President or the officer prior to the date on which the advisory committee would otherwise terminate."),
  ev("gihtml_eo14148","(yy) Executive Order 14084 of September 30, 2022")])
add("EO:13316","accept","no","no",["None."],
 "Only amendment (sec.5, EO 12131 sec.1-102(a)) displaced by EO 13596 sec.1, which rewrote all of sec.1-102 ('further amended to read as follows'). Secs 3-4 spent.",
 [ev("gihtml_eo13316","Sec. 5. Section 1-102(a) of Executive Order 12131, as"),
  ev("gihtml_eo13596","Section1. Section 1-102 of Executive Order 12131 of May ")])
add("EO:13385","accept_with_correction","no","no",
 ["Evidence overstatement: E_eo_list_2025_2026 (frlist_eo_2025_2026_p1) is page 1 only - 200 of 303 EOs, signed 2025-01-03..2025-08-11; it does not even reach EO 14354, so the claim that all 303 titles were reviewed is not supported by the cached file. Reviewer closed the gap: FR API list of EOs signed 2025-08-01..2026-10-14 (109 EOs, last signed 2026-10-05) - none continues or re-establishes the ILO committee, NIAC or PCAH.",
  "rules.jsonl is stale and contradicts the proposal: ADV-R4 'exceptions' says the ILO/NIAC committees do NOT meet its predicates (one cycle only) -> indeterminate. The 'no' now rests on coordinator ruling CR-1, not ADV-R4 (TC16 rule/record mismatch).",
  "Footprint detail: in sec.5 the paragraph 'In implementing this order, the NIAC shall not advise ... NS/EP Communications' sits outside the closing quotation marks; EO 13652 sec.6 later re-enacted it inside the replacement sec.3, and NIAC ended 2025-09-30, so it ends either way.",
  "Rule citation: 5 U.S.C. 1013(c) should be cited alongside 1013(a)(2)."],
 "CR-1 for sec.7 (EO 12216 sec.1-101, ILO committee): (1) operative rule - MET without relying on inactivity: EO 12216 sec.1-402 'shall terminate ... unless this date is extended by further Executive order' (NARA codification), last extension EO 14109 sec.1(f) to 2025-09-30 (DOL 2023 FR charter-renewal notice confirms 'through September 30, 2025'), EO 14354 omits it; 1013(a)(2),(c). (2) revival needs a new EO - MET (1-402 text itself). (3) no standing power in the sec.7 text (membership list) - MET; the host's sec.1-302 power belongs to the Committee Chairman and lapses with the committee. (4) no extension through cutoff - MET (FR presidential searches '12216' since 2015-10-06 show only 13811/13889/14048/14109; all-document search for the committee name since 2024-01-01 = 0; EO lists Jan 2025-Oct 2026; Jan 2026 withdrawal memorandum does not mention the ILO). dol.gov unreachable for producer; not needed. Sec.6 (PCAH): same CR-1 analysis as EO 13138 - met. Sec.5: displaced by EO 13652 sec.6. Sec.8: host EO 13226 revoked by EO 13539. No dissent from CR-1.",
 [ev("gihtml_eo13385","Sec. 7. Executive Order 12216, as amended, is further"),
  ev("frlist_eo_20250801_20261014",'"count":109'),
  ev("frsrch_12216_PRESDOCU",'"count":4'),
  ev("frsrch_name_ilo_all",'"count":0'),
  ev("uscode_5_1013_htm","prior to the date on which the advisory committee would otherwise terminate.")],
 ck={"quotes_exact":True,"sha_match":True,"text_complete":True,"refetched":True,"footprint_complete":True,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":False})
add("EO:13511","accept","no","no",["None."],"Pure continuance; secs 1-2 superseded by EO 13585 sec.3; sec.3 spent. No amendment of another EO.",
 [ev("gihtml_eo13511","continued until September 30, 2011."),ev("gihtml_eo13585","Sec. 3. Sections 1 and 2 of Executive Order 13511 are ")])
add("EO:13585","accept","no","no",["None."],"Sec.4 amendment host EO 13515 superseded by EO 14031 sec.4(a) (2021); EO 14031 itself revoked by EO 14148 (2025). Secs 1-2 superseded by EO 13652 sec.3.",
 [ev("gihtml_eo14031","Islanders); Executive Order 13515 of October 14, 2009 "),ev("gihtml_eo13652","September 30, 2011, and sections 1, 2, and 4 of ")])
add("EO:13591","accept","no","no",["None."],
 "Sec.3 wrote a sunset into EO 13530 sec.6 ('Unless extended by the President, the Council shall terminate on January 29, 2013'); CR-1 elements met: operative rule = the text itself; revival needs presidential act; no standing power; no extension (FR notes for 13530 list only 'Amended by: EO 13591'; EO 13646 of 2013 created a new, different council and does not mention EO 13530).",
 [ev("gihtml_eo13591","on January 29, 2013.''"),ev("frapi_eo13530",'"executive_order_notes":"Amended by: EO 13591, November 23, 2011"')])
add("EO:13652","accept_with_correction","no","no",
 ["Same EO-list overstatement as EO 13385 (page 1 of 2 only); reviewer's own 2025-08..2026-10 list closes it.",
  "rules.jsonl ADV-R4 exception still says NIAC does not meet the predicates (stale; TC16 mismatch); the 'no' rests on CR-1.",
  "NIAC termination basis should be stated precisely: EO 13231 no longer has its own sunset - the restated sec.3(d)(ii) ('shall terminate on October 15, 2003, unless extended by the President', EO 13286) was struck by EO 13385 sec.5, which kept only subsection (c). The operative rule is 5 U.S.C. 1013(a)(2),(c) with the EO 14109 continuance date; the DHS charter sec.11 is corroboration (an agency charter cannot itself fix a presidential committee's term). CISA meeting-page evidence is a rendered capture and is not needed.",
  "Sec.5 strikes EO 13043 sec.4 (annual DOT seat-belt report) in a host that is still unrevoked; treated as a spent pure partial repeal under the TC07 primary convention - record a durable_disposition tag / alternate-convention sensitivity."],
 "CR-1 for sec.6 (EO 13231 sec.3, NIAC): (1) operative rule - MET via statute 1013(a)(2),(c) + EO 14109 sec.1 date 2025-09-30, corroborated by the 2023 DHS charter; (2) revival needs presidential act - MET (1013(c); charter 'unless extended by the President'; no surviving FACA delegation in EO 13231 after 2005); (3) no standing power in the amended text - MET (President's appointment/designation powers presuppose a live NIAC); (4) no extension through cutoff - MET (FR presidential search 'National Infrastructure Advisory Council' since 2025-01-01 = 0; '13231' since 2015-10-06 only continuance orders to 2023; EO lists). Secs 4, 7 (PMAB EO 13538, PGDC EO 13600): own 2-year sunsets, last extended by EO 13708 to 2017, omitted from EO 13811 onward - CR-1 met. Sec.8: host EO 13515 superseded 2021. No dissent from CR-1.",
 [ev("gihtml_eo13652","Sec. 6. Executive Order 13231 of October 16, 2001, as "),
  ev("gihtml_eo13385","is further amended by striking section 3, except "),
  ev("gihtml_eo13286","The NIAC shall terminate on October 15, 2003, unless extended by the "),
  ev("frsrch_name_niac",'"count":0'),
  ev("gihtml_eo13043","Sec. 4. Reporting Requirements. The Secretary of ")],
 ck={"quotes_exact":True,"sha_match":True,"text_complete":True,"refetched":True,"footprint_complete":True,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":False})
add("EO:13708","accept","yes","yes",["None. Producer correctly uses the NARA ISOO compilation only as pre-13708 contrast and the USCODE-2024 50 U.S.C. 3161 note as the current compilation."],
 "TC05/TC14: present actor NARA/Archivist; object NISPPAC (EO 12829 sec.103), continued by EO 14354 sec.1(d) to 2027-09-30; command = NARA support (103(c)(2)) and Archivist FACA functions (103(d)). Later-change check: FR presidential search '12829' after 2015-10-06 returns only EO 13764 (cross-reference in its EO 13467 amendment), and continuance orders 13811, 13889, 14048, 14109, 14354; EO 14048 amends other EOs (12382, 13265 etc.), not 12829. No rewrite of sec.103 after 2016 found. Residual gap: any EO signed 2026-10-06..10-14 not yet published (none indexed).",
 [ev("gihtml_eo13708","Sec. 4. Executive Order 12829 of January 6, 1993, is "),
  ev("frsrch_12829_after2015",'"count":6'),
  ev("gihtml_eo14354","Advisory Committee; Executive Order 12829, as amended ")])
add("EO:13811","accept","no","no",["None."],"Pure continuance (PCAH not listed - confirms PCAH omission from 2017); sec.3 supersession of EO 13708 secs 1-2 and revocation of EO 13805 spent; secs 1-2 superseded by EO 13889. No amendment of another EO.",
 [ev("gihtml_eo13811","continued until September 30, 2019."),ev("gihtml_eo13811","2017 (Establishing a Presidential Advisory Council on ")])
add("EO:14109","accept","no","no",["None."],"Sec.4 host EO 14031 and sec.5 host EO 14084 both revoked by EO 14148 sec.2 (verified in EO 14148 text); no reinstatement found (FR notes for 14031/14084; 2026 notice citing 14148 concerns EO 14110 only). Secs 1-2 superseded by EO 14354 sec.3.",
 [ev("gihtml_eo14148","(ii) Executive Order 14031 of May 28, 2021 "),ev("gihtml_eo14148","(yy) Executive Order 14084 of September 30, 2022 "),
  ev("gihtml_eo14354","Sec. 3. Sections 1 and 2 of Executive Order 14109 of ")])
add("EO:14354","accept","yes","yes",["None."],
 "Identity: EO 14354 of September 29, 2025, 90 FR 48145-48146 (FR Doc. 2025-19485, Oct. 6, 2025), effective Sept 30, 2025. TC05/TC14: 22 listed committees continued until 2027-09-30 with FACA functions delegated to agency heads (sec.2). Later-change check through cutoff: FR presidential search '14354' after 2025-10-01 returns only EO 14354; 'advisory committee' presidential docs after 2025-10-07 (8 docs) - none amends/supersedes it (July 2026 Bears Ears proclamation keeps its advisory committee); EO list Aug 2025-Oct 2026 shows no successor continuance order.",
 [ev("gihtml_eo14354","continued until September 30, 2027."),ev("gihtml_eo14354","Executive Order 14354 of September 29, 2025"),
  ev("frsrch_14354_after",'"count":1')])
with open(os.path.join(B,'reviews.jsonl'),'w') as f:
    for r in R: f.write(json.dumps(r, ensure_ascii=False)+'\n')
print(len(R))
