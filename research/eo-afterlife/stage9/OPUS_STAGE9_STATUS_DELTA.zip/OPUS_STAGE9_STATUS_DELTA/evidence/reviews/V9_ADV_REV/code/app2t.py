import sys, json, hashlib
from bs4 import BeautifulSoup
for p in sys.argv[1:]:
    s = BeautifulSoup(open(p,'rb').read(), 'html.parser')
    d = s.select_one('div.field-docs-content') or s
    t = d.get_text('\n')
    out = p.rsplit('.',1)[0]+'.txt'; open(out,'w').write(t)
    mp = p.rsplit('.',1)[0]+'.meta.json'
    m = json.load(open(mp)); m['extraction_method']='python3 -I bs4 div.field-docs-content get_text (code/app2t.py)'; m['text_file_sha256']=hashlib.sha256(t.encode()).hexdigest()
    json.dump(m, open(mp,'w'), indent=1)
