const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ headless: true, proxy: { server: process.env.HTTPS_PROXY } });
  const ctx = await b.newContext({ acceptDownloads: true });
  const p = await ctx.newPage();
  // visit landing page first
  await p.goto(process.argv[2], { waitUntil: 'domcontentloaded', timeout: 90000 }).catch(e=>console.error('goto1',e.message));
  await p.waitForTimeout(6000);
  const r = await ctx.request.get(process.argv[3]).catch(e=>{console.error('req',e.message);return null;});
  if (r) { console.log('status', r.status(), r.headers()['content-type']); require('fs').writeFileSync(process.argv[4], await r.body()); }
  await b.close();
})();
