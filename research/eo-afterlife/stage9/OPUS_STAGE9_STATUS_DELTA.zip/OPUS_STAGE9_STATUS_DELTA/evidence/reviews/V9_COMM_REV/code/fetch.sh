#!/bin/bash
# usage: fetch.sh <source_id> <ext> <url>
D=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_COMM_REV/cache
id=$1; ext=$2; url=$3
out=$D/$id.$ext
t=$(date -u +%Y-%m-%dT%H:%M:%SZ)
info=$(curl -sSL -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36" --max-time 180 -o "$out" -w '%{http_code}\t%{content_type}\t%{url_effective}' "$url")
code=$(echo "$info"|cut -f1); ct=$(echo "$info"|cut -f2); fu=$(echo "$info"|cut -f3)
sha=$(sha256sum "$out"|cut -d' ' -f1)
python3 -I -c "import json,sys; json.dump({'url':sys.argv[1],'final_url':sys.argv[2],'retrieved_utc':sys.argv[3],'http_status':int(sys.argv[4]),'content_type':sys.argv[5],'sha256':sys.argv[6],'method':'curl original bytes'},open(sys.argv[7],'w'),indent=1)" "$url" "$fu" "$t" "$code" "$ct" "$sha" "$D/$id.meta.json"
echo "$id $code $ct $(stat -c %s "$out") $sha"
