const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ headless: true, proxy: { server: process.env.HTTPS_PROXY } });
  const p = await (await b.newContext({userAgent:'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'})).newPage();
  const resp = await p.goto(process.argv[2], { waitUntil: 'networkidle', timeout: 90000 }).catch(e=>{console.error('goto',e.message);return null;});
  await p.waitForTimeout(8000);
  require('fs').writeFileSync(process.argv[3], await p.content());
  console.log('status', resp && resp.status(), (await p.innerText('body').catch(()=>'')).slice(0,1500));
  await b.close();
})();
