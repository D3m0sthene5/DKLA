import json, hashlib, os, sys
R = '/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_COMM_REV'
C = R + '/cache'

def ev(sid, quote, txtext='txt'):
    meta = json.load(open(f'{C}/{sid}.meta.json'))
    txt = f'{C}/{sid}.{txtext}'
    t = open(txt, encoding='utf-8', errors='replace').read()
    if quote not in t:
        sys.exit(f'QUOTE NOT FOUND in {sid}: {quote!r}')
    return {"local_file": txt, "sha256": hashlib.sha256(open(txt, 'rb').read()).hexdigest(),
            "original_bytes_sha256": meta['sha256'], "url": meta['url'],
            "retrieved_utc": meta['retrieved_utc'], "retrieval_method": meta.get('method'), "quote": quote}

ALLCHK = dict(quotes_exact=True, sha_match=True, text_complete=True, refetched=True,
              footprint_complete=True, law_checked=True, later_changes_checked=True)

def rec(iid, verdict, sub, anyf, checks, problems, dissent, evidence):
    c = dict(ALLCHK); c.update(checks)
    return {"instrument_id": iid, "proposal_id": f"opus:s9:status:{iid}", "reviewer": "V9_COMM_REV",
            "verdict": verdict, "reviewer_substantive_effect": sub, "reviewer_any_operative_effect": anyf,
            "checks": c, "problems": problems, "dissent_or_limiting_predicates": dissent,
            "reviewer_evidence": evidence}

out = []

out.append(rec("EO:10245", "accept", "no", "no", {"rule_predicates_met": True},
 ["No completion report under para. 5 located by producer or reviewer (APP searches May 1951-Dec 1953 return only the order, the July 4, 1951 address and the July 5 news conference). Formal self-termination is therefore unproved; first-cessation date/cause stays unknown."],
 "Identity secure: FR 16 FR 4675 heading, number and date match the ledger row. The order sets no date; its only end event is the Commission's own report (para. 5), which is undocumented. The 'no' on both axes rests on TC05/TC07: every clause (paras. 1-4) serves only the commemoration of the 175th anniversary (July 4, 1951, named in the preamble), which took place; no clause can have unexpired applicability now (the 2026 semiquincentennial is a different anniversary). Formal existence of a body with no performable function is treated as no present operative effect. Limiting predicate: a convention that counts bare formal existence (ex officio membership of current officeholders) as an effect would give any-effect=indeterminate. FACA sec. 14 was not relied on (composition wholly of federal officers; function operational, not advisory).",
 [ev("fr_1951-05-19", "report that fact to the President, and"),
  ev("app_eo10245", "3. It shall be the function of the Commission to plan and arrange for the appropriate commemoration, by ceremonies and otherwise, of the one hundred and seventy-fifth anniversary of the signing of the Declaration of Independence."),
  ev("app_eo10245", "WHEREAS the fourth day of July in this year One Thousand Nine Hundred and Fifty-one will mark the one hundred and seventy-fifth anniversary"),
  ev("nara_eo_1951", "Federal Register page and date: 16 FR 4675, May 19, 1951")]))

out.append(rec("EO:10887", "accept_with_correction", "no", "no", {"rule_predicates_met": None},
 ["Producer did not map the amending act cited in the order's own preamble ('72 Stat. 1703, as amended'): Pub. L. 86-250 (73 Stat. 486, Sept 9, 1959) rewrote Act sec. 3(3) so that federal buildings stand on land 'conveyed to the United States in fee simple' and are designed for 'governmental purposes and needs after the close of the exposition'. This confirms sec. 3's 'public building' status had a real federal object, so the 'no' DOES depend on proof that the buildings and grounds left federal ownership.",
  "That proof rested only on a third-party copy of the 2010 Seattle landmark nomination. Reviewer corroborated with the Pacific Science Center dedication plaque transcription (title passed Oct 26, 1974) and PacSci's own history page (title received in 1974 'on the condition that it must remain a science museum for the next 30 years'). Deed not retrieved.",
  "The 30-year use condition (to about 2004) is a deed covenant under the FPASA disposal required by Act sec. 6, not an effect of EO 10887; it has in any case run. Wikipedia's undated claim of a 2004 deed (citation needed) is read as the release of that condition; it does not affect the EO status."],
 "Sec. 3 status ended when title left the United States (Oct 26, 1974); secs. 1-2 have no object after the 1962 close, the sec. 5(b) report and the property disposal; sec. 4 is a spent supersession. Limiting predicate: if any building 'constructed pursuant to the act' were still federally owned, sec. 3 would be a continuing status (yes). Reviewer found no such building (plaque: 'these ... buildings and grounds formerly owned by the federal government').",
 [ev("fr_1960-09-27", "be a “public building” under the Public"),
  ev("stat_73_486", "sary for ingress and egress) conveyed to the United States in fee"),
  ev("plaque_pacsci", "On October 26, 1974, these magnificent buildings and grounds formerly owned by the federal government officially became the property of the Pacific Science Center Foundation"),
  ev("pacsci_history", "The Pacific Science Center Foundation receives the title to its buildings and grounds from the U.S. Government, on the condition that it must remain a science museum for the next 30 years."),
  ev("nara_eo_1960", "Supersedes: Letter of November 13, 1958 to the Secretary of Commerce")]))

out.append(rec("EO:11538", "accept_with_correction", "no", "no", {"rule_predicates_met": False},
 ["R-COMM-01 predicate (a) requires each clause to be limited 'by its own text' to a dated event; EO 11538's text names no date. The time bound comes from the controlling statute (sec. 709, 83 Stat. 317: 'not later than 1971', changed to 1972 by 84 Stat. 1204 sec. 609). Decide individually on the statutory window (TC16), not under R-COMM-01 as written.",
  "The Transpo 72 link is not needed: whatever exposition was held, sec. 709 authorizes only an exposition held not later than 1972, so the delegated authority has had no lawful object since Dec 31, 1972. Reviewer found DOT records (DOT-19071, Sept 8, 1971; FAA World May 1972) showing a DOT-run 'U.S. International Transportation Exposition' with daily military airshows at Dulles, consistent with but not expressly citing sec. 709.",
  "Post-exposition property passes to DoD and net revenues go to the Treasury by the statute itself, not by the order; no EO wind-up term exists. A govinfo STATUTE search for 'International Aeronautical Exposition' returned 0 later hits (besides producer's checks)."],
 "Limiting predicate: the 'no' assumes no contract under the delegation remains in administration; any such 1972 contract claim would be long time-barred, and the order has no explicit wind-up clause (contrast EO 12001 sec. 2).",
 [ev("fr_1970-07-01", "the establishment and conduct of an International Aeronautical"),
  ev("rosap_dot_83021", "Special Assistant for Development of the U.S. International Transportation"),
  ev("nara_eo_1970", "Federal Register page and date: 35 FR 10645; July 1, 1970")]))

out.append(rec("EO:11546", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "End condition in sec. 2(d) (terminate on submission of final report) is documented by the 1971 Nixon message and the April 26, 1971 briefing footnote (producer evidence re-checked). Only amendment is EO 11557 (NARA). Even if the report date were off, FACA sec. 14 (1972) would have ended an advisory commission with private members by 1975.",
 [ev("fr_1970-07-14", "later than April 30,1971. The Commission shall terminate on the date"),
  ev("nara_eo_1970", "EO 11557")]))

out.append(rec("EO:11557", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "Text re-fetched (35 FR 14375): sole operative content is a substitute sec. 1(b) of EO 11546; no independent clause (TC09). Host ended 1971.",
 [ev("fr_1970-09-12", "by substituting the following for subsection (b) of section 1"),
  ev("nara_eo_1970", "Amends: \nEO 11546")]))

out.append(rec("EO:11741", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "Sunset text verified in 38 FR 28809 and APP: 'Use of the symbol pursuant to this order shall continue through December 31, 1976.' The order only commands/permits federal agency use; it creates no symbol, ownership or protection. Symbol protection was statutory (Pub. L. 93-179 sec. 2(i), tied to ARBA certification; EO 12001 sec. 3(b) moved enforcement powers to Interior only until Dec 31, 1977). Reviewer searched the 2023 U.S. Code Title 36 and Title 18 ch. 33 (emblems, insignia, names): no American Revolution Bicentennial symbol provision (Title 36 'Bicentennial' hits concern Douglass and Lincoln commissions). Nothing keeps a symbol regime alive that is attributable to EO 11741.",
 [ev("fr_1973-10-17", "Sec. 3. Use o f the sym bol pursuant to this order shall continue through"),
  ev("app_eo11741", "SEC. 3. Use of the symbol pursuant to this order shall continue through December 31,1976."),
  ev("nara_eo_1973", "Federal agency use of the official American Revolution Bicentennial symbol")]))

out.append(rec("EO:11820", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "Delegation limited by its own text to 'the meeting of the International Council on Archives to be held in Washington, D.C. in 1976'. Meeting held Sept 27-Oct 1, 1976: Archivaria announcement (dates, sponsors) plus American Archivist vol. 41 no. 1 (1978) report 'Archival Revolution or Evolution: The 8th International Congress on Archives' and the Wellcome proceedings record. CRL record is CAPTCHA-walled (not bypassed).",
 [ev("fr_1974-11-29", "respect to the meeting of the International Council on Archives to be"),
  ev("archivaria_10441", "The Eighth International Congress on Archives, sponsored by the National"),
  ev("aa_41_1_p17", "Archival Revolution or Evolution: The 8th International Congress on Archives"),
  ev("nara_eo_1974-ford", "International Council on Archives-Bicentennial Year Meeting")]))

out.append(rec("EO:12001", "accept_with_correction", "no", "indeterminate", {"rule_predicates_met": None},
 ["Producer's finding 'No later statute found ending sec. 2' missed directly relevant later law: Pub. L. 99-500 (Oct 18, 1986), Interior/NPS appropriations, directed the Secretary of the Interior to 'begin processing claims of the licensees of the American Revolution Bicentennial Administration' (claims filed 1979-1985; Amerecord test case settled Aug 20, 1983) and to finish within one year. This shows ARBA contracts (licenses) were still being administered after Dec 31, 1983, so the alternative reading that the 87 Stat. 701 sec. 7(b) bound ('until December 31, 1983') closed sec. 2 is not supported; any-effect indeterminate is the correct result.",
  "The 1986 proviso is aimed at possible congressional equitable compensation; it does not itself show closure of all ARBA contracts and grants."],
 "Substantive 'no' is defensible under TC03: secs. 1 and 3(a),(c) end Dec 31, 1983 and 3(b) Dec 31, 1977 by express terms (verified in 42 FR 33709); secs. 4-7 are spent transfers/revocation (TC07). Sec. 2 ('administer existing contracts and grants of ARBA') is a wind-up term over a closed 1977 set, i.e. residual, not substantive; unknown residual may coexist with substantive=no. Any-effect stays indeterminate (codebook: residual terms with no proved surviving subjects -> indeterminate). Settle with Interior/NPS closeout records or a later statute/GAO decision closing the ARBA licensee claims.",
 [ev("fr_1977-07-01", "S e c . 2. The Secretary shall administer existing contracts and grants of the"),
  ev("app_eo12001", "exercise the following powers under the Act which are hereby transferred to him for such purposes until December 31, 1983, except as otherwise provided in subsection (b) of this Section:"),
  ev("stat_100_1783", "terior shall begin processing claims of the licensees of the American"),
  ev("stat_100_1783", "processed to completion in a judicious and expedient manner not to"),
  ev("nara_eo_1977-carter", "Transferring certain Bicentennial functions to the Secretary of the Interior")]))

out.append(rec("EO:13136", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "Verified in 66 FR 50291-92: EO 13225 sec. 3(c) revokes 'Executive Order 13090, as amended by Executive Order 13136' among orders establishing committees 'that have terminated and whose work is completed'; sec. 5 'This order shall be effective September 30, 2001.' EO 13136 (64 FR 48931) only changes the 13090 sec. 2(c) date (March 1, 1999 -> December 31, 2000); its purpose clause ('extend the life of the ... Commission') is non-operative. NARA 1998 table: 13090 amended only by 13136, revoked by 13225. No revival (TC11).",
 [ev("fr_1999-09-08", "that section 2(c) of Executive Order 13090 is amended by deleting ‘‘March"),
  ev("fr_eo13225", "(c) Executive Order 13090, as amended by Executive Order 13136, estab-"),
  ev("fr_eo13225", "Sec. 5. This order shall be effective September 30, 2001."),
  ev("fr_eo13090", "(d) The Commission shall terminate 60 days after the submission of its")]))

out.append(rec("EO:22", "accept", "no", "no", {"rule_predicates_met": True},
 [],
 "Completeness checked against an independent transcription of Richardson, Messages and Papers vol. 8 (Project Gutenberg #12754): preamble, single operative paragraph, 'Done at ... 9th day of April, 1884' and Frelinghuysen attestation all match APP. Later orders (July 8, 10, 16, 1884) also re-fetched; all concern finite 1884-85 expositions.",
 [ev("gutenberg_12754", "to be held in the city of New Orleans, commencing December 1, 1884,"),
  ev("gutenberg_12754", "Done at the city of Washington, this 9th day of April, 1884, and of the"),
  ev("app_eo317", "the provisions of which order being hereby extended to embrace said Cincinnati and Louisville expositions.")]))

out.append(rec("EO:23", "accept", "no", "no", {"rule_predicates_met": True},
 ["APP slug 'executive-order-311' is APP's internal numbering; identity with Lord EO 23 is secure: Richardson vol. 8 prints this text immediately after EO 22, dated May 13, 1884, with the De Caindry designation, matching the ledger title and date. Minor transcription variant: 'London A. Smith' (Gutenberg) vs 'Lyndon A. Smith' (APP); immaterial."],
 "Complete text (organizing direction plus secretary designation, dated and attested) matches between APP and Gutenberg/Richardson. One-time organizing act and appointment for a board whose duties ended with the 1884-85 expositions (TC07).",
 [ev("gutenberg_12754", "I also designate W.A. De Caindry as the secretary of said board."),
  ev("gutenberg_12754", "Done at the city of Washington, this 13th day of May, 1884, and of the")]))

out.append(rec("EO:26", "accept_with_correction", "no", "no", {"rule_predicates_met": False},
 ["R-COMM-01 predicate (b) ('where a dated event is named, it took place') is not shown for EO 26: neither producer nor reviewer documented that the October 1887 encampment was held. The rule should not be applied as written; decide individually.",
  "Individually the result holds without the event: the permission covers only visitors 'satisfied ... [to] come as guests, in pursuance of the aforesaid invitation' to an encampment 'to be held in Chicago in October proximo' (1887). That class closed in 1887 whether or not the event occurred; the reexportation formality attaches only to goods so admitted."],
 "Identity secure: APP slug 'executive-order-269' text matches Richardson (Gutenberg #15863, Cleveland first term) dated 'EXECUTIVE MANSION, Washington, August 25, 1887', matching ledger title/date. Text complete (Richardson prints no attestation beyond Cleveland's signature).",
 [ev("gutenberg_15863", "Encampment to be held in Chicago in October proximo, in commemoration of"),
  ev("gutenberg_15863", "such visitors come as guests, in pursuance of the aforesaid invitation,")]))

out.append(rec("EO:3665", "accept", "indeterminate", "indeterminate",
 {"text_complete": False, "refetched": False, "footprint_complete": False, "law_checked": False, "later_changes_checked": False, "quotes_exact": True, "sha_match": True, "rule_predicates_met": None},
 ["Reviewer's added ladder attempts also failed: CDNC newspaper search (Cloudflare 403 challenge), chroniclingamerica.loc.gov OCR endpoints (308 to www.loc.gov, Cloudflare challenge), tile.loc.gov storage paths (403/404 without batch ids), Google Books API (429 daily quota exhausted), archive.org advancedsearch for 1922 executive-order and Civil Service Commission report volumes (no US 1922 hits), WebSearch (only the Monthly Catalog index entry). No CAPTCHA bypassed."],
 "Hold is correct: only an index summary exists; it cannot support 'no' (gate 2, TC15). Neighbouring-number check (APP: EO 3714 dated Aug 1, 1922) shows no numbering anomaly.",
 []))

out.append(rec("EO:7700", "accept", "no", "no", {"rule_predicates_met": True},
 ["Ledger citation 'II Fed. Reg. 1799' is wrong; the order is at 2 FR 2103 (Sept 3, 1937). NARA's 1937 table assigns 7700 to the tax-return inspection order (2 FR 2215) and has no entry for the excusal order. Producer logged both in conflicts.jsonl."],
 "Gate 1 identity secure: the FR document reviewed carries the ledger title (excusing federal employees on Sept 17, 1937, 150th anniversary of the Constitution), the ledger date (THE WHITE HOUSE, August 31, 1937) and the printed number '[No. 7700]' (OCR '77003'). The NARA/APP 7700 vs 7700-A split concerns the other order's number, not the identity of this text. Both clauses operate only on Sept 17, 1937 (TC07).",
 [ev("fr_1937-09-03", "[No. 77003"),
  ev("fr_1937-09-03", "August 31. 1937."),
  ev("fr_1937-09-03", "   1. On Friday, September 17, 1937, the one hundred fiftieth"),
  ev("nara_eo_1937", "Inspection of Income, Profit, and Capital Stock Tax Returns by the Committee on Interstate Commerce, U.S. Senate")]))

with open(R + '/reviews.jsonl', 'w') as f:
    for r in out:
        f.write(json.dumps(r, ensure_ascii=False) + '\n')
from collections import Counter
print(len(out), Counter(r['verdict'] for r in out))
