# V9_COMM_REV review of shard S9_COMM (14 commemoration/exposition orders)

- Reviewer UTC start: 2026-10-16T17:06:55Z
- Reviewer UTC end: 2026-10-16T17:22:08Z
- Inputs: REVIEWER_PROTOCOL.md, PRODUCER_PROTOCOL.md (including the standing rule on blocked sources), CODEBOOK_2.0.0_UNCHANGED.json, shards/S9_COMM/*
- Outputs: reviews.jsonl (14 records), cache/ (original bytes plus meta.json for every reviewer fetch), code/ (fetch.sh, evcheck.py, build_reviews.py, page.js, dl.js)

## Verdicts

| verdict | n | IDs |
|---|---|---|
| accept | 10 | EO:10245, EO:11546, EO:11557, EO:11741, EO:11820, EO:13136, EO:22, EO:23, EO:3665, EO:7700 |
| accept_with_correction | 4 | EO:10887, EO:11538, EO:12001, EO:26 |
| reject_to_indeterminate | 0 | |
| reject_other | 0 | |

Error rate as the protocol defines it (any verdict other than plain `accept`, divided by the total): 4/14 = 28.6%. Status errors (`reject_*`): 0/14 = 0%. In all 14 records I reached the same substantive and any-effect statuses as the producer.

## Checks done
- Evidence fidelity: I checked all 83 producer evidence records with python3 -I. Every quote is an exact substring of its .txt file, every .txt and original-bytes sha256 matches its record, and every cache meta sha256 matches its file. No mismatches.
- Re-fetch: I downloaded these again myself:
  - Federal Register issues from govinfo: 1937-09-03, 1951-05-19, 1960-09-27, 1970-07-01, 1970-07-14, 1970-09-12, 1973-10-17, 1974-11-29, 1977-07-01 and 1999-09-08, plus the EO 13090 and EO 13225 documents.
  - The APP pages for all 13 orders that have text, plus the July 1884 follow-on orders.
  - The NARA disposition tables for 1937, 1951, 1960, 1970, 1973, 1974-ford, 1975, 1977-carter and 1998.
  - For EO 22, 23 and 26, the Project Gutenberg transcriptions of Richardson's Messages and Papers (#12754 Arthur, #15863 Cleveland first term). These are an independent copy of the same source that APP transcribes.
  - In every case the operative provisions match the producer's text.
- Gate 1 (identity):
  - EO 7700: the FR document carries the ledger title, the ledger date (Aug 31, 1937) and the printed number "[No. 7700]". NARA and APP give the 7700 / 7700-A split to the tax-return inspection order, so it does not affect which text this is. The ledger cite "II Fed. Reg. 1799" is wrong; the producer already logged that conflict.
  - EO 23 and EO 26: APP slugs 311 and 269 are APP-internal numbers. Richardson has the same texts, dated May 13, 1884 and Aug 25, 1887, and those dates match the ledger.
  - Identity is secure for all 13 orders with text.

## Key findings by focus item
- (a) Identity: secure (see above). No identity-based rejection needed.
- (b) EO 10245: the order sets no date. It ends only on the Commission's own completion report (para. 5), and no such report was found. I accept no/no on TC05/TC07, because every clause serves only the July 4, 1951 commemoration, which took place. This is a stated limiting predicate: a convention that counts bare formal existence as an effect would give any-effect=indeterminate.
- (b) EO 10887: the producer missed Pub. L. 86-250 (73 Stat. 486). That act required the federal land to be conveyed to the United States in fee simple, and the buildings to be designed for government use after the exposition. So the sec. 3 "public building" status was real, and the 'no' does depend on the 1974 conveyance. I corroborated the conveyance from two further sources: the PacSci dedication plaque (Oct 26, 1974) and PacSci's own history page, which mentions a 30-year science-museum use condition. That condition is a covenant in the property-disposal deed, not an effect of the order, and it has run.
- (b) EO 11538: R-COMM-01 predicate (a) fails on the order's own text. The date bound is in sec. 709 of the statute, not in the order. The 'no' does not need the Transpo 72 link: sec. 709 authorizes only an exposition held by 1972, so the authority has had no lawful object since then. DOT press releases I retrieved (via Chromium after a curl 403) are consistent with that link but do not cite sec. 709.
- (c) EO 11741: sunset text verified in 38 FR 28809. The order only directs agency use of the symbol. Symbol protection was statutory: Pub. L. 93-179 sec. 2(i), with Interior enforcement only until Dec 31, 1977. The 2023 U.S. Code Title 36 and Title 18 ch. 33 contain no American Revolution Bicentennial symbol provision.
- (d) EO 13136: verified. EO 13225 sec. 3(c) revokes "Executive Order 13090, as amended by Executive Order 13136", and sec. 5 makes it effective Sept 30, 2001.
- (e) EO 12001: I accept no/indeterminate, with a correction. Pub. L. 99-500 (1986, Interior/NPS appropriations) directed Interior to process the claims of ARBA licensees within one year. So ARBA contracts were still being administered after the statute's Dec 31, 1983 bound. That defeats the alternative reading that sec. 7(b) closed sec. 2, which would have made any-effect 'no'. Substantive 'no' is defensible under TC03: sec. 2 is a wind-up of a closed set of 1977 contracts and grants (a residual term), and every substantive clause has an express end date.
- (f) EO 22, 23 and 26: the APP texts are complete when compared with Richardson. For EO 26, R-COMM-01 predicate (b) is not shown, because the 1887 encampment is not documented as held. The 'no' still holds on the order's own scope: guests coming under the 1887 invitation form a closed class.

## Systematic problems
1. The shared rule R-COMM-01 was applied to orders that fail its own predicates as written (TC16): EO 11538 (no date in the order's own text) and EO 26 (event not shown to have occurred). Narrow the rule, or decide these two individually.
2. Searches for later changes relied on NARA tables and targeted Statutes at Large pages. They missed two relevant statutes: the amending act named in EO 10887's own preamble (Pub. L. 86-250), and later appropriations riders (Pub. L. 99-500 for ARBA). A full-text search of govinfo STATUTE (api.govinfo.gov search) finds both.
3. EO 10887 depended on one third-party copy of a secondary source.

## Retrieval ladder log (reviewer)
- govinfo HTML guess for EO 13136 (FR-1999-09-08/html/99-23565.htm): page not found. I used the full issue PDF instead.
- NARA 1999-clinton and 2001-bush table slugs: 404. These tables were not needed; the 1998 table carries the 13090 disposition.
- govinfo API (DEMO_KEY): 429 rate limit once, then succeeded after a wait.
- UNT catalog: JavaScript bot check, not pursued.
- rosap.ntl.bts.gov PDFs: curl 403 and WebFetch ENOTFOUND. Headless Chromium then fetched them (200, original PDF bytes).
- CRL catalog: CAPTCHA, not bypassed. American Archivist: page rendered in Chromium; PDF download returned HTML.
- Project Gutenberg: connection reset twice, then succeeded after retries.
- EO 3665: CDNC (Cloudflare 403); chroniclingamerica OCR (308 to www.loc.gov, then Cloudflare challenge); tile.loc.gov (403/404); Google Books API (429, daily quota); archive.org advancedsearch (no relevant 1922 volumes); WebSearch (index entry only). The hold stands.
