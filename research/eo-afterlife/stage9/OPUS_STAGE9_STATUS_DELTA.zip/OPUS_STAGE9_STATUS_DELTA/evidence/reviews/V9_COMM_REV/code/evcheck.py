import json,hashlib,os,sys
base=sys.argv[1]
res=[]
for l in open(os.path.join(base,'evidence.jsonl')):
    e=json.loads(l)
    lf=e['local_file']
    p=lf if os.path.isabs(lf) else os.path.join(base,lf)
    if not os.path.exists(p):
        alt=os.path.join(base,'..','..',lf)
        p=alt if os.path.exists(alt) else p
    ok=os.path.exists(p)
    sha=hashlib.sha256(open(p,'rb').read()).hexdigest() if ok else None
    txtp=p
    if ok and not p.endswith('.txt'):
        txtp=os.path.splitext(p)[0]+'.txt'
    txt=open(txtp,encoding='utf-8',errors='replace').read() if os.path.exists(txtp) else ''
    q=e['quote']
    res.append((e['evidence_id'],ok,sha==e.get('local_file_sha256'),q in txt,lf,e.get('evidence_grade')))
bad=[r for r in res if not (r[1] and r[2] and r[3])]
print(len(res),'records; bad:',len(bad))
for r in bad: print(r)
