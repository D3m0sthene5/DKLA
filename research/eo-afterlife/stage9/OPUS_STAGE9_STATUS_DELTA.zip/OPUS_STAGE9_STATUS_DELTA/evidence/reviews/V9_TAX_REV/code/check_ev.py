import json,hashlib,os,sys
base=sys.argv[1]
os.chdir(base)
bad=[]
for l in open('evidence.jsonl'):
    e=json.loads(l)
    lf=e['local_file']
    p=lf if os.path.isabs(lf) else os.path.join(base,lf)
    if not os.path.exists(p):
        alt=os.path.join(base,'cache',os.path.basename(lf))
        p=alt if os.path.exists(alt) else p
    if not os.path.exists(p):
        bad.append((e['evidence_id'],'missing',lf)); continue
    b=open(p,'rb').read()
    sha=hashlib.sha256(b).hexdigest()
    shaok = sha==e['local_file_sha256']
    txt=b.decode('utf-8','replace')
    qok = e['quote'] in txt
    print(e['evidence_id'],os.path.basename(p),'sha',shaok,'quote',qok,e['evidence_grade'],'|',e['supports'][:80])
    if not (shaok and qok): bad.append((e['evidence_id'],shaok,qok))
print('BAD',bad)
