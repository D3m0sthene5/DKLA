# V9_TAX_REV review of shard S9_TAX

- Reviewer: V9_TAX_REV (independent; did not produce the shard). Codebook 2.0.0, cutoff 2026-10-14.
- Actual UTC start: 2026-10-16T16:59:03Z. Actual UTC end: 2026-10-16T17:10:26Z.
- Outputs: reviews.jsonl (14 records), cache/ (original bytes + meta.json + .txt), code/, attempts.log.

## Counts by verdict
- accept: 14 (8 no/no, 6 indeterminate/indeterminate)
- accept_with_correction: 0; reject_to_indeterminate: 0; reject_other: 0
- Error rate (non-accept / total): 0/14 = 0%.
- Ownership: all records remain OWNERSHIP_NOT_VERIFIED; the review does not promote them.

## Gate 1: evidence fidelity
All 62 producer evidence records checked with python3 -I: the original-byte sha256 matches for 62/62, the text_sha256 matches for 62/62, and each quote is an exact substring of its text_file for 62/62. Note that quotes are substrings of the .txt extraction, not of the PDF or HTML bytes in local_file. This follows the protocol, but a check against local_file alone gives false negatives.

## Gate 2: re-fetch (mandatory for the 8 'no' orders)
- I re-fetched FR daily issues 1942-12-12, 1953-05-26, 1954-10-02, 1962-05-09, 1973-05-21, 1974-06-11 and 1976-01-23 from govinfo. All seven are byte-identical to the producer's copies (same sha256). I read the operative text of 9281, 10455, 10566, 11020, 11720, 11786 and 11900 directly from my own pdftotext output.
- I re-fetched EO 6342 from APP; it is pre-Federal Register. The text matches. The page bytes differ because the page is dynamic.
- I also re-fetched TRA 1976 (90 Stat. 1520; byte-identical), the current 26 CFR 301.6103(a)-1 (eCFR versioner API), 26 U.S.C. 6103, 5 U.S.C. 551 and 26 U.S.C. 7851 (Cornell LII), the NARA legislative guides (Senate ch. 18, House ch. 14), and 62 NARA EO disposition tables for 1937-2005.

## Focus findings
(a) End clauses. The own-text Congress limit is confirmed for 10455 ("during the Eighty-third Congress"), 11020 (87th), 11720 (93d) and 11900 (94th). EO 10566 operates only inside 10455. EO 6342 and EO 9281 have no Congress clause. They end because their named recipient ceased (and, for 9281, because its purpose was tied to H.Res. 420 of the 77th Congress). EO 11786 has no Congress or committee limit; it ends by TRA 1976.

(b) 1939-Code counterexample. Several 'no' orders do reach 1939-Code or earlier returns: 6342 (Revenue Acts 1926-1932), 9281 (1932+, incl. 1939 Code), 10455/10566 (to 1952/1953), 11020 (1946-1962) and 11720 (1939-1974). In every one of these, the order's own Congress limit or the end of its recipient closes it, whatever Code governs the returns. EO 11786 covers only Nixon's 1969-1972 returns, which are 1954-Code returns, under 1954 Code 6103(a)/6106. EO 11900 covers only 1955-1975 returns. So no 'no' order depends on TRA 1976 for 1939-Code returns. The producer's counterexample (7851(a)(6)(A)) is correctly quoted.

(c) TRA 1976 sec. 1202 was read in full. (a)(1) rewrites 6103 "to read as follows"; (h)(1) repeals 6106; (i) makes the changes effective Jan 1, 1977. There is no savings or transition clause. 301.6103(a)-1 reaches only disclosures "to an officer or employee of a Federal agency (as defined in section 6103(b)(9))". Under 6103(b)(9), that is 5 U.S.C. 551(1), which "does not include (A) the Congress". Committees therefore get no residual.

(d) TC09. EO 10566 strikes "1952" and inserts "1953" in EO 10455. The host contains "1952" only once, in the return-period clause. The mapping is correct.

(e) Later EOs. My APP citation searches ("Order No. N" / "Executive Order N") found only 10566 (cites 10455) and 9444 (cites 9281). The 62 NARA tables show the shard's orders only in their own year's table, plus cross-references for 9281 (EO 8131 in 1939, EO 9444 in 1944). EO 12553 (1986, a bulk revocation of obsolete orders) does not list any shard order.

## Systematic problems / residual gaps (none change a status)
1. The NARA disposition pages for 1953-eisenhower and 1962 return a genuine 404. I worked through the full ladder: curl in several URL forms, Playwright (a real 404), Wayback CDX (connection reset), WebFetch (cannot reach web.archive.org), archive.org availability (no snapshots), archive.ph (429, not pursued) and federalregister.gov (CAPTCHA page; API 403 IP block). Mitigation: the APP searches, and the absence of 10455 and 11020 from every later table I could reach. Other missing tables (1979, 1980, 1982, 1984, 1987, 1989, and others) could only hold cleanup revocations (TC13). Those would not change any status.
2. Committee-end dates rest on NARA archival descriptions (year only) and on House practice (a resolution lapses with its Congress). Neither party retrieved S.Res. 78, H.Res. 420 or H.Res. 803. For EO 9281, the first cessation is better dated Jan 3, 1943 than the producer's '1945' (a latest bound). The pattern of one new EO per resolution supports this.
3. EO 11900: TRA (Jan 1, 1977) precedes the order's own term end (Jan 3, 1977). The first cause is therefore statutory intervention, although the order is filed under RULE-TAX-CONGRESS-TERM. This matters only for any time-vs-intervention headline coding.
4. Indeterminate orders: I agree that the 1939 Code sec. 55 continuity question is a real blocker. New 6103(b)(1) defines "return" by reference to "this title", which cuts both ways. I did not attempt an upgrade (gates 1-6 not completed for 'no'). EO 10076: my WebSearch also found no source for the end of the MRPRB.

## Attempts log
See attempts.log (every curl, Playwright and archive attempt, with UTC time and result).
