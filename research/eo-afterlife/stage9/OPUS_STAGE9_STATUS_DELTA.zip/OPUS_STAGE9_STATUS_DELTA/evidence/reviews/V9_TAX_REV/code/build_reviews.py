import json,hashlib,os,sys
R=sys.argv[1]; os.chdir(R)
def meta(txt):
    base=txt[:-4]
    if txt.startswith('cache/nara/'):
        m=json.load(open('cache/nara/manifest.meta.json'))[os.path.basename(base)+'.html']; return m['url'],m['retrieved_utc'],base+'.html',m['sha256']
    m=json.load(open(base+'.meta.json'))
    for ext in ('.pdf','.html','.xml','.json'):
        if os.path.exists(base+ext): return m['url'],m['retrieved_utc'],base+ext,m['sha256']
def ev(txt,quote):
    t=open(txt,encoding='utf-8').read()
    assert quote in t,(txt,quote)
    url,ts,orig,sha=meta(txt)
    assert hashlib.sha256(open(orig,'rb').read()).hexdigest()==sha
    return {"local_file":orig,"sha256":sha,"text_file":txt,"text_sha256":hashlib.sha256(open(txt,'rb').read()).hexdigest(),"url":url,"retrieved_utc":ts,"quote":quote}
TRA=[ev('cache/stat_90_1520.txt','(1) Section 6106 (relating t o publicity of unemployment t a x'),
     ev('cache/stat_90_1520.txt','(i) EFFECTIVE D A T E . — T h e amendments made by this section take'),
     ev('cache/stat_90_1520.txt','Section 6103 (relating to publicity of t a x 26 USC 6103.')]
CFR=[ev('cache/ecfr_301_6103a1_api.txt','to an officer or employee of a Federal agency (as defined in section 6103(b)(9))'),
     ev('cache/usc26_6103_lii.txt','The term “ Federal agency ” means an agency within the meaning of section 551(1) of title 5'),
     ev('cache/usc5_551_lii.txt','but does not include— (A) the Congress'),
     ev('cache/usc26_6103_lii.txt','specially authorized to inspect any return or return information by a resolution of the Senate or the House of Representatives')]
C7851=ev('cache/usc26_7851_lii.txt','The provisions of subtitle F shall apply with respect to any tax imposed by the Internal Revenue Code of 1939 only to the extent provided in subparagraphs (B) and (C) of this paragraph.')
base_checks=dict(quotes_exact=True,sha_match=True)
recs=[]
def add(iid,verdict,sub,anyv,checks,problems,dissent,evs):
    c=dict(base_checks); c.update(checks)
    recs.append({"instrument_id":iid,"proposal_id":"opus:s9:status:"+iid,"reviewer":"V9_TAX_REV","verdict":verdict,
      "reviewer_substantive_effect":sub,"reviewer_any_operative_effect":anyv,"checks":c,"problems":problems,
      "dissent_or_limiting_predicates":dissent,"reviewer_evidence":evs})
full=dict(text_complete=True,refetched=True,footprint_complete=True,law_checked=True,later_changes_checked=True,rule_predicates_met=True)
add("EO:6342","accept","no","no",full,
 ["Pre-FR order: only source is APP transcript (re-fetched; operative text and annexed T.D. para. 13(a) identical). Byte hash differs from producer copy (dynamic page), text content same.",
  "No own time limit; closure rests solely on recipient cessation (NARA: committee 'continued until 1938'; Air Mail committee ceased 1935). Senate resolution text not retrieved; end year, not date."],
 "Recipient-ceased rule applies on the order's own text: sole permission is to the special committee 'appointed under Senate Resolution 78, Seventy-third Congress'; the annex names only that committee and the Air Mail committee. Covered returns are pre-1939 Revenue Act returns, so the 1939-Code/TRA question is moot: the permission has no present actor. NARA tables start 1937; APP citation search (re-run) finds no later order.",
 [ev('cache/app_eo6342.txt','appointed under Senate Resolution 78, Seventy-third Congress, such inspection'),
  ev('cache/nara_senguide_ch18.txt','created by S. Res. 78 on June 13, 1933, and continued until 1938'),
  ev('cache/nara_senguide_ch18.txt',"The committee's activity ceased after the submission of its preliminary report regarding ocean mail contracts on June 18, 1935.")])
add("EO:9281","accept","no","no",full,
 ["Order covers returns 'for the year 1932 and subsequent years' under the Revenue Acts 1932-1938 AND the 1939 Code, so it does reach 1939-Code returns (focus b). Closure does not depend on TRA 1976: the permission is 'for the purpose of carrying out the provisions of House Resolution 420 ... (Seventy-seventh Congress, second session)' and addressed to the Special Committee, which was replaced in 1945; successor HUAC abolished 1975.",
  "Producer's end date '1945' is the latest bound; earlier end at the close of the 77th Congress (Jan 3, 1943) is the better-supported first cessation, corroborated by the series pattern: a new order was issued for each new resolution (EO 7933-A 1938, EO 8131 1939 'See: EO 9281', EO 9281 1942, EO 9444 1944 for H.Res. 65). H.Res. 420 text still not retrieved.",
  "EO 9444 incorporates 9281's description of returns by reference ('the returns described in such Executive Order'); this is a reference used by 9444, not a continuing effect of 9281, and 9444 itself was tied to H.Res. 65 (78th Cong.) and the same Special Committee (ended 1945)."],
 "Not a 'during the Nth Congress' clause; the limit is a resolution-purpose limit plus a named recipient. Both ended long before the cutoff regardless of which Code governs the returns.",
 [ev('cache/fr_1942-12-12.txt','Resolution 420, passed March 11-, 1942'),
  ev('cache/fr_1942-12-12.txt','Internal Revenue Code, for the year 1932'),
  ev('cache/nara_houseguide_ch14.txt','In 1945 the House Un-American Activities Committee was created as a permanent standing committee to replace the temporary Select Committee on Un-American Activities'),
  ev('cache/nara_houseguide_ch14.txt','In 1975 the committee was abolished'),
  ev('cache/nara/1939.txt','See: EO 7933-A, July 14, 1938; EO 9281')])
add("EO:10455","accept","no","no",full,
 ["Order covers returns 'for any period to and including 1952' (1953 after EO 10566), i.e. 1939-Code returns (focus b), but its own text limits inspection to 'during the Eighty-third Congress'; that limit closes it irrespective of 1939 Code sec. 55 continuity.",
  "NARA 1953-eisenhower disposition page still 404 (re-tried curl, bare host, no-.html, Playwright; Wayback CDX connection reset; WebFetch cannot reach web.archive.org; archive.ph 429; federalregister.gov CAPTCHA/API 403). Mitigation: re-run APP citation searches (only EO 10566) and all reachable NARA tables 1937-2005 (62 pages) scanned: 10455 appears only in the 1954 table (EO 10566). FR 1954-10-02 index: '10455 (amended by EO 10566)'."],
 "Congress-term predicate met on own text.",
 [ev('cache/fr_1953-05-26.txt','to and including 1952, shall, during'),
  ev('cache/fr_1953-05-26.txt','the Eighty-third Congress, be open to'),
  ev('cache/nara/1954.txt','Amendment of Executive Order No. 10455, Authorizing the Inspection of Certain Tax Returns')])
add("EO:10566","accept","no","no",full,
 ["TC09 host mapping confirmed: the sole operative clause amends EO 10455 'by striking out “1952” and inserting in lieu thereof “1953”'; the host contains '1952' only once (the return-period clause), which sits inside the 83d-Congress permission. Entire amender footprint is in the host; the host's own term ended Jan 3, 1955.",
  "Covered 1953 returns are 1939-Code returns; irrelevant because the host's Congress limit governs."],
 "Amender predicate (TC09) met; no independent clause.",
 [ev('cache/fr_1954-10-02.txt','hereby amended by striking out “1952”'),
  ev('cache/fr_1954-10-02.txt','No. 10455 of May 22, 1953, entitled “In')])
add("EO:11020","accept","no","no",full,
 ["Covers returns 'for the years 1946 to 1962' (1946-1953 are 1939-Code returns; authority recites 1939 Code sec. 55(a)); own text limits it to 'during the Eighty-seventh Congress' (ended Jan 3, 1963).",
  "NARA 1962 disposition page 404 (same escalation ladder as 10455, all failed). Mitigation: APP searches ('Order No. 11020' 0 hits; 'Executive Order 11020' only itself); NARA tables 1963-1978 do not mention 11020; any extension would have been a new order (cf. series pattern) and none is cited."],
 "Congress-term predicate met on own text.",
 [ev('cache/fr_1962-05-09.txt','for the years 1946 to 1962, inclusive, shall, during the Eighty-seventh'),
  ev('cache/fr_1962-05-09.txt','Internal Revenue Code o f 1939, as amended')])
add("EO:11720","accept","no","no",full,
 ["Covers returns 'for the years 1939 to 1974' including 1939-Code returns (focus b); own text limits to 'during the Ninety-third Congress' (ended Jan 3, 1975). Closure independent of TRA 1976 and of 1939 Code sec. 55 continuity."],
 "Congress-term predicate met on own text.",
 [ev('cache/fr_1973-05-21.txt','excess-profits, estate, gift, or excise tax return for the years 1939 to 1974,'),
  ev('cache/fr_1973-05-21.txt','inclusive, shall, during the Ninety-third Congress, be open to inspection')])
add("EO:11786","accept","no","no",full,
 ["Confirmed: no 'during the Nth Congress' clause and no named end. Closure rests on TRA 1976 sec. 1202(a)(1) (6103 rewritten), 1202(h)(1) (6106 repealed), 1202(i) (effective Jan 1, 1977), no savings clause in 1202(a)-(i) (read in full). Post-1976 committee access only under new 6103(f)(3) by House/Senate resolution.",
  "Focus (b): the object is 'all tax returns of President Nixon for the years 1969 through 1972' and related records, which are 1954-Code returns; the order cites only 1954 Code secs. 6103(a) and 6106. The 1939-Code counterexample therefore cannot apply.",
  "26 CFR 301.6103(a)-1 reaches only disclosures to a 'Federal agency (as defined in section 6103(b)(9))' = 5 U.S.C. 551(1), which excludes 'the Congress'; no residual for the Judiciary Committee.",
  "Additional, independent (inferential) end: the permission is 'in connection with House Resolution 803' (93d Cong.), a House resolution whose authority lapsed no later than Jan 3, 1975; resolution text not retrieved by either party."],
 "TRA-1976 predicate met on own text: clause rests solely on 1954 Code 6103(a)/6106 and covers only 1954-Code returns; recipient is not a Federal agency.",
 [ev('cache/fr_1974-06-11.txt','By virtue of the authority vested in me by sections 6 1 0 3 (a ) and 6106'),
  ev('cache/fr_1974-06-11.txt','thorized, in connection with House Resolution 803, authorizing and'),
  ev('cache/fr_1974-06-11.txt','all tax returns of President Nixon for the years 1969 through 1972, includ')]+TRA+CFR)
add("EO:11900","accept","no","no",full,
 ["Own text: 'during the Ninety-fourth Congress' (ended Jan 3, 1977); returns 1955-1975 (1954 Code only). TRA 1976 took effect Jan 1, 1977, two days earlier, so the first cessation is the statutory replacement; the rule label RULE-TAX-CONGRESS-TERM in rules.jsonl is a backstop, not the first cause. Status unaffected; flag for any time-vs-intervention headline coding.",
  "Class-of-returns proviso and Privacy Act statement condition are ancillary to inspection and end with it."],
 "Both predicates (Congress-term, TRA-1976 1954-Code-only, non-agency recipient) met on own text.",
 [ev('cache/fr_1976-01-23.txt','conditions imposed herein, during the Ninety-fourth Congress, be open to inspection'),
  ev('cache/fr_1976-01-23.txt','estate, or gift tax return for the years 1955 to 1975, inclusive, shall, subject to the')]+TRA[1:2])
ind=dict(text_complete=True,refetched=False,footprint_complete=True,law_checked=True,later_changes_checked=True,rule_predicates_met=True)
blk="1939-Code blocker confirmed on current 26 U.S.C. 7851(a)(6)(A) text (re-fetched); TRA 1976 sec. 1202 contains no clause on 1939-Code returns; new 6103(b)(1) defines 'return' by reference to 'this title'. Reviewer did not complete gates 1-6 for a 'no' and does not upgrade."
add("EO:5824","accept","indeterminate","indeterminate",dict(ind,text_complete=False,footprint_complete=False),
 ["Operative text (APP) open-ended; annexed March 22, 1932 regulation amendment not obtained, so footprint incomplete, as producer says. "+blk,
  "Not in any NARA table (pre-1937); APP: no later order."],"Indeterminate correctly held; possible displacement by EO 5970/T.D. 4359 remains a lead only.",[C7851])
add("EO:9499","accept","indeterminate","indeterminate",ind,
 ["Open-ended permission to Commerce for 1939-Code returns 'for the year 1941 and subsequent years'; no own limit; recipient exists. "+blk,
  "301.6103(a)-1 residual doubtful for a 1939-Code sec. 55 order (regulation speaks of orders 'under section 6103'), as producer notes. NARA 1944 and later tables: no change (1951 hit is an FR page number)."],"Indeterminate correctly held.",[C7851])
add("EO:10076","accept","indeterminate","indeterminate",ind,
 ["Open-ended permission to the Military Renegotiation Policy and Review Board for 1939-Code returns 1939+. Reviewer WebSearch also found no source for the Board's abolition (only the Renegotiation Board's 1979 termination). "+blk],
 "Indeterminate correctly held; would become no/no under RULE-TAX-RECIPIENT-CEASED if the Board's end (without successor) is sourced.",[C7851])
add("EO:10090","accept","indeterminate","indeterminate",ind,
 ["Open-ended permission to FTC for 1949-1950 corporate returns (1939 Code only). "+blk],"Indeterminate correctly held.",[C7851])
add("EO:10619","accept","indeterminate","indeterminate",ind,
 ["Mixed 1939/1954-Code clauses; 1954-Code clause ended Jan 1, 1977 (TRA, verified), 1939-Code clause blocked; recipient is a Federal agency so 301.6103(a)-1 residual (verified text) is real but subject not proved. "+blk],"Indeterminate correctly held.",[C7851]+CFR[:1])
add("EO:10814","accept","indeterminate","indeterminate",ind,
 ["Mixed: transcript cards from corporate returns for years ending after 1952 (partly 1939-Code) and returns for years ending after 1956 (1954 Code). Same analysis as 10619. "+blk],"Indeterminate correctly held.",[C7851]+CFR[:1])
with open('reviews.jsonl','w') as f:
    for r in recs: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(len(recs))
