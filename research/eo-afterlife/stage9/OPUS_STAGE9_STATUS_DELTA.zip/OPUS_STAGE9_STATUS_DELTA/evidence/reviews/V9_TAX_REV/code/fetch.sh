#!/bin/bash
# usage: fetch.sh <id> <ext> <url>
R=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_TAX_REV/cache
id=$1; ext=$2; url=$3
out=$R/$id.$ext
info=$(curl -sSL --compressed -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36" --max-time 180 -o "$out" -w '%{http_code}|%{url_effective}|%{content_type}' "$url")
ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
code=${info%%|*}; rest=${info#*|}; furl=${rest%%|*}; ct=${rest#*|}
sha=$(sha256sum "$out" | cut -d' ' -f1)
python3 -I -c "import json,sys;json.dump({'url':sys.argv[1],'final_url':sys.argv[2],'retrieved_utc':sys.argv[3],'http_status':int(sys.argv[4]),'content_type':sys.argv[5],'sha256':sys.argv[6],'method':'curl original bytes (reviewer V9_TAX_REV)'},open(sys.argv[7],'w'),indent=1)" "$url" "$furl" "$ts" "$code" "$ct" "$sha" "$R/$id.meta.json"
echo "$ts $id $code $ct $(stat -c %s $out) $sha"
echo "$ts | curl | $url | $code" >> $R/../attempts.log
