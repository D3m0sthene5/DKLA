const { chromium } = require('playwright');
(async () => {
  const [url, out] = process.argv.slice(2);
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const p = await b.newPage({ ignoreHTTPSErrors: false });
  let status = null;
  try { const r = await p.goto(url, { timeout: 90000, waitUntil: 'domcontentloaded' }); status = r && r.status(); } catch (e) { console.log('ERR', e.message.slice(0,200)); }
  const html = await p.content();
  require('fs').writeFileSync(out, html);
  console.log(status, html.length, await p.title());
  await b.close();
})();
