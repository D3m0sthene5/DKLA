#!/bin/bash
# usage: fetch.sh <source_id> <url> <ext>
set -u
SID="$1"; URL="$2"; EXT="$3"
C=/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWI_REV/cache
OUT="$C/$SID.$EXT"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
RES=$(curl -sSL -A "Mozilla/5.0 (X11; Linux x86_64) research-reviewer" --max-time 240 -o "$OUT" -w '%{http_code}\t%{url_effective}\t%{content_type}' "$URL")
CODE=$(echo "$RES" | cut -f1); FINAL=$(echo "$RES" | cut -f2); CT=$(echo "$RES" | cut -f3)
SHA=$(sha256sum "$OUT" | cut -d' ' -f1)
python3 -I -c '
import json,sys
sid,ext,url,final,ts,code,ct,sha,c=sys.argv[1:]
json.dump({"source_id":sid,"url":url,"final_url":final,"retrieved_utc":ts,"http_status":int(code),"content_type":ct,"sha256":sha,"method":"curl original bytes","retrieved_by":"V9_WWI_REV"},open(c+"/"+sid+".meta.json","w"),indent=1)
' "$SID" "$EXT" "$URL" "$FINAL" "$TS" "$CODE" "$CT" "$SHA" "$C"
echo "$SID $CODE $(stat -c %s $OUT) $SHA $TS"
