import json,hashlib,os,sys
R="/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWI_REV"
C=R+"/cache"
def meta(sid):
    return json.load(open(f"{C}/{sid}.meta.json"))
def sl(txtfile,start,end):
    t=open(f"{C}/{txtfile}",encoding="utf-8",errors="strict").read()
    i=t.index(start); j=t.index(end,i)+len(end)
    return t[i:j]
def ev(sid,txtfile,start,end,note=""):
    m=meta(sid)
    q=sl(txtfile,start,end)
    t=open(f"{C}/{txtfile}",encoding="utf-8").read()
    assert q in t
    raw=[f for f in os.listdir(C) if f.startswith(sid+".") and not f.endswith((".meta.json",))]
    lf=f"reviews/V9_WWI_REV/cache/{txtfile}"
    return {"local_file":lf,"sha256":hashlib.sha256(open(f"{C}/{txtfile}","rb").read()).hexdigest(),
            "original_bytes_sha256":m["sha256"],"url":m["url"],"retrieved_utc":m["retrieved_utc"],"quote":q,"note":note}
def img(sid,note):
    m=meta(sid)
    return {"local_file":f"reviews/V9_WWI_REV/cache/{sid}.jpg","sha256":m["sha256"],"url":m["url"],"retrieved_utc":m["retrieved_utc"],"quote":None,"note":note}
