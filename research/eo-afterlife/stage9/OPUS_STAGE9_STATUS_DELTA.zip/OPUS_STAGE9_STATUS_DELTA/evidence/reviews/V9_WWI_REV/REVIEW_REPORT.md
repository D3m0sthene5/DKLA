# V9_WWI_REV: independent review of shard S9_WWI

- Reviewer: V9_WWI_REV. Codebook 2.0.0. Cutoff 2026-10-14 America/New_York.
- Actual UTC start: 2026-10-16T16:57:32Z. Actual UTC end: 2026-10-16T17:12:30Z.
- When I read the three held proposals (2663, 2678, 3015): 2026-10-16T17:09:06Z. At that time the file's mtime was 17:02:45Z and its sha256 was bfad1f97455c5c9bb4ce211efa181f7143fa9a1c7c16a1f7ecab7dc85c32d437. Since my first read at 16:57Z, only `hold_reason` and `subsequent_change_check` had changed for those three. The seven `no` records had not changed.
- Outputs: `reviews.jsonl` (10 records), `cache/` (original bytes, each with a `.meta.json` giving URL, real retrieval UTC and sha256, plus a text extract), `code/`, `view/` (downscaled page images I looked at).

## Verdict counts

| verdict | n | IDs |
|---|---|---|
| accept | 9 | 1547, 2554, 2559A, 2605, 2830, 2918 (all no/no); 2663, 2678, 3015 (indeterminate/indeterminate holds) |
| accept_with_correction | 1 | 2908 (no/no stands, but the reasoning needs correcting) |
| reject_to_indeterminate | 0 | |
| reject_other | 0 | |

**Error rate** (non-accept / total) = 1/10 = **10%**.

Sensitivity: the shared-rule savings error (problem 1 below) appears word for word in all seven `no` records. If a reviewer counts that as a reasoning correction for every one of them, the rate would be 7/10. I kept those six as `accept` because each record also states the factual ground that actually decides the case.

## What I checked

1. **Evidence fidelity.** I checked all 32 evidence records with python3 -I.
   - Every sha256 matches.
   - Every quote is an exact substring of its text file.
   - Minor issue: for the statute PDFs and APP HTML, `local_file` names the .pdf or .html, but the quotes are substrings of the derived .txt. The .txt sha256 is recorded in the meta file.
2. **Text completeness and re-fetch.** I re-fetched every `no` order myself. I confirmed the archive.org scans by viewing the page images.

| Order | Producer source re-fetched | Further confirmation |
|---|---|---|
| 1547 | Yes (byte-identical) | Scan p. 130 of the GPO 1922 Panama Canal EO compilation |
| 2554 | Yes (byte-identical) | Two more printings: AFL Proceedings 1917 (independent) and 7 Comp. Gen. 76 (quoted in full). Also the Sun Ship Building Co. record (the order was incorporated by contract clause) |
| 2559A | Yes | Independent printing in AFL Proceedings 1917 |
| 2605 | Yes (APP) | AFL Proceedings 1917 |
| 2830 | Yes | Official Bulletin scan, Apr. 6, 1918, pp. 13 and 15; independent printing in American Lumberman, Apr. 13, 1918 |
| 2908 | Yes | Official Bulletin scan, July 16, 1918, p. 2 |
| 2918 | Yes | Official Bulletin scan, July 22, 1918, p. 15; Public Works, Aug. 17, 1918 |

   - All seven texts are complete as published.
   - The "completion, etc.," wording in 2830 also appears in the independent American Lumberman printing, so it is probably in the released text rather than a Bulletin abbreviation. It does not affect the scope, which is one named building.
3. **Controlling law, read myself from govinfo PDFs.** 37 Stat. 137-138 (1912 Act secs. 1-3), 39 Stat. 1192 (1917 proviso), 41 Stat. 1359-1360 (Mar. 3, 1921 joint resolution, approved; it covers Acts, joint resolutions and proclamations only), 76 Stat. 357-360 (Pub. L. 87-581), and Pub. L. 97-468 title VI (96 Stat. 2556 ff.).
   - **1962 Act.** It was approved Aug. 13, 1962. Sec. 204 makes it effective 60 days later, which is 1962-10-12. Sec. 203 repeals 40 U.S.C. 321-322 (the 1892 Act as amended in 1913), 324-325 (the 1912 Act) and 326 (the 1917 power). Its savings clause keeps "the provisions of such statutes" applying only to contracts existing on the effective date or let under bids then outstanding. Sec. 202(b) keeps Court of Claims jurisdiction over 40 U.S.C. 324 penalty claims for those same contracts.
   - **Can the savings clause keep any of these orders alive?** No.
     - It saves contracts only. Government-employee coverage, such as EO 2605's second clause, ended outright on 1962-10-12.
     - None of the seven orders was operative on 1962-10-12. Their own limits were the WWI emergency, 1915, or one finished building. The Comptroller General held in 1927 that EO 2554's authority had ceased. Later suspensions were fresh orders, not reliance on these: EO 8198 (1939), and EO 9849 (1947) under a different statute.
     - Any contract that did exist on 1962-10-12 was performed long before the 2026 cutoff.
4. **Later changes.** I searched the Lord 1944 list, both volumes, including the subject index under "Labor - Eight-hour day - Suspended for". There is no revoking, amending or reviving entry for any of the ten orders. I also confirmed that EO 9849 does not rely on EO 2908.
5. **Saved wage rights.** None is attributable to these orders.
   - The time-and-a-half overtime right came from the 1917 proviso, not from the orders.
   - Penalty claims and Court of Claims jurisdiction were saved only for contracts existing in 1962.
   - Claims against the U.S. are barred after 6 years (28 U.S.C. 2501, current text read).
   - EO 2678 is the only order that might have touched wage computation. Its text is missing, so it correctly stays on hold.

## Systematic problems

1. **The shared rule misstates the savings clause (affects all seven `no` records; the outcome is unchanged).** Rule S9WWI-R1 says the 1962 savings clause preserves only "saved statutory applications, not EO authority (TC08)". That is too broad. Sec. 203 also saves the 40 U.S.C. 326 suspension power for contracts existing in 1962. So an EO suspension that was still operative on 1962-10-12 could have continued as an EO effect for such a contract. The `no` results should rest on the facts instead: none of these orders was operative on 1962-10-12, and any contract saved then is long performed (TC14). The producer states this factual ground in short form, so the statuses stand.
2. **EO 2908 (accept_with_correction).**
   - The record omits the 1985 transfer. Pub. L. 97-468 sec. 615(a)(1) repealed the 1914 Alaska Railroad Act (38 Stat. 305) on the date of transfer, which the 45 U.S.C. 1203 note gives as Jan. 5, 1985. On that date the State assumed the railroad's contracts (sec. 604(d)(2)(A)). So after 1985 there are no U.S.-party contracts for the order's object ("the Alaskan Railroad now being built and operated by the United States").
   - The record's statement that no 1962-existing contract is "plausible" is wrong for this order. U.S.-party maintenance contracts for the railroad certainly existed in 1962. The correct ground is the order's own "during the present national emergency" (WWI) limit, with the 1985 transfer as an independent outer bound.
   - The producer was right that "maintenance" of a running railroad gives no finite-project end.
3. **EO 2918 is a second continuing-object order that the rule does not list.** Its scope includes "management, maintenance ... repair" of war housing, the same kind of continuing object as EO 2908. Rule S9WWI-R1's exceptions list only 2908. The order's own record correctly relies on P3(c) plus P5, so this is bookkeeping only.
4. **EO 2554 is handled correctly as a counterexample.** It has no date term. Its operative clause ties it to "present emergency conditions", so P3(c) is met on its own text (TC16). The Comptroller General (1927) and the 1920 Navy contract that still cited it were both disclosed. The first cessation is correctly left unpinned.
5. **The holds (2663, 2678, 3015) are correct.**
   - My own archive.org full-text searches found only catalog, Lord and bibliography summaries.
   - archive.org has no Alaska Railroad Record and no 1917 or Oct.-Dec. 1918 Official Bulletin volumes.
   - The 3015 phrase appears in the access-restricted Brookings Shipping Board monograph, but only as a summary.
   - Under TC15 none of the three can be `no`, so I did not upgrade them.

## Retrieval notes

- uscode.house.gov returned a maintenance page and then "Page Not Found", so I used govinfo USCODE-2024 HTML for 45 U.S.C. 1201-1206 and 28 U.S.C. 2501.
- govinfo `link/statute/96/2556` resolved to the wrong page (Proclamation 4953). I fetched STATUTE-96-Pg2543.pdf directly.
- Page images came from `archive.org/download/<id>/page/n<k>_w1600.jpg`; I located the pages with the fulltext `inside.php` search.
- What I did not verify: the exact completion date of the Arlington Building (full-text snippets suggest Veterans Bureau use by 1923; not fetched), and the six-year limitation period as it read in 1917-1921 (only the current text was read).
