import json,sys
sys.path.insert(0,"/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWI_REV/code")
from ev import ev,img
R="/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/reviews/V9_WWI_REV"

LAW=[
 ev("stat_76_357","stat_76_357.txt","SEC. 203. The following statutes are hereby repealed","Approved August 13, 1962, 11:46 a.m.","1962 repeal; savings limited to contracts existing on effective date (Aug 13 + 60 days = Oct 12, 1962) or under then-outstanding bids. Savings keeps 'the provisions of such statutes' (incl. 40 U.S.C. 326 suspension power) applying to those contracts."),
 ev("stat_39_1168","stat_39_1168.txt","That   in case of national emergency the President is authorized to","less than time and one-half for all hours work in excess of eight hours.","1917 proviso: suspension power + statutory overtime"),
]
WAGE=ev("usc_28_2501","usc_28_2501.txt","Every claim of which the United States Court of Federal Claims has jurisdiction","after such claim first accrues.","Six-year limit on claims against the U.S.; any 1912-1921 overtime/penalty claims long barred")
J1921=ev("stat_41_1359","stat_41_1359.txt","of any provision relating to the duration or date of the termination","of the termination of the war or of the present or existing emergency,","1921 joint resolution (Acts, joint resolutions, proclamations only; analogy for EOs)")
CHECKS_BASE={"quotes_exact":True,"sha_match":True,"text_complete":True,"refetched":True,"footprint_complete":True,"law_checked":True,"later_changes_checked":True,"rule_predicates_met":True}
RULECORR=("Shared-rule correction (S9WWI-R1 savings statement): the producer says the 1962 savings clause preserves only 'saved statutory applications, not EO authority (TC08)'. That is too broad. Sec. 203 keeps 'the provisions of such statutes' applying to contracts existing on 1962-10-12, and those statutes include the 40 U.S.C. 326 suspension power. An EO suspension that was still operative on 1962-10-12 for a then-existing contract could therefore have continued for that contract as an EO effect. The 'no' result rests instead on facts: (i) no covered order was operative on 1962-10-12 (WWI-emergency or finite-project limits; Comp. Gen. 1927; fresh suspensions in 1939 (EO 8198) and 1947 (EO 9849) under other authority), and (ii) any contract existing on 1962-10-12 was performed long before the 2026-10-14 cutoff (TC14 bounded continuity). The producer does state ground (i) in short form ('no 1962-existing contract under a 1912-1918 order is known or plausible'), so the per-order statuses stand.")
WAGENOTE=("Saved wage rights (reviewer check d): the time-and-one-half overtime right came from the 1917 proviso, not from the orders. Penalty claims (40 U.S.C. 324) and Court of Claims jurisdiction were saved only for contracts existing on 1962-10-12 (sec. 202(b), 203, 204). Claims accruing 1912-1921 against the U.S. were barred after six years (28 U.S.C. 2501, current text read; the predecessor limit was also six years, not re-read). No surviving wage right is attributable to any of these orders.")

recs=[]
def rec(iid,verdict,sub,anyv,checks,problems,dissent,evid):
    c=dict(CHECKS_BASE); c.update(checks)
    recs.append({"instrument_id":iid,"proposal_id":f"opus:s9:status:{iid}","reviewer":"V9_WWI_REV","verdict":verdict,
      "reviewer_substantive_effect":sub,"reviewer_any_operative_effect":anyv,"checks":c,"problems":problems,
      "dissent_or_limiting_predicates":dissent,"reviewer_evidence":evid})

# EO 1547
rec("EO:1547","accept","no","no",{},
 ["Minor: evidence records E02-E07 cite the .pdf as local_file, but the quotes are substrings of the derived .txt (the .txt sha256 is in the meta file). This applies to all statute evidence in the shard."],
 [RULECORR,"Own end confirmed on the scan (p. 130, GPO 1922 compilation): waiver 'until January first, nineteen hundred and fifteen'. The 1912 Act sec. 2 canal-waiver power itself ran only to that date. The waived Act was repealed eff. 1962-10-12.",WAGENOTE],
 [ev("ia_pc_eos_1921","ia_pc_eos_1921.txt","By  virtue  of  the  authority  conferred  upon  me  by  Section  2","struction of  the  Isthmian  Canal.","Re-fetched archive.org djvu text (byte-identical to producer copy)"),
  img("pc_n131_eo1547","Page image n131 = printed p. 130, viewed by reviewer: order complete, signed Wm H Taft, June 19, 1912, [No. 1547]"),
  ev("stat_37_137","stat_37_137.txt","tive order, may waive the provisions and stipulations in this Act as","construction of the Isthmian Canal.","1912 Act sec. 2"),LAW[0]])

# EO 2554
rec("EO:2554","accept","no","no",{},
 ["Producer's text came from one secondary printing (BLS Monthly Review). Reviewer confirmed it from two more printings: AFL Proceedings 1917 (independent) and 7 Comp. Gen. 76 (quoted in full). The 'present emergency conditions' condition is in the operative clause, so predicate P3(c) is met on the order's own text (TC16)."],
 [RULECORR,"Counterexample handled correctly: the order has no date or 'until further orders' term. It ends through its own condition ('hastening preparation to meet present emergency conditions'). The Comptroller General (1927) held that the authority ceased when that need ceased. The first cessation stays unpinned because a 1920 Navy contract still cited the order. The 1962 repeal is the certain outer bound. EO 8198 (1939) used a fresh suspension.","Sun Ship Building Co. v. United States, 271 U.S. 96 (1926), record: the order was applied by contract clause ('shall be made applicable to work under this contract'). Any effect therefore lived in specific Navy contracts, all long performed.",WAGENOTE],
 [ev("ia_afl_1917","ia_afl_1917.txt","I do hereby authorize the suspension of the provisions of law pro-","hastening preparation to meet present emergency conditions.","Independent printing of full text, AFL Proceedings 1917 p. 109"),
  ev("ia_compgen_v7","ia_compgen_v7.txt","When the need for","ceased to exist. The provi-","7 Comp. Gen. 76 (1927)"),
  ev("ia_sunship_record","ia_sunship_record.txt","shall be made applicable to work under this contract","shall be made applicable to work under this contract","Sun Ship record: the order was incorporated by contract clause"),
  ev("ia_mlr_1917_05","ia_mlr_1917_05.txt","I do hereby authorize the suspension of the provisions of law prohibit-","in hastening preparation to meet present emergency conditions,","Producer's source re-fetched (byte-identical)"),LAW[0],WAGE])

# EO 2559A
rec("EO:2559A","accept","no","no",{},
 ["Producer had one printing (NWLB Memorandum 1918). Reviewer confirmed the full text in an independent printing (AFL Proceedings 1917) and found no differences in the operative clause."],
 [RULECORR,"'during the pending emergency and until further orders': under either reading of 'and', the 1917 proviso allows suspension only 'in case of national emergency', and the suspended 1912 Act was repealed eff. 1962-10-12.",WAGENOTE],
 [ev("ia_afl_1917","ia_afl_1917.txt","It is hereby ordered that the provisions of the Act approved June 19, 1912,","until further orders. This order shall take effect from and after this date.","AFL Proceedings 1917 p. 109, EO of 24 March 1917"),
  ev("ia_memo8hr","ia_memo8hr.txt","it is hereby ordered that the provisions of the act approved June 19, 1912,","pending emergency and until further orders.","Producer's source re-fetched (byte-identical)"),LAW[0],LAW[1]])

# EO 2605
rec("EO:2605","accept","no","no",{},
 [],
 [RULECORR,"Second clause ('extraordinary emergency' under 1892/1913 Act, including government employees): secs. 1-2 of the 1892 Act were repealed eff. 1962-10-12. For government employees there is no saving at all, because sec. 203 saves only contracts. 'operative during the pending emergency or until further orders' was confirmed in APP and AFL 1917.",WAGENOTE],
 [ev("app_eo2605","app_eo2605.txt","This order shall take effect from and after this date and shall be operative during the pending emergency or until further orders.","This order shall take effect from and after this date and shall be operative during the pending emergency or until further orders.","APP re-fetch"),
  ev("ia_afl_1917","ia_afl_1917.txt","Under authority contained in the Naval Appropriation Act approved \nMarch 4, 1917 (Public No. 391, 64th Congress), it is hereby ordered that the","in Executive Order of March 24, 1917.","AFL Proceedings 1917 independent printing (first clause)"),LAW[0]])

# EO 2830
rec("EO:2830","accept","no","no",{},
 ["The 'completion, etc.,' abbreviation also appears in an independent trade-press printing (American Lumberman, Apr. 13, 1918). It is therefore probably in the released text itself, not an editing choice by the Bulletin. The scope (one named building) is unaffected. Reviewer viewed the Official Bulletin scan pages (Apr. 6, 1918, pp. 13 and 15). The order appears within Secretary McAdoo's letter on the Government's purchase of the building, which the President approved on Mar. 25, 1918."],
 [RULECORR,"P3(b) is met: the order is limited to completing one named building. The building was in Government office use by the early-to-mid 1920s (producer evidence: 1926; archive.org full-text snippets suggest Veterans Bureau use by 1923, not fetched). The suspended statutes were repealed eff. 1962-10-12.",WAGENOTE],
 [ev("ia_amlumber_19180413","ia_amlumber_19180413.txt","I do hereby suspend the pro","This \norder will take effect from and after this date.","Independent printing, American Lumberman Apr. 13, 1918"),
  img("ob01_n986_eo2830","Official Bulletin Apr. 6, 1918 p. 13 page image (McAdoo letter; President approved Mar. 25, 1918; start of order)"),
  img("ob01_n988_eo2830","Official Bulletin Apr. 6, 1918 p. 15 page image (rest of order, signed Woodrow Wilson, Apr. 1, 1918)"),LAW[0]])

# EO 2908
rec("EO:2908","accept_with_correction","no","no",{},
 ["The producer's footprint and rule omit the 1985 transfer. The 1914 Alaska Railroad Act (38 Stat. 305), under which the order's object ('the Alaskan Railroad now being built and operated by the United States') existed, was repealed on the date of transfer, Jan. 5, 1985 (Pub. L. 97-468 sec. 615(a)(1)). On that date the State assumed the railroad's contracts (sec. 604(d)(2)(A)), so after 1985 there are no U.S.-party contracts for maintaining the Alaskan Railroad.",
  "The producer's savings analysis is weakest for this order. Alaska Railroad maintenance contracts with the U.S. as a party certainly existed on 1962-10-12, so 'no 1962-existing contract ... plausible' is not the right ground. The right ground is that the order's suspension ran only 'during the present national emergency' (WWI). Supporting this, EO 9849 (1947) used a fresh 'extraordinary emergency' finding under the 1892/1913 Act for Alaska Railroad work and did not rely on EO 2908. Even on the weakest view, the order's object and any saved contract ended with the 1985 transfer."],
 [RULECORR,"Counterexample handled correctly in substance: 'maintenance' of a continuing railroad gives no finite-project end, and the producer rightly relies on the emergency limit plus the 1962 repeal. Correction: add the 1985 transfer and the repeal of the 1914 Act as an independent bound on the object.","Verified on scan: Official Bulletin July 16, 1918, p. 2 (page image viewed); text complete; dated July 10, 1918.",WAGENOTE+" Under sec. 604(d)(2)(B) of the 1983 Act, the U.S. kept liability for claims against the Alaska Railroad accruing before transfer. Any 1918-era claims were already time-barred."],
 [ev("ia_ob02","ia_ob02.txt","hereby  ordered  that  during  the  pres-","by  said  act  of  March  4, 1917,  supra.","Official Bulletin July 16, 1918 p. 2 (re-fetched, byte-identical)"),
  img("ob02_n199_eo2908","Page image n199 = Official Bulletin July 16, 1918 p. 2, viewed: full order, Woodrow Wilson, July 10, 1918"),
  ev("stat_96_2543","stat_96_2543.txt","(2)(A) Prior to the date of transfer, the Secretary shall also certify","vided by this title.","Pub. L. 97-468 sec. 604(d)(2)(A): State assumes contracts"),
  ev("stat_96_2543","stat_96_2543.txt","SEC. 615. (a) On the date of transfer to the State","(1) The Act of March 12,1914 (43 U.S.C. 975 et seq.).","Sec. 615(a)(1): repeal of the 1914 Act on the date of transfer (OCR layout drops the word 'repealed')"),
  ev("usc_45_1203","usc_45_1203.txt","The transfer of the Alaska Railroad to the State of Alaska was carried out on January 5, 1985.","The transfer of the Alaska Railroad to the State of Alaska was carried out on January 5, 1985.","45 U.S.C. 1203 note (govinfo USCODE-2024)"),
  ev("app_eo9849","app_eo9849.txt","WHEREAS by section 1 of the act of August 1, 1892","except in case of extraordinary emergency;","EO 9849 (1947): fresh suspension under a different statute"),LAW[0]])

# EO 2918
rec("EO:2918","accept","no","no",{},
 ["Rule bookkeeping: like EO 2908, EO 2918 covers continuing objects ('management, maintenance ... repair' of war housing), so no finite-project end is available. Rule S9WWI-R1 lists only 2908 as this kind of exception. The order's own record correctly relies on P3(c) ('during the present national emergency') plus P5, so the status is unaffected."],
 [RULECORR,"Verified on scan: Official Bulletin July 22, 1918, p. 15 (page image viewed); second printing Aug. 13, 1918. The operative clause also appears in Public Works, Aug. 17, 1918.",WAGENOTE],
 [ev("ia_ob02","ia_ob02.txt","I  do  hereby  suspend  during  the  pres-","needs.  This  order  will  take  effect  from","Official Bulletin July 22, 1918 p. 15 (re-fetched)"),
  img("ob02_n292_eo2918","Page image n292 = Official Bulletin July 22, 1918 p. 15, viewed: full order, Woodrow Wilson, July 18, 1918"),
  ev("ia_pubworks_19180817","ia_pubworks_19180817.txt","executive order suspending,","and other war needs.","Public Works Aug. 17, 1918 (independent partial printing)"),LAW[0]])

# holds
HOLDNOTE="Reviewer read status_proposals.jsonl for this ID at 2026-10-16T17:09:06Z (file mtime 17:02:45Z; sha256 bfad1f97455c5c9bb4ce211efa181f7143fa9a1c7c16a1f7ecab7dc85c32d437). Only hold_reason and subsequent_change_check had changed since 16:57Z."
for iid,extra,evs in [
 ("EO:2663","Single-contract order (contract no. 43, Feb. 19, 1917). The reviewer's own archive.org full-text searches ('contract No. 43' + 'Seattle Car'; 'Seattle Car and Foundry' + 'Executive order') found only Monthly Catalog, Lord and bibliography summaries. Advanced search found no 'Alaska Railroad Record' volumes and no 1917 Official Bulletin volume.",
  [ev("ia_lord_v2","ia_lord_v2.txt","Seattle  Car  and  Foundry  Co.  contracts  17,  2663,  2678","Seattle  Car  and  Foundry  Co.  contracts  17,  2663,  2678","Lord subject index: no revoking or amending entry")]),
 ("EO:2678","The catalog summary describes a waiver of wage-computation and overtime-rate provisions. This is the only order in the shard that might have affected workers' overtime rights, so text is essential. Reviewer searches ('Alaska railroad no. 9'; 'computation of wages' + 'Alaskan Engineering Commission') found only catalog entries.",
  [ev("ia_lord_v2","ia_lord_v2.txt","Seattle  Car  and  Foundry  Co.  contracts  17,  2663,  2678","Seattle  Car  and  Foundry  Co.  contracts  17,  2663,  2678","Lord subject index: no revoking or amending entry")]),
 ("EO:3015","Post-armistice order with a standing 'whenever necessary to prevent undue delay' condition (per catalog). P3(c) is not shown. The reviewer's full-text search found the phrase only in Monthly Catalog entries and in the access-restricted Brookings Shipping Board monograph (unitedstatesship0063smit). The snippet there is itself a summary ('Another, issued on December 3...'), not operative text.",
  [ev("ia_moncat_1918_1919","ia_moncat_1918_1919.txt","Hours  of  labor — Coutinued.","(No.  3015.)","Monthly Catalog annual volume: summary only")]),
]:
    rec(iid,"accept","indeterminate","indeterminate",
        {"text_complete":False,"refetched":False,"footprint_complete":False,"rule_predicates_met":None},
        ["No operative text exists in the record. The hold is correct under TC15 and the producer protocol ('no' needs text_obtained). The reviewer also failed to locate text (see dissent field). "+HOLDNOTE],
        [extra,"If text is found and shows only a suspension/waiver tied to the WWI emergency or to a completed 1917-1918 contract, the 1962 repeal (sec. 203) and the analysis above would very likely support no/no. That is not decided here (TC15)."],
        evs)

with open(R+"/reviews.jsonl","w") as f:
    for r in recs: f.write(json.dumps(r,ensure_ascii=False)+"\n")
print(len(recs))
for r in recs: print(r["instrument_id"],r["verdict"],len(r["reviewer_evidence"]))
