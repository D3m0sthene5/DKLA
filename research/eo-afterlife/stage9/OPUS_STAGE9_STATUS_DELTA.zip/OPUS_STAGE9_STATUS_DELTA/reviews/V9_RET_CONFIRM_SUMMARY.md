# V9_RET_CONFIRM summary (cutoff 2026-10-14, codebook 2.0.0)
Work started 2026-10-16T15:59:46Z, ended 2026-10-16T16:02:29Z (UTC, `date -u`). The input checksums (INPUT_SHA256SUMS.txt) all matched. I read only files in review5_input.

| EO | substantive | any | verdict | confidence |
|---|---|---|---|---|
| 8256 | no | no | confirm_no | high |
| 8497 | no | no | confirm_no | high |
| 8904 | no | no | confirm_no | high |
| 10225 | no | no | confirm_no | high |
| 11619 | no | no | confirm_no | medium |

- **Latta (EO 8256, 8497, 8904):** Under reading (a), each order ended on its own stated date: 1940-10-31, 1941-10-31 and 1942-10-31. Under reading (b), each follows EO 9238, which the ledger accepts as no/no (ended no later than 1978-09-30). Both readings give no. The earlier RET-R1 holds (RA: "packet EO 8256, 8497"; RB: "EO 8904 ... held") are resolved by the accepted result for EO 9238.
- **Pyke (EO 10225):** Under reading (a), the order ended no later than 1952-03-31 ("not extending beyond March 31, 1952,"). Under reading (b), it follows EO 10333, which the ledger accepts as no/no. Both readings give no.
- **EO 11619:**
  - The non-limitation clause is a rule of construction ("shall be deemed"). It grants and commands nothing, and the authority it mentions comes from EO 11228, not from this order (TC08). This matches the accepted treatment of EO 11378.
  - RET-R2 predicates Q1 to Q4 are met on the order's text. A "personal secretary of former President Truman" is in none of the 8335 categories that kept mandatory separation.
  - Q5 (no later order or statute) rests on the producer's search, which I could not repeat.
  - The dissenting view treats the clause as operative, which would make any_operative_EO_effect indeterminate. I do not adopt it, but I record it.
- **Statute check:** The files support the 1978-09-30 effective date and the striking of the general age rule.
  - publ95_256_92stat189.txt: "(1) by striking out subsections (a), (b), (c), (d), and (e) thereof;" and "The amendments made by this section shall take effect on September 30,1978,".
  - usc5_8335_2011.txt: "Amendment by Pub. L. 95–256 effective Sept. 30, 1978".
  - The age-70 / 15-year content of the struck subsection (a) appears only as a WebFetch paraphrase in usc5_8335_2011.txt. The two sources number the amending section differently (6(c) in the Statutes rendering, 5(c) in the Code note).
  - The 8335 file is the 2011 edition, so amendments from 2012 to 2026 are not shown.
- **Quotes:** All 70 quotes relied on are exact substrings of their files. Two variant spellings are NOT in the files: "September 30, 1978" (the file has the OCR form "30,1978") and "Pub. L. 95-256 effective" with an ASCII hyphen (the file uses an en dash).
- **Source limits:** The order texts are hosted transcripts fetched with WebFetch, not original bytes. "No other provision" is the tool's own statement, not verbatim text from the order.
