#!/usr/bin/env python3
"""Integrate Opus Stage 11 producer shards and independent reviews; patch the Stage 11 ledger.

Usage: python3 -I build_stage11.py <stage11_packet_dir> <s11_work_dir> <report_md> <out_dir>

Promotion gates (all required):
  * the ID is in OPUS_STAGE11_FINITE_CONTINUITY_1145 or OPUS_NIRA_P3_RECOVERED_16 (Opus-exclusive);
  * it is substantive 'indeterminate' in the Stage 11 reconciled ledger (sha256 below);
  * a separately instantiated reviewer agreed on an axis (accept / accept_with_correction /
    reject_to_indeterminate with the same value on that axis). Each axis stands only where producer
    and reviewer agree; otherwise it is indeterminate. Coordinator overrides may only make an axis stricter.
The patched ledger changes only accepted rows (status fields plus an 'opus11_present_status' object);
every other row is copied byte for byte.
"""
import collections, datetime, hashlib, json, os, re, shutil, sys

PKT, S11, REPORT, OUT = sys.argv[1:5]
LEDGER_SHA = "c0308e008cd719cd153ca667271c93267d5d855bf3eb26d48076e41938fc7729"
DENOM = 14973
PRIOR = {"YES": 193, "NO": 2322, "UNKNOWN": 12458}
PRIOR_ANY = {"YES": 205, "NO": 2165, "UNKNOWN": 12603}
PRIOR_DET = PRIOR["YES"] + PRIOR["NO"]
MAX_BINARY, MAX_TEXT, WINDOW = 2 * 1024 * 1024, 256 * 1024, 3000
TEXTLIKE = (".txt", ".json", ".jsonl", ".md", ".log", ".py", ".mjs", ".js", ".csv", ".tsv", ".sh")
LANE = {"A": "A_CLOSED_INSTITUTION_OR_NAMED_ENDING", "B": "B_NARA_EXECUTED_OBSOLETE", "C": "C_NARA_TEMPORARY",
        "D": "D_AUTHORITY_REPEALED", "E": "E_POSITIVE_CONTINUITY", "F": "F_NRA_P3_RECOVERED", "G": "G_LATER_ENDING_EVENT"}


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def jl(p):
    out = []
    if os.path.exists(p):
        with open(p) as f:
            for l in f:
                l = l.strip()
                if l:
                    out.append(json.loads(l))
    return out


def wjl(p, rows):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        for r in rows:
            f.write(json.dumps(r, sort_keys=True, ensure_ascii=False) + "\n")


def wjson(p, o):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        json.dump(o, f, indent=1, sort_keys=True, ensure_ascii=False)
        f.write("\n")


if os.path.exists(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)

# ------------------------------------------------------------------ baseline
lp = os.path.join(PKT, "RECONCILED_STATUS_LEDGER_STAGE11_PROVISIONAL.jsonl")
assert sha(lp) == LEDGER_SHA, "Stage 11 ledger hash mismatch"
raw_lines = open(lp, "rb").read().split(b"\n")
ledger = {}
for ln in raw_lines:
    if ln.strip():
        r = json.loads(ln)
        ledger[r["instrument_id"]] = r
val = [r for r in ledger.values() if r.get("included_validated")]
c = collections.Counter(r["substantive_effect"] for r in val)
ca = collections.Counter(r["any_operative_EO_effect"] for r in val)
assert len(ledger) == 15010 and len(val) == DENOM
assert (c["yes"], c["no"], c["indeterminate"]) == (193, 2322, 12458), c
assert (ca["yes"], ca["no"], ca["indeterminate"]) == (205, 2165, 12603), ca
work = {r["instrument_id"]: r for r in jl(os.path.join(PKT, "WORKLISTS/OPUS_STAGE11_FINITE_CONTINUITY_1145.jsonl"))}
nra = {r["instrument_id"]: r for r in jl(os.path.join(PKT, "WORKLISTS/OPUS_NIRA_P3_RECOVERED_16.jsonl"))}
assert len(work) == 1145 and len(nra) == 16 and not set(work) & set(nra)
universe = set(work) | set(nra)
for i in universe:
    assert ledger[i]["substantive_effect"] == "indeterminate" and ledger[i].get("included_validated"), i
subfamily = {i: w["stage11_subfamily"] for i, w in work.items()}
subfamily.update({i: "nra_p3_recovered" for i in nra})

overrides = collections.defaultdict(list)
for o in jl(os.path.join(S11, "COORD_OVERRIDES.jsonl")):
    overrides[o["instrument_id"]].append(o)

# ------------------------------------------------------------------ shards and reviews
shards = sorted(d for d in os.listdir(os.path.join(S11, "shards")) if os.path.isdir(os.path.join(S11, "shards", d)))
records, accepted, held, seen_all = [], [], [], {}
stats = collections.defaultdict(collections.Counter)
for sh in shards:
    m = re.match(r"S11_([A-G])_", sh)
    lane = LANE[m.group(1)]
    phase = "expansion" if re.search(r"_X\d*$|_EXP", sh) else "pilot"
    revdir = "V" + sh[1:] + "_REV"
    revs = {r["instrument_id"]: r for r in jl(os.path.join(S11, "reviews", revdir, "reviews.jsonl"))}
    packet = {r["instrument_id"] for r in jl(os.path.join(S11, "packets", sh + ".jsonl"))}
    props = jl(os.path.join(S11, "shards", sh, "status_proposals.jsonl"))
    seen = set()
    for p in props:
        iid = p["instrument_id"]
        assert iid in packet and iid in universe, (sh, iid)
        assert iid not in seen_all, ("ID researched in two shards", iid, sh, seen_all.get(iid))
        seen.add(iid)
        seen_all[iid] = sh
        ps, pa = p.get("proposed_substantive_effect"), p.get("proposed_any_operative_effect")
        r = revs.get(iid)
        rv = r and r.get("verdict")
        rs, ra = (r.get("reviewer_substantive_effect"), r.get("reviewer_any_operative_effect")) if r else (None, None)
        if r is None or rv == "reject_other":
            fs, fa = "indeterminate", "indeterminate"
        else:
            fs = ps if rs == ps else "indeterminate"
            fa = pa if ra == pa else "indeterminate"
        applied = []
        for o in overrides.get(iid, []):
            assert o["value"] == "indeterminate"
            if o["axis"] == "substantive" and fs != "indeterminate":
                fs = "indeterminate"; applied.append(o)
            if o["axis"] == "any" and fa != "indeterminate":
                fa = "indeterminate"; applied.append(o)
        if r is None:
            state = "NOT_YET_REVIEWED"
        elif fs == "indeterminate":
            state = "REVIEWED_INDETERMINATE" if ps == "indeterminate" else "REVIEW_DISAGREEMENT_HELD"
        else:
            state = "ACCEPTED_PROVISIONAL"
        st = stats[(lane, phase)]
        st["researched"] += 1
        st["texts_complete"] += bool(p.get("text_obtained") and p.get("footprint_complete"))
        st["reviewed"] += r is not None
        st["review_accept"] += rv == "accept"
        st["review_corrections"] += rv == "accept_with_correction"
        st["review_reject_to_indeterminate"] += rv == "reject_to_indeterminate"
        st["review_reject_other"] += rv == "reject_other"
        st["accepted_yes"] += state == "ACCEPTED_PROVISIONAL" and fs == "yes"
        st["accepted_no"] += state == "ACCEPTED_PROVISIONAL" and fs == "no"
        st["any_effect_indeterminate_among_accepted"] += state == "ACCEPTED_PROVISIONAL" and fa == "indeterminate"
        rec = {"instrument_id": iid, "lane": lane, "phase": phase, "stage11_subfamily": subfamily[iid], "shard": sh,
               "reviewer": revdir, "ledger_title": ledger[iid]["title"], "ledger_signing_date": ledger[iid].get("signing_date"),
               "producer_proposal": [ps, pa], "producer_confidence": p.get("confidence"), "rule_id": p.get("rule_id"),
               "text_obtained": p.get("text_obtained"), "footprint_complete": p.get("footprint_complete"),
               "text_source_grade": p.get("text_source_grade"), "hold_reason": p.get("hold_reason"),
               "what_remains_inferential": p.get("what_remains_inferential"),
               "review_verdict": rv, "reviewer_statuses": [rs, ra], "review_problems": r and r.get("problems"),
               "dissent_or_limiting_predicates": r and r.get("dissent_or_limiting_predicates"),
               "coordinator_overrides": applied, "final_substantive_effect": fs, "final_any_operative_EO_effect": fa,
               "decision_state": state, "counted_in_coverage": state == "ACCEPTED_PROVISIONAL",
               "historical_causes": "UNKNOWN (retained; not researched)", "protected_fields_modified": False,
               "evidence_dir": f"evidence/shards/{sh}/", "review_dir": f"evidence/reviews/{revdir}/"}
        records.append(rec)
        if state == "ACCEPTED_PROVISIONAL":
            accepted.append(rec)
        else:
            held.append({"instrument_id": iid, "lane": lane, "state": state, "shard": sh,
                         "blocker": p.get("hold_reason") or (r and r.get("problems")) or "not reviewed"})
    for iid in sorted(packet - seen):
        held.append({"instrument_id": iid, "lane": lane, "state": "NO_PRODUCER_RECORD", "shard": sh, "blocker": "producer did not finish"})
        stats[(lane, phase)]["missing_producer_record"] += 1

wjl(os.path.join(OUT, "STAGE11_STATUS_RECORDS.jsonl"), records)
wjl(os.path.join(OUT, "STAGE11_ACCEPTED.jsonl"), [{k: a[k] for k in ("instrument_id", "lane", "stage11_subfamily", "final_substantive_effect", "final_any_operative_EO_effect", "rule_id", "shard", "reviewer", "review_verdict")} for a in accepted])
wjl(os.path.join(OUT, "STAGE11_HELD_QUEUE.jsonl"), held)
new_no = [a for a in accepted if a["final_substantive_effect"] == "no"]
new_yes = [a for a in accepted if a["final_substantive_effect"] == "yes"]
wjl(os.path.join(OUT, "PENDING_CLAUDE_NEW_NO_STAGE11.jsonl"), [
    {"instrument_id": a["instrument_id"], "new_substantive_effect": "no", "new_any_operative_EO_effect": a["final_any_operative_EO_effect"],
     "decision_id": "decision:opus11:" + a["instrument_id"], "cause_research_state": "PENDING_CLAUDE", "do_not_infer_first_cause": True,
     "origin": "OPUS_STAGE11_FINITE", "status_effect_cutoff": "2026-10-14"} for a in new_no])
wjl(os.path.join(OUT, "STAGE11_NEW_YES.jsonl"), [{k: a[k] for k in ("instrument_id", "lane", "final_any_operative_EO_effect", "rule_id", "ledger_title")} for a in new_yes])
unproc = [dict(work.get(i) or nra.get(i), unprocessed_reason="not researched this session") for i in sorted(universe - set(seen_all))]
wjl(os.path.join(OUT, "UNPROCESSED_WORKLIST.jsonl"), unproc)

# ------------------------------------------------------------------ patched ledger
acc_by = {a["instrument_id"]: a for a in accepted}
patched_path = os.path.join(OUT, "RECONCILED_STATUS_LEDGER_STAGE11_OPUS_PATCHED.jsonl")
changed = 0
with open(patched_path, "wb") as f:
    for i, ln in enumerate(raw_lines):
        if not ln.strip():
            if i < len(raw_lines) - 1:
                f.write(ln + b"\n")
            continue
        r = json.loads(ln)
        a = acc_by.get(r["instrument_id"])
        if a is None:
            f.write(ln + b"\n")
            continue
        prev = (r["substantive_effect"], r["any_operative_EO_effect"])
        r["substantive_effect"] = a["final_substantive_effect"]
        r["any_operative_EO_effect"] = a["final_any_operative_EO_effect"]
        r["decision_id"] = "decision:opus11:" + a["instrument_id"]
        r["decision_status"] = "accepted_present_status"
        r["headline_category"] = "continuing_substantive" if a["final_substantive_effect"] == "yes" else "ceased_substantive_cause_unallocated"
        r["evidence_grade"] = "opus11_independent_ai_review_" + str(a.get("text_source_grade") or "unspecified")
        r["opus11_present_status"] = {"decision_tier": "separately_model_reviewed_provisional_not_human_legal_peer_review",
                                      "integrating_stage": "OPUS_STAGE11_FINITE", "previous_substantive_status": prev[0],
                                      "previous_any_operative_status": prev[1], "opus_record": a}
        f.write(json.dumps(r, ensure_ascii=False).encode() + b"\n")
        changed += 1
# verify every untouched row is byte-identical and counts
src = [l for l in raw_lines if l.strip()]
dst = [l for l in open(patched_path, "rb").read().split(b"\n") if l.strip()]
assert len(src) == len(dst) == 15010
diff = [i for i, (x, y) in enumerate(zip(src, dst)) if x != y]
assert len(diff) == changed == len(accepted)
pv = [json.loads(l) for l in dst]
pv = [r for r in pv if r.get("included_validated")]
nc = collections.Counter(r["substantive_effect"] for r in pv)
na = collections.Counter(r["any_operative_EO_effect"] for r in pv)

ny, nn = len(new_yes), len(new_no)
newly = ny + nn
acct = {
    "cutoff": "2026-10-14 America/New_York", "codebook_version": "2.0.0",
    "baseline_source": "RECONCILED_STATUS_LEDGER_STAGE11_PROVISIONAL.jsonl sha256 " + LEDGER_SHA,
    "prior_accepted_substantive_determinate": PRIOR_DET, "prior_breakdown": PRIOR, "prior_any_effect": PRIOR_ANY,
    "prior_note": "Stage 9 v2's 180 and Astra Stage 10's results are PRIOR work, not Stage 11 throughput.",
    "added_ACCEPTED_YES": ny, "added_ACCEPTED_NO": nn, "newly_accepted": newly, "previously_accepted_overturned": 0,
    "substantive_UNKNOWN_remaining": PRIOR["UNKNOWN"] - newly,
    "numerator": PRIOR_DET + newly, "denominator": DENOM,
    "coverage_pct": round((PRIOR_DET + newly) / DENOM * 100, 6), "coverage_pct_prior": round(PRIOR_DET / DENOM * 100, 6),
    "post_stage11_substantive": {"YES": nc["yes"], "NO": nc["no"], "UNKNOWN": nc["indeterminate"]},
    "post_stage11_any_effect": {"YES": na["yes"], "NO": na["no"], "UNKNOWN": na["indeterminate"],
                                "coverage_pct": round((na["yes"] + na["no"]) / DENOM * 100, 6)},
    "accepted_any_effect_breakdown": dict(collections.Counter(a["final_any_operative_EO_effect"] for a in accepted)),
    "researched_ids": len(records), "held_ids": len(held), "unprocessed_ids": len(unproc),
    "patched_ledger_sha256": sha(patched_path), "patched_rows": changed, "untouched_rows_byte_identical": True,
    "historical_census_complete": False,
}
assert acct["post_stage11_substantive"] == {"YES": PRIOR["YES"] + ny, "NO": PRIOR["NO"] + nn, "UNKNOWN": PRIOR["UNKNOWN"] - newly}
wjson(os.path.join(OUT, "ACCOUNTING.json"), acct)

# ------------------------------------------------------------------ telemetry
tele = jl(os.path.join(S11, "TELEMETRY_LOG.jsonl"))
last = {}
for t in tele:
    tk = t.get("subagent_tokens_cumulative") or t.get("subagent_tokens")
    if tk:
        last[t["agent"]] = (tk, t.get("duration_ms_cumulative") or t.get("duration_ms") or 0)
tok, dur = collections.Counter(), collections.Counter()
for a, (tk, ms) in last.items():
    m = re.match(r"[SV]11_([A-G])_", a)
    if m:
        tok[LANE[m.group(1)]] += tk
        dur[LANE[m.group(1)]] += ms
per_lane = {}
for (lane, phase), st in stats.items():
    per_lane.setdefault(lane, collections.Counter()).update(st)
out_lanes = {}
for lane, st in per_lane.items():
    acc = st["accepted_yes"] + st["accepted_no"]
    out_lanes[lane] = dict(st, accepted=acc, subagent_tokens=tok[lane], agent_minutes=round(dur[lane] / 60000, 1),
                           accepted_per_100k_tokens=round(acc / tok[lane] * 1e5, 2) if tok[lane] else None,
                           accepted_per_agent_hour=round(acc / (dur[lane] / 3.6e6), 2) if dur[lane] else None)
wjson(os.path.join(OUT, "TELEMETRY.json"), {"per_lane": out_lanes,
                                             "per_lane_phase": [dict(lane=k[0], phase=k[1], **v) for k, v in sorted(stats.items())],
                                             "raw_agent_log": tele,
                                             "note": "Subagent tokens/durations as reported by the harness at completion; agents ran in parallel; coordinator tokens not exposed."})

# ------------------------------------------------------------------ rules, conflicts, protocols
rules = []
for sh in shards:
    rules += [dict(r, shard=sh) for r in jl(os.path.join(S11, "shards", sh, "rules.jsonl"))]
wjl(os.path.join(OUT, "rules/STAGE11_SHARD_RULES.jsonl"), rules)
for f in ("COORDINATOR_RULINGS.md", "PRODUCER_PROTOCOL.md", "REVIEWER_PROTOCOL.md"):
    if os.path.exists(os.path.join(S11, f)):
        shutil.copy2(os.path.join(S11, f), os.path.join(OUT, "rules", f))
conf = []
for base, kind in ((os.path.join(S11, "shards"), "producer"), (os.path.join(S11, "reviews"), "reviewer")):
    for d in sorted(os.listdir(base)):
        conf += [dict(r, reported_by=d, reporter_kind=kind) for r in jl(os.path.join(base, d, "conflicts.jsonl"))]
conf += [dict(r, reporter_kind="coordinator") for r in jl(os.path.join(S11, "COORD_CONFLICTS.jsonl"))]
wjl(os.path.join(OUT, "CONFLICT_LOG.jsonl"), conf)

# ------------------------------------------------------------------ evidence
skipped = []
qby = collections.defaultdict(set)
for base in (os.path.join(S11, "shards"), os.path.join(S11, "reviews")):
    for d in os.listdir(base):
        for fn in ("evidence.jsonl", "reviews.jsonl", "reviewer_evidence.jsonl"):
            for r in jl(os.path.join(base, d, fn)):
                for e in [r] + list(r.get("reviewer_evidence") or []):
                    lf, q = e.get("local_file"), e.get("quote")
                    if lf and isinstance(q, str) and q:
                        qby[os.path.basename(lf)].add(q)
images = []


def excerpt(sp, dp):
    text = open(sp, encoding="utf-8", errors="surrogateescape").read()
    spans = []
    for q in qby.get(os.path.basename(sp), ()):
        s = 0
        while True:
            i = text.find(q, s)
            if i < 0:
                break
            spans.append((max(0, i - WINDOW), min(len(text), i + len(q) + WINDOW)))
            s = i + 1
    if not spans:
        return 0
    spans.sort()
    mg = [list(spans[0])]
    for a, b in spans[1:]:
        if a <= mg[-1][1]:
            mg[-1][1] = max(mg[-1][1], b)
        else:
            mg.append([a, b])
    os.makedirs(os.path.dirname(dp), exist_ok=True)
    with open(dp + ".EXCERPTS.json", "w") as f:
        json.dump({"source_file": os.path.basename(sp), "source_sha256": sha(sp), "source_chars": len(text),
                   "windows": [{"start": a, "end": b, "text": text[a:b]} for a, b in mg]}, f, ensure_ascii=False)
    return len(spans)


def copy_tree(src, dst):
    for root, _, files in os.walk(src):
        names = set(files)
        for f in files:
            sp = os.path.join(root, f)
            rel = os.path.relpath(sp, src)
            dp = os.path.join(dst, rel)
            size = os.path.getsize(sp)
            stem = os.path.splitext(f)[0]
            if f.endswith((".html", ".htm")) and (stem + ".txt") in names:
                skipped.append({"path": os.path.relpath(dp, OUT), "bytes": size, "sha256": sha(sp), "note": "HTML not packaged; .txt and .meta.json packaged"})
                continue
            if f.endswith(".txt") and size > MAX_TEXT:
                n = excerpt(sp, dp)
                skipped.append({"path": os.path.relpath(dp, OUT), "bytes": size, "sha256": sha(sp),
                                "note": f"large text packaged as quote windows ({n} hits)" if n else "large text with no cited quote; not packaged"})
                continue
            if f.endswith(TEXTLIKE) or size <= MAX_BINARY:
                os.makedirs(os.path.dirname(dp), exist_ok=True)
                shutil.copy2(sp, dp)
            else:
                skipped.append({"path": os.path.relpath(dp, OUT), "bytes": size, "sha256": sha(sp), "note": "original bytes not packaged (size); see sibling .meta.json"})


for sh in shards:
    copy_tree(os.path.join(S11, "shards", sh), os.path.join(OUT, "evidence", "shards", sh))
for rv in sorted(os.listdir(os.path.join(S11, "reviews"))):
    copy_tree(os.path.join(S11, "reviews", rv), os.path.join(OUT, "evidence", "reviews", rv))
wjl(os.path.join(OUT, "evidence/UNPACKAGED_LARGE_ORIGINALS.jsonl"), skipped)
os.makedirs(os.path.join(OUT, "code"), exist_ok=True)
shutil.copy2(os.path.abspath(__file__), os.path.join(OUT, "code", "build_stage11.py"))
shutil.copy2(REPORT, os.path.join(OUT, "REPORT.md"))
for pk in sorted(os.listdir(os.path.join(S11, "packets"))):
    os.makedirs(os.path.join(OUT, "packets"), exist_ok=True)
    shutil.copy2(os.path.join(S11, "packets", pk), os.path.join(OUT, "packets", pk))

man = []
for root, _, files in os.walk(OUT):
    for f in sorted(files):
        p = os.path.join(root, f)
        rel = os.path.relpath(p, OUT)
        if rel != "MANIFEST.json":
            man.append({"path": rel, "sha256": sha(p), "bytes": os.path.getsize(p)})
man.sort(key=lambda x: x["path"])
wjson(os.path.join(OUT, "MANIFEST.json"), {"package": "OPUS_STAGE11_FINITE_STATUS_DELTA",
                                            "built_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                                            "inputs": {"stage11_ledger_sha256": LEDGER_SHA}, "files": man})
print(json.dumps({k: acct[k] for k in ("added_ACCEPTED_YES", "added_ACCEPTED_NO", "substantive_UNKNOWN_remaining", "numerator", "coverage_pct", "post_stage11_any_effect", "researched_ids", "held_ids", "unprocessed_ids", "patched_rows")}, indent=1))
print(json.dumps(out_lanes, indent=1))
