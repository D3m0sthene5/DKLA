# Stage 9/11 producer protocol (present-status research)

Project: The Afterlife of Executive Orders. Legal cutoff: **October 14, 2026, America/New_York**. Codebook **2.0.0** (frozen): `/tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s11/CODEBOOK_2.0.0_UNCHANGED.json`. Read its rules TC01-TC16 before the first decision.

You are a **producer** for one shard. An independent reviewer will check your work afterwards; your record is a proposal. Work only on the IDs in your packet. Write only inside your shard directory `s11/shards/<SHARD>/`.

## Question for each order

As of the cutoff, does the order still have (a) a **substantive** legal effect and (b) **any operative** legal effect of its own? Each answer is `yes`, `no` or `indeterminate`.

- `no` substantive only if every substantive provision has ended. `no` any-effect only if every provision, residual ones included, has ended. A finite completed event (a closing on a past date, a completed sale, a board that reported and dissolved) is spent under TC07; a continuing right, status, property interest, incorporated amendment or saved provision may remain.
- `yes` requires a present actor/object, a command/permission/status, unexpired applicability and a legal source (TC05, TC14).
- Anything you cannot close is `indeterminate` with a `hold_reason` naming the missing fact and the source that would settle it. Never guess `no`.
- Mixed orders: decide every clause. Amending orders: map the footprint in the host (TC09).
- Do not infer an ending from age, title, a person's death or the age of the order. Indian land trust periods are usually extended until Congress directs otherwise (25 U.S.C. 5102): never expire them by date.
- Historical causes stay UNKNOWN; you do not research causes, first-cessation dates or formal disposition fields beyond what the status needs.

## Mandatory gates per order

1. Identify the order (number, date, title) and note any conflict with the ledger title/date in `conflicts.jsonl` (never "correct" the ledger).
2. Retrieve its **complete operative text** (annexes too where they carry operative content). A ledger title, Lord (1944) list entry, search snippet or summary is NOT operative text and cannot support `no`.
3. Map every operative clause: actor / object / authority / time / conditions.
4. Retrieve controlling law: authorizing statute, repeal/expiration, savings clauses, later amendments or revivals, the affected host. Look for later orders that amend, revoke, extend or supersede (APP search, Federal Register, NARA disposition tables at archives.gov/federal-register/executive-orders/disposition-tables).
5. Decide substantive and any-effect separately.
6. Record counterevidence checked and what remains inferential.

## Sources and evidence (strict)

The network is open. Fetch with `curl -sSL` from the shell and **store original bytes**: `cache/<source_id>.<ext>` (html/pdf). Right after each fetch write `cache/<source_id>.meta.json` with `url`, `final_url`, `retrieved_utc` (take it from `date -u +%Y-%m-%dT%H:%M:%SZ` at fetch time; never invent or approximate), `http_status`, `content_type`, `sha256` of the bytes, `method: "curl original bytes"`. Extract text to `cache/<source_id>.txt` (pdftotext -layout for PDFs; for HTML use python3 -I with bs4 and keep the extraction method in the meta file, plus the text file's sha256). Quotes in evidence must be **exact substrings of the .txt file**; verify with python before writing.

If you must use WebFetch (e.g. a page that blocks curl), save the returned text with a first header line: URL, actual retrieval time, "WebFetch rendering; original bytes not stored"; grade it `hosted_transcript`. WebSearch is for locating URLs only.

Useful sources:
- American Presidency Project (APP): `https://www.presidency.ucsb.edu/documents/executive-order-<number>-<slug>`; search: `https://www.presidency.ucsb.edu/advanced-search?field-keywords=<words>&items_per_page=50`. Grade `hosted_transcript` (APP is a transcription, not the signed original).
- Federal Register 1936+: whole daily issues at `https://www.govinfo.gov/content/pkg/FR-YYYY-MM-DD/pdf/FR-YYYY-MM-DD.pdf` (large; extract only the order's pages into your quotes). Grade `official_publication`.
- Statutes at Large: `https://www.govinfo.gov/link/statute/<volume>/<page>` (follow redirects) and Library of Congress `https://www.loc.gov/law/help/statutes-at-large/`. U.S. Code: `https://uscode.house.gov/` (current and notes), `https://www.govinfo.gov/app/collection/uscode` (1994+ editions), `https://www.law.cornell.edu/uscode/text/<title>/<section>`. CFR: `https://www.ecfr.gov/`.
- NARA EO disposition tables (1937+): `https://www.archives.gov/federal-register/executive-orders/<year>.html` and `.../disposition-tables`.
- Older material: archive.org full texts (`https://archive.org/advancedsearch.php?q=...&fl[]=identifier&output=json`, then `https://archive.org/stream/<id>/<id>_djvu.txt`). HathiTrust returns 403 to the shell; try WebFetch if essential.
- Pre-1937 orders: APP has many; the 1944 Lord list is only an index.

Retrieve each shared statute once and reuse it across orders. Reuse files already in `s11/shared_cache/` if present (read-only). Keep scripts in `s11/shards/<SHARD>/code/`, run Python as `python3 -I`, and never execute downloaded content.

## Output files (JSON Lines, in your shard directory; write as you finish each order)

`status_proposals.jsonl`, exactly one per packet ID:
```
{"instrument_id","shard_id","family","proposal_id":"opus:s9:status:<ID>",
 "proposed_substantive_effect":"yes|no|indeterminate","proposed_any_operative_effect":"yes|no|indeterminate",
 "operative_footprint":[{"clause","actor","object","authority","time_or_condition","end":{"date","basis"},"evidence_ids":[]}],
 "footprint_complete":bool,"text_obtained":bool,
 "text_source_grade":"original_signed|official_publication|hosted_transcript|index_only|none",
 "controlling_authority_evidence_ids":[],"subsequent_change_check":{"searched":[...],"findings":"..."},
 "savings_or_residual_considered":"...","rule_id":"<shared rule id or null>","evidence_ids":[],
 "confidence":"high|medium|low","hold_reason":null|"...","what_remains_inferential":"...",
 "ownership_status":"<copy from packet>","producer_state":"producer_supported_pending_independent_review"}
```
`no` requires text_obtained true, footprint_complete true and a grade other than index_only/none.

`evidence.jsonl`: `{"evidence_id","source_id","source_title","url","retrieved_utc","local_file","local_file_sha256","quote","locator","retrieval_method","evidence_grade","supports"}`.

`rules.jsonl` (one per shared rule you rely on): `rule_id, legal_authority, sources, applicability_predicates, exceptions, savings_or_surviving_effects, covered_ids, what_evidence_proves, what_remains_inferential, substantive_result, any_effect_result`. Every covered order must meet the predicates on its own text (TC16). A family rule that fails on a counterexample must be dropped or narrowed, not forced.

`queue.jsonl` (`instrument_id, blocker, source_that_would_settle_it`), `conflicts.jsonl`, and `SHARD_REPORT.md`: counts by proposed status, texts obtained, footprints complete, retrieval failures, new legal blockers, and your **actual UTC start and end time** (`date -u`). Final reply: at most 10 lines.

## STANDING RULE (owner's instruction, 2026-10-16): never give up on a blocked source

If the American Presidency Project, Cornell LII, uscode.house.gov (or any other source you need) is blocked, errors, rate-limits or returns a bot page, you MUST keep trying with increasingly creative methods before marking anything as unobtainable. Escalate in roughly this order and log every attempt (method, URL, result) in your SHARD_REPORT.md:
1. Retry with a short backoff; try the other host form (www./bare), http->https, a different path (APP `/node/<id>` vs `/documents/<slug>`), a print or plain-text view, a browser-like User-Agent header.
2. Switch tools: curl <-> WebFetch; or render the page in the pre-installed headless Chromium via Playwright (`node` with `playwright`, executablePath `/opt/pw-browsers/chromium` if needed; PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers) and save page.content().
3. Archived copies: Wayback Machine (`https://web.archive.org/web/2024*/<url>`, CDX API `https://web.archive.org/cdx/search/cdx?url=<url>&output=json`, then `https://web.archive.org/web/<timestamp>id_/<url>` for original bytes), archive.today.
4. Other official or authoritative copies of the same text: govinfo (Federal Register issues, Statutes at Large, US Code editions incl. USCODE-YYYY XML/HTML, CFR annual editions), federalregister.gov API, NARA, Library of Congress (tile.loc.gov Statutes at Large / FR), presidential library sites (trumanlibrary.gov, fdrlibrary, eisenhowerlibrary, etc.), GPO bulk data, uscode.house.gov downloads (XML zips), eCFR API.
5. Reputable secondary hosts of the same primary text: Justia, Casetext/CourtListener, govregs, Wikisource, Google Books/HathiTrust full-text views (try WebFetch or Playwright if curl gets 403), archive.org scans (full-text `_djvu.txt`), university repositories, GitHub mirrors of official XML (e.g. US Code USLM).
6. Use WebSearch to discover new mirrors or the exact document location, then fetch the document itself.
Record the grade honestly: a mirror or archive copy is graded by what it is (e.g. `archived_copy_of_official_publication`, `hosted_transcript`), with the original URL it copies. Limits that still apply: do not defeat logins, paywalls or CAPTCHAs, and do not route traffic through paid third-party services. Only after the full ladder fails may you hold an order for lack of text, and the hold must list every method tried.

## STAGE 11 ADDENDUM (2026-10-16)

- Baseline: s11 packet ledger RECONCILED_STATUS_LEDGER_STAGE11_PROVISIONAL.jsonl (sha256 c0308e00...): 193 YES / 2,322 NO / 12,458 UNKNOWN. Every ID in your packet is UNKNOWN there. Never research or change any other ID (in particular not the 180 Stage 9 results, Astra's Stage 10 results, or Astra's 1,181 civil-service IDs).
- Your packet rows carry NARA's 1989 disposition notes and Federal Register metadata. These are LEADS (NARA's editorial view as of 1989-01-20), never proof of a 2026 status.
- Group your orders by operative text and ending statute; retrieve each shared statute/ending instrument ONCE (into your shard cache) and cite it for every order it covers. Reuse s9/shared files read-only where relevant: /tmp/claude-0/-home-user-DKLA/12ae7585-13c6-58ed-91db-9f0727202756/scratchpad/s9/shards/*/cache (e.g. Pub. L. 87-581, Tax Reform Act 1976, Official U.S. Bulletin texts) — cite by path and sha256.
- Source failures: never repeat the same failing method more than twice; move to the next rung of the STANDING RULE ladder; log each attempt. Stop at interactive CAPTCHAs.
- Disk: no PDF over 20 MB kept (keep meta/sha256, full text, and page excerpts).
- Output the per-order record compactly: predicates met/failed, exceptions checked, quotes — not essays.
- For a YES: show a present actor/object, the original order's attributable legal operation, and a live 2026 legal bridge (current CFR/USC text or a current agency delegation/document) plus a check of amendments/revocations through 2026-10-14.
- Indian land trust periods: NEVER expire by date or by general repeal (25 U.S.C. 5102).
